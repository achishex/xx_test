#!/bin/bash

echo "Start build media Transfer"

#chmod 777 ./* -R 

cd ./src

make clean

make

#make install

echo "End build media Transfer"

