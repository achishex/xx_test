///////////////////////////////////////////////////////////////
//
// FileName : 
// Creator  : fan
// Date     : 2017-12-21
// Comment  : rabbitMQ  client 
//
///////////////////////////////////////////////////////////////

#ifndef _RABBITMQ_CLIENT
#define _RABBITMQ_CLIENT


#include <amqp.h>
#include <amqp_framing.h>
#include <amqp_tcp_socket.h>
#include "common.h"
#include "clientSession.h"
#include "udpLogBase.h"
#include "dev_info.h"

class RabbitMQClient
{
public:
    RabbitMQClient();
    ~RabbitMQClient();
    int logIn();
    int logIn(const char* host, int port,char const* vhost,const char* username,const char* password);
    int publishMessage(const char* message);
    int basicPublish(const char* queuename,const char* body);
    //int basicConsumer(const char* queuename,std::string& message);
    //int queueClear(const char* queuename, vector<string>& messagevec) ;
    void loopConsumer();
    void consumerRun();
    void closeConnection();
    void consumerInit();

    void SetDevInfoHandle( DevInfo* pDevInfo )
    {
        m_pDevInfo = pDevInfo; 
    }

    bool ParseDevSrcIP(std::string& sIP, std::string& sMsgId, const std::string& sSDPBuf);
    bool NotifyDevSrcIpToUdpEvent( const std::string& sMsgId, const std::string& sDevip );
    bool UpdateMsgStatus( const std::string& sMsgId );
    
private:
	string _MQServerIp;
	string _udpServerIp;
	UdpLogBase _udpLogBase;
    amqp_connection_state_t m_amqpConn;

    DevInfo* m_pDevInfo;
public:
   static RabbitMQClient* create() ;
   
};

#endif // !
