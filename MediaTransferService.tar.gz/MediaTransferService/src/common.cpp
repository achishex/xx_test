///////////////////////////////////////////////////////////////
//
// FileName : common.cpp
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : common source file
//
///////////////////////////////////////////////////////////////

#include "common.h"


void S_clientToIPCMsg::display()
{
    LOG_INFO_("S_clientToIPCMsg sendToIp: %s - sendToPort: %d - localPort: %d - command: %d - deviceCode:%s", sendToIp, sendToPort, localPort, command, chDevIndeCode);
}

int singleton(const string& lock_file)
{
    int fd = open(lock_file.c_str(), O_WRONLY|O_CREAT, S_IRWXU);
    if ( -1 == fd )
    {
        cout << "open lock file: [ " << lock_file << " ] fail! err msg: " << strerror(errno) << endl;
        return -1;
    }

    int rv = flock(fd, LOCK_EX|LOCK_NB);
    if (0 != rv)
    {
        cout << "the process is running!" << endl;
        close(fd);
        return -1;
    }
    return 0;
}
