///////////////////////////////////////////////////////////////
//
// FileName : HandleHeartbeat.cpp
// Creator  : fan
// Date     : 2017-12-22
// Comment  : handle_stream head file
//
///////////////////////////////////////////////////////////////

#include "HandleHeartbeat.h"
#include "udpClient.h"

#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

using namespace rapidjson;

/***
***...HandleHeartbeat()...
***...主要实现停止音频视频流...
***/
HandleHeartbeat::HandleHeartbeat() 
{
    m_pHttpServer = NULL ;
    m_bReplyStatus = false ;
    m_iReceivePort = 0 ;
}

HandleHeartbeat::~HandleHeartbeat() 
{

}

void HandleHeartbeat::init(std::string& urldata, HttpServer* httpserver)
{
    m_sReceiveData = urldata ;
    m_pHttpServer = httpserver ;
}

void HandleHeartbeat::getReplyData(std::string& replaydata)
{
    if(true == m_bReplyStatus)
    {
        replaydata = "{\"errMsg\": \"success!\", \"success\": true}";
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
}

bool HandleHeartbeat::receiveDataParse(std::string& urldata)
{
    if(urldata.empty())
    {
        LOG_ERROR_("urldata is NULL");
        return false;
    }

    Document document;
    document.Parse<0>(urldata.c_str());
    if( document.HasParseError() )
    {
        /* 报错 */
        cout<<"Parse错误描述:"<<rapidjson::GetParseError_En(document.GetParseError())<<endl ;
        cout<<"urldata"<<urldata<<endl ;
        return false ;
    }
    if( !document.IsObject() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("json parse error in HandleStreamStop::receiveDataParse") ;
        return false ;
    }

    if( !document.HasMember("receiveIp") || !document["receiveIp"].IsString() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document Parse receiveIp eror ") ;
        return false ;
    }
    m_sReceiveIp = document["receiveIp"].GetString();

    if( !document.HasMember("receivePort") || !document["receivePort"].GetInt() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document Parse receivePort eror ") ;
        return false ;
    }
    m_iReceivePort = document["receivePort"].GetInt();

    return true;

}

void  HandleHeartbeat::deal(const char *peerIp)
{
    m_bReplyStatus = this->receiveDataParse(m_sReceiveData);
    if( m_bReplyStatus == false )
    {
        return ;
    }
    char buf[100] ;
    memset(buf , 0, sizeof(char )*100 ) ;
    sprintf(buf,"%s:%d", m_sReceiveIp.c_str(), m_iReceivePort ) ;
    string clientID = buf;//流唯一标示
    
    string strLogDump = ConfigXml::getIns()->getValue("Log", "LogDump");
    if (strLogDump == "1" )
    {
        LOG_DEBUG_("client %s heartbeat",clientID.c_str());
    }

    if (m_pHttpServer -> m_ClientSessionList.find(clientID) == m_pHttpServer->m_ClientSessionList.end())
    {
        m_bReplyStatus =false ;
        return ;
    }

    ClientSession* pClient = m_pHttpServer->m_ClientSessionList[clientID];
    pClient->SetClientUpdate();
    return ;
}


HandleVideoAppHeartbeat::HandleVideoAppHeartbeat() 
{
    m_pHttpServer = NULL ;
    m_bReplyStatus = false ;
}

HandleVideoAppHeartbeat::~HandleVideoAppHeartbeat() 
{

}

void HandleVideoAppHeartbeat::init(std::string& urldata, HttpServer* httpserver )
{
    m_sReceiveData = urldata ;
    m_pHttpServer = httpserver ;
}

void HandleVideoAppHeartbeat::getReplyData(std::string& replaydata)
{
    replaydata = "{\"errMsg\": \"success!\", \"success\": true}";
}

void  HandleVideoAppHeartbeat::deal(const char *peerIp)
{
    return ;
}
