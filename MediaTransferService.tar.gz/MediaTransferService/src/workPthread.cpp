///////////////////////////////////////////////////////////////
//
// FileName : workPthread.cpp
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : workPthread source file
//
///////////////////////////////////////////////////////////////

#include "workPthread.h"

WorkPthread::WorkPthread()
{
	m_prior = 1;
	m_startStatus = 0;
    m_mutex = PTHREAD_MUTEX_INITIALIZER;
}

void WorkPthread::start()
{
    int ret = pthread_create(&m_tid, NULL, workPthreadFunc, this);
	if ( 0 != ret )
	{
		LOG_ERROR_( "create the workPthread failed" ) ;
		return;
	}
	m_startStatus = 1;
	// LOG_NOTICE_("create the workPthread sucess, tid: %ld", gettid());
}

void* WorkPthread::workPthreadFunc(void* arg)
{
	if ( arg )
	{
    	WorkPthread* work = static_cast<WorkPthread*>(arg);
		work->run();
	}
	return NULL;
}


/* int WorkPthread::getStartStatus()
{
	return m_startStatus;
} */

void WorkPthread::stop()
{
	m_startStatus = 0;
}

/* void WorkPthread::lock()
{
    pthread_mutex_lock(&m_mutex);
} */

void WorkPthread::unlock()
{
    pthread_mutex_unlock(&m_mutex);
}

/* pthread_t WorkPthread::gettid()
{
	return m_tid;
} */

WorkPthread::~WorkPthread()
{
	stop();
    pthread_mutex_trylock(&m_mutex);
	unlock();
	pthread_mutex_destroy(&m_mutex);
}
