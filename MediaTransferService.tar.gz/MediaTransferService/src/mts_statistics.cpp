#include "mts_statistics.hpp"

using namespace rapidjson;
namespace MTS
{

    const std::string HandleStatistics::SNAMERMEMMAX        = "net.core.rmem_max";
    const std::string HandleStatistics::SNAMERMEMDEFAULT    = "net.core.rmem_default";
    const std::string HandleStatistics::SNAMEWMEMMAX        = "net.core.wmem_max";
    const std::string HandleStatistics::SNAMEWMEMDEFAULT    = "net.core.wmem_default";

    void StreamInfo::GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc)
    {
        std::stringstream ios;
        ios << sDevCode << " : " << sDevChannelId;
        rapidjson::Value devchannelSub;
        devchannelSub.SetString( ios.str().c_str(), ios.str().size(), alloc);
        jsonObj.AddMember("Devcode_channelid", devchannelSub, alloc);
        
        rapidjson::Value ipSub;
        ipSub.SetString( sIpClientRcvStream.c_str(), sIpClientRcvStream.size(), alloc);
        jsonObj.AddMember("ClientRecvStreamIp", ipSub, alloc);

        jsonObj.AddMember("ClientRecvStreamPort", uiPortClientRcvStream, alloc);
        jsonObj.AddMember("MtsRelayStreamtoClientPort", uiStreamRelayPort, alloc);

        return ;
    }

    void AudioVideoInfo::GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc)
    {
        rapidjson::Value devSub;
        devSub.SetString( sDevCode.c_str(), sDevCode.size(), alloc);
        jsonObj.AddMember("DevCode", devSub, alloc);
        
        rapidjson::Value devIpSub;
        devIpSub.SetString( sIpDevRcvAudio.c_str(), sIpDevRcvAudio.size(), alloc);
        jsonObj.AddMember("DevRcvAudioIp", devIpSub, alloc);
        jsonObj.AddMember("DevRcvAudioPort", uiPortDevRcvAudio, alloc);
        jsonObj.AddMember("MtsRelayAudioToDevPort", uiPortRelayAudioToDev, alloc);
       
        rapidjson::Value clientIpSub;
        clientIpSub.SetString( sIpClientRcvStream.c_str(), sIpClientRcvStream.size(), alloc);
        jsonObj.AddMember("ClientRcvVideoIp", clientIpSub, alloc);
        jsonObj.AddMember("ClientRcvVideoPort", uiPortClientRcvStream, alloc);
        jsonObj.AddMember("MtsRelayVideotoClientPort", uiPortRelayVideoToClient, alloc);

        rapidjson::Value clientIpAudioSub;
        clientIpAudioSub.SetString( sIpClientRcvAudio.c_str(), sIpClientRcvAudio.size(), alloc);
        jsonObj.AddMember("ClientRcvAudioIp", clientIpAudioSub, alloc);
        jsonObj.AddMember("ClientRcvAudioPort", uiPortClientRecvAudio, alloc);
        jsonObj.AddMember("MtsRelayAudiotoClientPort", uiPortRelayAudioToClient, alloc);

        return ;
    }


    HandleStatistics::HandleStatistics()
    {
        RegisterStatType();
    }
    HandleStatistics::~HandleStatistics()
    {
        m_mpToStatType.clear();
        m_mpCloudAvStats.clear();
        m_mpNicStats.clear();
        m_mpWRBufLen.clear();
        m_uiClientNums = 0;
        m_mpAudioVideoStat.clear();
        m_mpStreamStat.clear();
        m_mpStrConf.clear();
        m_mpIntConf.clear();
        m_pHttpServer = NULL;
        m_mpUuidVIp.clear();
    }

    void HandleStatistics::init(std::string& urldata, HttpServer* httpserver)
    {
        m_pHttpServer = httpserver;
        m_bReplyStatus = true;
        
        m_mpIntConf.clear();
        m_mpStrConf.clear();

        m_mpStreamStat.clear();
        m_mpAudioVideoStat.clear();
        m_uiClientNums = 0;

        for (auto it = m_mpWRBufLen.begin(); it != m_mpWRBufLen.end(); ++it)
        {
            it->second.CleanStat();
        }
        
        std::vector<std::string> vAllNicName;
        bool bRet = NICStat::NicCmd::GetAllNicName(vAllNicName);
        if ( bRet == false || vAllNicName.empty() )
        {
            LOG_DEBUG_("get all nic name in this sys fail");
        }
        else 
        {
            m_mpNicStats.clear();
            for (auto it = vAllNicName.begin(); it != vAllNicName.end(); ++it)
            {
                NICStat oneStat(*it);
                m_mpNicStats.insert(std::make_pair(*it, oneStat));
            }
        }
        m_mpCloudAvStats.clear();
        m_mpUuidVIp.clear();
        LOG_DEBUG_("mts statistics get req init");
    }

    void HandleStatistics::deal(const char *peerIp)
    {
        for (auto it = m_mpToStatType.begin(); it != m_mpToStatType.end(); ++it)
        {
            if (it->second == NULL)
            {
                continue;
            }
            StatInterface statfunc = it->second;
            ((*this).*statfunc)();
        }
    }

    void HandleStatistics::getReplyData(std::string& replaydata)
    {
        std::string sResponseFormat;
        sResponseFormat += "<!DOCTYPE html>\n"; 
        sResponseFormat += "<html>\n";
        sResponseFormat += "<head>\n";
        sResponseFormat += "<meta charset=\"utf-8\">\n";
        sResponseFormat += "<title>mts_statistics(hd)</title>\n";
        sResponseFormat += "</head>\n";
        sResponseFormat += "<body>\n";
        sResponseFormat += "<h1>mts_statistics</h1>\n<p>";

        if (m_bReplyStatus == false)
        {
           sResponseFormat += "{\"errMsg\": \"false!\", \"success\": false}</p>\n";
           sResponseFormat += "</body>\n";
           sResponseFormat += "</html>\n";
           replaydata       = sResponseFormat;
           return ;
        }

        Document doc;
        doc.SetObject();
        Document::AllocatorType &allocator = doc.GetAllocator();
        
        //"ClientNums": 1231
        doc.AddMember("ClientNums", m_uiClientNums, allocator);
        
        rapidjson::Value mtsconfObj(rapidjson::kObjectType);
        for (auto it = m_mpIntConf.begin(); it != m_mpIntConf.end(); ++it)
        {
            //   "MTS_Conf": {"ab":12, "bc":1231}
            mtsconfObj.AddMember(rapidjson::StringRef(it->first.c_str()), it->second, allocator);
        }
        for (auto it = m_mpStrConf.begin(); it != m_mpStrConf.end(); ++it)
        {
            //   "MTS_Conf": {"ab":12, "bc":"1231"}
            rapidjson::Value strItemSub;
            strItemSub.SetString( it->second.c_str(), it->second.length(), allocator);
            mtsconfObj.AddMember(rapidjson::StringRef(it->first.c_str()), strItemSub, allocator);
        }
        doc.AddMember("MTS_Conf", mtsconfObj, allocator);
        

        rapidjson::Value sysconfObj(rapidjson::kObjectType);
        for (auto it = m_mpWRBufLen.begin(); it != m_mpWRBufLen.end(); ++it)
        {
            //   "SYS_Conf": {"ab":12, "bc":1231}
            sysconfObj.AddMember(rapidjson::StringRef(it->first.c_str()), 
                                    it->second.GetStatItem(), allocator);
        }
        doc.AddMember("SYS_Conf", sysconfObj, allocator);


        rapidjson::Value nicJsonArr(rapidjson::kArrayType);
        for (auto it = m_mpNicStats.begin(); it != m_mpNicStats.end(); ++it)
        {
            // "Nic": [ {"eth0": {"a":1, "b":2}}, {"eth1": {"ab":12, "bc":23}} ]
            rapidjson::Value onenicDetail(rapidjson::kObjectType);
            it->second.GetJsonObj(onenicDetail, allocator);
           
            rapidjson::Value oneNic(rapidjson::kObjectType);
            oneNic.AddMember( rapidjson::StringRef(it->first.c_str()),
                                onenicDetail, allocator );
            
            nicJsonArr.PushBack(oneNic, allocator);
        }
        doc.AddMember("Nic",nicJsonArr, allocator);

        rapidjson::Value uuidDevIpArr(rapidjson::kArrayType);
        for (auto it = m_mpUuidVIp.begin(); it != m_mpUuidVIp.end(); ++it)
        {
            //"UUID_DEV":[ {"uuid":"", "ip":["ip1","ip2"]}, {} ]
            rapidjson::Value oneUUIDDEV(rapidjson::kObjectType);
            
            rapidjson::Value uuidDev;
            uuidDev.SetString(it->first.c_str(), it->first.length(), allocator);
            oneUUIDDEV.AddMember("uuid", uuidDev, allocator);

            rapidjson::Value ipArray(rapidjson::kArrayType);
            for (auto itIp = it->second.begin(); itIp != it->second.end(); ++itIp)
            {
                rapidjson::Value oneIp(kStringType);
                oneIp.SetString(itIp->c_str(),itIp->length(), allocator);
                ipArray.PushBack(oneIp, allocator);
            }
            oneUUIDDEV.AddMember("ip", ipArray, allocator);

            uuidDevIpArr.PushBack(oneUUIDDEV, allocator);
        }
        doc.AddMember("UUID_DEV", uuidDevIpArr, allocator);


        //key: devcode+channel id
        std::map<std::string, std::vector<StreamInfo> > mpDevVClients;
        for (auto it = m_mpStreamStat.begin(); it != m_mpStreamStat.end(); ++it)
        {
            std::stringstream ios; 
            ios << it->second.sDevCode << ":" << it->second.sDevChannelId;

            auto itDevClient = mpDevVClients.find(ios.str());
            if ( itDevClient == mpDevVClients.end() )
            {
                std::vector<StreamInfo> vClients;
                vClients.push_back(it->second);
                mpDevVClients.insert(std::make_pair(ios.str(), vClients));
            }
            else 
            {
                itDevClient->second.push_back(it->second);
            }
        }

        rapidjson::Value streamStatArray(rapidjson::kArrayType); 
        for (auto it = mpDevVClients.begin(); it != mpDevVClients.end(); ++it)
        {
            // "VideoPreview": [ {"Dev":"1231", "12313": [ {}, {} ] }, { }]
             rapidjson::Value oneDev(rapidjson::kObjectType);
             rapidjson::Value devSub;
             devSub.SetString( it->first.c_str(), it->first.length(), allocator );
             oneDev.AddMember(rapidjson::StringRef("Dev"), devSub, allocator);
             
             rapidjson::Value vclientArray(rapidjson::kArrayType);
             for (auto itvClient = it->second.begin(); itvClient != it->second.end(); ++itvClient)
             {
                 rapidjson::Value clientStat(rapidjson::kObjectType);
                 itvClient->GetJsonObj(clientStat, allocator);
                 vclientArray.PushBack(clientStat, allocator);
             }
             oneDev.AddMember(rapidjson::StringRef(it->first.c_str()), vclientArray, allocator);
             streamStatArray.PushBack(oneDev, allocator);
        }
        doc.AddMember("VideoPreview", streamStatArray, allocator);


        // speakable process 
        rapidjson::Value AudioVideoStatArray(rapidjson::kArrayType); 
        for (auto it = m_mpAudioVideoStat.begin(); it != m_mpAudioVideoStat.end(); ++it)
        {
            // "VisibleSpeak": [{ "Dev":"12313", "123123":{} }, {}]
             rapidjson::Value oneDev(rapidjson::kObjectType);

             rapidjson::Value devSub;
             devSub.SetString( it->first.c_str(), it->first.length(), allocator );
             oneDev.AddMember("Dev", devSub, allocator);
             
             rapidjson::Value devInfoObj(rapidjson::kObjectType);
             it->second.GetJsonObj(devInfoObj, allocator);
             oneDev.AddMember(rapidjson::StringRef(it->first.c_str()), devInfoObj, allocator);
             
             AudioVideoStatArray.PushBack(oneDev, allocator);
        }
        doc.AddMember("VisibleSpeak", AudioVideoStatArray, allocator);
   

        //cloud speak process
        rapidjson::Value CloudSpeakStatArray(rapidjson::kArrayType); 
        for (auto it = m_mpCloudAvStats.begin(); it != m_mpCloudAvStats.end(); ++it)
        {
            //"CloudSpeak:[ {"Dev":"", "DevRcvAudioIp":"", "DevRcvAudioPort":123}, {}, {} ]"
            
            rapidjson::Value  oneCloudSpeakDev(rapidjson::kObjectType);
            it->second.GetJsonObj(oneCloudSpeakDev, allocator);
            CloudSpeakStatArray.PushBack(oneCloudSpeakDev, allocator);
        }
        doc.AddMember("CloudSpeak", CloudSpeakStatArray, allocator);
       

        //
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        doc.Accept(writer);

        sResponseFormat += buffer.GetString();
        sResponseFormat += "</p>\n</body>\n";
        sResponseFormat += "</html>";
        replaydata = sResponseFormat;
        LOG_DEBUG_("get response: %s", replaydata.c_str());
    }

    void HandleStatistics::RegisterStatType()
    {
        m_mpToStatType.insert(std::make_pair(STAT_CONF, &HandleStatistics::GetConfInfo));

        m_mpToStatType.insert(std::make_pair(STAT_MQ, &HandleStatistics::GetMQReqRespStat));

        m_mpToStatType.insert(std::make_pair(STAT_CURSTREAM, 
                              &HandleStatistics::GetCurStartedStremStat));

        m_mpToStatType.insert(std::make_pair(STAT_CURAVSPEAK,
                              &HandleStatistics::GetCurAudioVideoStat));

        m_mpToStatType.insert(std::make_pair(STAT_CLIENTS,
                              &HandleStatistics::GetClientNums));

        m_mpToStatType.insert(std::make_pair(STAT_NETWRBUFLEN,
                              &HandleStatistics::GetSysWRBufLen));

        m_mpToStatType.insert(std::make_pair(STAT_NICCONF,
                              &HandleStatistics::GetNicStats));
        
        m_mpToStatType.insert(std::make_pair(STAT_CLOUDAV,
                              &HandleStatistics::GetCloudAVStats));

        m_mpToStatType.insert(std::make_pair(STAT_UUIDVIP,
                              &HandleStatistics::GetUuidIpList));
        
        //------------------------------------------------------------//
        SysWRBufStat rMemMaxStat(SNAMERMEMMAX);
        m_mpWRBufLen.insert(std::make_pair(SNAMERMEMMAX, rMemMaxStat));

        SysWRBufStat rMemDefault(SNAMERMEMDEFAULT);
        m_mpWRBufLen.insert(std::make_pair(SNAMERMEMDEFAULT, rMemDefault));
        
        SysWRBufStat wMemMaxStat(SNAMEWMEMMAX);
        m_mpWRBufLen.insert(std::make_pair(SNAMEWMEMMAX, wMemMaxStat));

        SysWRBufStat wMemDefault(SNAMEWMEMDEFAULT);
        m_mpWRBufLen.insert(std::make_pair(SNAMEWMEMDEFAULT, wMemDefault));
    }

    //inner interface 
    void HandleStatistics::GetConfInfo()
    {
        m_mpStrConf.insert(std::make_pair(std::string("RabbitMQ_Host"),
                                          ConfigXml::getIns()->getValue("RabbitMQ", "host") 
                                         )
                           );
        m_mpStrConf.insert(std::make_pair("Tutk_UUID", 
                                          ConfigXml::getIns()->getValue("Tutk", "UUID")));
       
        unsigned int uuid_ver = 0;
        IOTC_Get_Version(&uuid_ver);
        char buf[1024] = "\0";
        memset(buf,0,sizeof(buf));
        snprintf(buf, sizeof(buf), "0X%08X", uuid_ver);
        m_mpStrConf.insert(std::make_pair("Tutk_Ver",
                                          buf));
    }

    void HandleStatistics::GetMQReqRespStat()
    {
        return ;
    }

    void HandleStatistics::GetCurStartedStremStat()
    {
        if (m_pHttpServer == NULL)
        {
            return ;
        }

        for (auto it = m_pHttpServer->m_ClientSessionList.begin(); 
                it != m_pHttpServer->m_ClientSessionList.end(); ++it)
        {
            if (it->second == NULL)
            {
                continue;
            }
            //client => ip:port
            StreamInfo streamStat;
            streamStat.sDevCode = it->second->GetClientParentId();
            streamStat.sDevChannelId = it->second->GetClientDeviceCode();
            streamStat.sIpClientRcvStream = it->second->GetClientIp();
            streamStat.uiPortClientRcvStream = it->second->GetClientPort();
            streamStat.uiStreamRelayPort = it->second->GetClientLocalPort();
            m_mpStreamStat.insert(std::make_pair(it->first, streamStat));
        }
    }

    void HandleStatistics::GetCurAudioVideoStat()
    {
        if (m_pHttpServer == NULL)
        {
            return ;
        }

        std::map<std::string, AudioVideoClient>& avMpClient = m_pHttpServer->m_AudioVideoSession;
        for (auto it = avMpClient.begin(); it != avMpClient.end(); ++it)
        {
            AudioVideoInfo avClient;
            avClient.sDevCode = it->second.m_sDevCode;
            
            avClient.sIpDevRcvAudio = it->second.sIpDevRcvAudio;
            avClient.uiPortDevRcvAudio = it->second.uiPortDevRcvAudio;
            avClient.uiPortRelayAudioToDev = it->second.uiPortRelayAudioToDev;
           
            avClient.sIpClientRcvStream = it->second.sIpClientRcvStream;
            avClient.uiPortClientRcvStream = it->second.uiPortClientRcvStream;
            avClient.uiPortRelayVideoToClient = it->second.uiPortRelayVideoToClient;
           
            avClient.sIpClientRcvAudio = it->second.sIpClientRcvAudio;
            avClient.uiPortClientRecvAudio = it->second.uiPortClientRecvAudio;
            avClient.uiPortRelayAudioToClient = it->second.uiPortRelayAudioToClient;

            m_mpAudioVideoStat.insert(std::make_pair(it->first, avClient ));
        }
    }

    void HandleStatistics::GetClientNums()
    {
        //video preview client nums
        m_uiClientNums = m_mpStreamStat.size();
        //visible speak client nums
        m_uiClientNums += m_mpAudioVideoStat.size();
    }

    void HandleStatistics::GetSysWRBufLen()
    {
        //Take care: [ this software running on ubuntu, 
        //so just collection net.* param on this opsys ]
        for (auto it = m_mpWRBufLen.begin(); it != m_mpWRBufLen.end(); ++it)
        {
            it->second.RunSysStat();
        }
    }

    void HandleStatistics::GetNicStats()
    {
        for (auto it = m_mpNicStats.begin(); it != m_mpNicStats.end(); ++it)
        {
            it->second.NicStatRun();
        }
    }

    void HandleStatistics::GetCloudAVStats()
    {
        m_mpCloudAvStats.clear();
        for (auto it = m_pHttpServer->m_mpCloudAVSession.begin(); 
             it != m_pHttpServer->m_mpCloudAVSession.end(); ++it)
        {
            CloudAvStat cloudAvClient;
            cloudAvClient.m_sDevCode                =   it->second.m_sDevCode;
            cloudAvClient.sIpDevRecvAudio           =   it->second.sIpDevRecvAudio;
            cloudAvClient.uiPortDevRecvAudio        =   it->second.uiPortDevRecvAudio;
            cloudAvClient.uiPortMtsRelayAudioToApp  =   it->second.uiPortMtsRelayAudioToApp;
            cloudAvClient.uiPortMtsRelayVideoToApp  =   it->second.uiPortMtsRelayVideoToApp;

            m_mpCloudAvStats.insert(std::make_pair(it->second.m_sDevCode, cloudAvClient));
        }
    }

    void HandleStatistics::GetUuidIpList()
    {
        m_mpUuidVIp.clear();
        struct st_LanSearchInfo psLanSearchInfo[100];
        int nDeviceNum = IOTC_Lan_Search(psLanSearchInfo,100, 100);
        for ( int iIndex = 0; iIndex < nDeviceNum; ++iIndex )
        {
            char *pSUUID = psLanSearchInfo[iIndex].UID;
            char *psUUIDDevIp = psLanSearchInfo[iIndex].IP;

            if (strlen(pSUUID) == 0)
            {
                LOG_INFO_("seach lan dev uuid is empty");
                continue;
            }
            LOG_DEBUG_("seach uuid: %s", pSUUID);
            
            if (strlen(psUUIDDevIp) == 0)
            {
                LOG_INFO_("seach lan dev ip is empty");
                continue;
            }
            LOG_DEBUG_("search uuid dev ip: %s", psUUIDDevIp);
            
            auto itUUIDIpList = m_mpUuidVIp.find(pSUUID); 
            if (itUUIDIpList == m_mpUuidVIp.end())
            {
                std::vector<std::string> vDevIp;
                vDevIp.push_back(psUUIDDevIp);
                m_mpUuidVIp[pSUUID] = vDevIp;
            }
            else 
            {
                m_mpUuidVIp[pSUUID].push_back(psUUIDDevIp);
            }
        }
        LOG_INFO_("has search uuid dev nums: %d in lan", nDeviceNum);
    }

    //----------------------- SysWRBufStat implement ---------------------------//
    bool SysWRBufStat::RunSysStat()
    {
        if (sStatName.empty())
        {
            return false;
        }

        std::string sStatCmd ; 
        sStatCmd.append("/sbin/sysctl ");
        sStatCmd.append(sStatName);
        LOG_DEBUG_("cmd: %s", sStatCmd.c_str());
        
        SysWRBufStat::SysCmd oneCmd;
        int iRet = oneCmd.RunCmd(sStatCmd);
        if (iRet < 0)
        {
            LOG_INFO_("fail, run cmd: %s, iRet: %d", sStatCmd.c_str(), iRet);
            return false;
        }

        iStatNums = iRet;
        return true;
    }

    int32_t SysWRBufStat::SysCmd::RunCmd(const std::string& sCmd)
    {
        if (sCmd.empty())
        {
            return -1;
        }
        fp = popen(sCmd.c_str(), "r");
        if (NULL ==  fp)
        {
            LOG_INFO_("run popen(%s) fail, err msg: %s", sCmd.c_str(), strerror(errno));
            return -2;
        }

        char buf[1024];
        std::string sRead;

        memset(buf,0,sizeof(buf));
        while(fgets(buf, sizeof(buf), fp) != NULL)
        {
            sRead.append(buf);
            memset(buf,0,sizeof(buf));
        }
        
        if (sRead.empty())
        {
            return -3;
        }

        auto MTS_Split = [] (const std::string& sSrc, const std::string& sDelim, 
                                     std::vector<std::string>& vOutData)
        {
            size_t last = 0;
            size_t index= sSrc.find_first_of(sDelim, last);
            while (index != std::string::npos) 
            {
                vOutData.push_back(sSrc.substr(last, index-last));
                last = index + 1;
                index = sSrc.find_first_of(sDelim, last);
            }           
            if (index - last > 0) 
            {
                vOutData.push_back(sSrc.substr(last,index-last)); 
            }           
            return true;
        };

        std::vector<std::string> vData;
        if (false == MTS_Split(sRead, "=", vData))
        {
            return -4;
        }
        if (vData.size() <=1)
        {
            return -5;
        }
        return ::atoi(vData[1].c_str());
    }
    
    //---------------------------- NICStat::NicCmd implement ----------------------//
    bool NICStat::NicCmd::RunNicCmd(int iNicOpt, struct ifreq& inIfReq)
    {
        if (iNicOpt < 0)
        {
            return false;
        }
        if (m_iSock < 0)
        {
            m_iSock = ::socket(AF_INET, SOCK_DGRAM, 0); 
            if (m_iSock < 0)
            {
                return false;
            }
        }

        if (ioctl(m_iSock, iNicOpt, &inIfReq) < 0)
        {
            LOG_ERROR_("ioctl() err, err_msg: %s", strerror(errno));
            return false;
        }

        return true;
    }

    bool NICStat::NicCmd::GetAllNicName(std::vector<std::string>& nicNameList)
    {
        int iSock = 0;
        struct ifreq ifVec[100];
        iSock = ::socket(AF_INET, SOCK_DGRAM, 0);
        if (iSock < 0)
        {
            return false;
        }

        struct ifconf ioIfConf;
        ioIfConf.ifc_len = sizeof(ifVec);
        ioIfConf.ifc_req = ifVec;

        if (ioctl(iSock, SIOCGIFCONF, &ioIfConf) < 0 )
        {
            close(iSock);
            return false;
        }

        struct ifreq *ifPt, *ifEndPt;
        ifPt = ioIfConf.ifc_req ;
        ifEndPt = ifVec + ioIfConf.ifc_len /sizeof(struct ifreq);

        for (; ifPt < ifEndPt; ifPt++)
        {
            if (ifPt->ifr_addr.sa_family != AF_INET)
            {
                continue;
            }

            if (memcmp(ifPt->ifr_name, "lo", sizeof("lo")) == 0)
            {
                continue;
            }
            nicNameList.push_back(ifPt->ifr_name);
        }
        close(iSock);
        return true;
    }

    //----------------------------- NICStat implement ---------------------------//
    bool NICStat::NicStatRun()
    {
        NicCmd instanceNicCmd;
        
        struct ifreq txquereq;
        memset(&txquereq, 0, sizeof(struct ifreq));
        memcpy(txquereq.ifr_name, sNicName.c_str(), sNicName.size());

        if (instanceNicCmd.RunNicCmd( SIOCGIFTXQLEN, txquereq ) == false)
        {
            LOG_ERROR_("run nic cmd fail");
        }
        else 
        {
            iTxQueLen = txquereq.ifr_qlen;
        }

        memset(&txquereq,0,sizeof(struct ifreq));
        //++ other items;
        return true;
    }

    void NICStat::GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc)
    {
        //format: {"a":1, "b":2, "c":"iea"}  
        jsonObj.AddMember(rapidjson::StringRef(sTxQueName.c_str()),iTxQueLen, alloc);
        //++ other items;
    }


    //--------------------- cloud speak stat implement ------------------//
    CloudAvStat::CloudAvStat()
    {
    }
    CloudAvStat::~CloudAvStat()
    {
    }
    void CloudAvStat::GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc)
    {
        rapidjson::Value oneItem;
        oneItem.SetString( m_sDevCode.c_str(), m_sDevCode.length(), alloc );
        jsonObj.AddMember( "DevCode", oneItem, alloc );

        oneItem.SetString( sIpDevRecvAudio.c_str(), sIpDevRecvAudio.length(), alloc );
        jsonObj.AddMember( "DevRcvAudioIp", oneItem, alloc );

        jsonObj.AddMember( "DevRcvAudioPort", uiPortDevRecvAudio, alloc );

        jsonObj.AddMember( "MtsRelayAudioToAppPort", uiPortMtsRelayAudioToApp, alloc );
        jsonObj.AddMember( "MtsRelayVideoToAppPort", uiPortMtsRelayVideoToApp, alloc );
    }
}
