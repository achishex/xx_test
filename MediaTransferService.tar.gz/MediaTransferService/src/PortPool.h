///////////////////////////////////////////////////////////////
//
// FileName : PortPool.h
// Creator  : fan
// Date     : 2017-12-13
// Comment  : 
//
///////////////////////////////////////////////////////////////
#ifndef _STREAM_COMMON_PORT_H_
#define _STREAM_COMMON_PORT_H_
//#include "HD_Mutex.h"
#include <pthread.h>
#include <list>
#include <map>
#include <string>
#include <vector>
#include "configXml.h"
using namespace std;


class PortPool 
{
public:
	PortPool();
	~PortPool();

	static PortPool* GetInstance()
	{	
		static PortPool* instance_ = 0;	
		if(!instance_)
		{
			instance_ = new PortPool();
		}		
		return instance_;	
	}
	
	void InitPortPool(unsigned short nTcpPortBase, unsigned short nTcpPortCount, unsigned short nUdpPortBase, unsigned short nUdpPortCount);
	unsigned short GetTcpPort();
	unsigned short GetUdpPort();
	unsigned short GetAndCheckTcpPort(int iCycleCount = 10);
	unsigned short GetAndCheckUdpPort(int iCycleCount = 10);
	void ReleaseTcpPort(unsigned short nPort);
	void ReleaseUdpPort(unsigned short nPort);
	//static PortPool* instance_;
public:
	map<string, vector<int> > m_mapDevecePort; //设备编码和端口的映射

private:
    void NoLogReleaseUdpPort(unsigned short nPort); 

private:
	unsigned short m_nTcpPortBase;
	unsigned short m_nTcpPortCount;
	unsigned short m_nUdpPortBase;
	unsigned short m_nUdpPortCount;
    std::list<unsigned short> m_listTcpPortPool;
    std::list<unsigned short> m_listUdpPortPool;
	//HPR_Mutex m_iTcpPortPoolLock;
	//HPR_Mutex m_iUdpPortPoolLock;
	pthread_mutex_t m_iTcpPortPoolLock; 
	pthread_mutex_t m_iUdpPortPoolLock; 
	
	bool m_bInit;
};

#endif
