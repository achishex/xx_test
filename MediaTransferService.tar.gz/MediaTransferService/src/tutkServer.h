///////////////////////////////////////////////////////////////
//
// FileName : tutkServer.h
// Creator : chenbo
// Date : 2018-2-24 
// Comment :
//
///////////////////////////////////////////////////////////////

#ifndef _TUTK_SERVER_H_
#define _TUTK_SERVER_H_

#include <atomic>
#include "common.h"
#include "tutk/IOTCAPIs.h"
#include "tutk/AVAPIs.h"
#include "tutk/P2PCam/AVFRAMEINFO.h"
#include "tutk/P2PCam/AVIOCTRLDEFs.h"

#define TUTK_MAX_CLIENT_NUMBER	        128
#define TUTK_SERVTYPE_STREAM_SERVER     0
#define TUTK_MAX_AV_CHANNEL_NUMBER	    16
#define TUTK_MAX_SIZE_IOCTRL_BUF		1024
#define AUDIO_FORMAT_PCM  
#define MAX_IP_LEN 64

#ifdef  AUDIO_FORMAT_PCM
#define AUDIO_FRAME_SIZE 640
#define AUDIO_FPS 25
#define AUDIO_CODEC 0x8C
#endif

typedef struct AV_CLIENT
{
    int  nClientSid;
    int  nSpeakerCh;
    int  nAVIndex;
    bool bEnableAudio;
    bool bEnableVideo;
    bool bEnableSpeaker;
    char chSpeakSendToIp[MAX_IP_LEN];
    int  nSpeakSendToPort;
    int  nVideoDataLogNum;
    int  nAudioDataLogNum;
    AV_CLIENT()
    {
        nClientSid = -1;
        nSpeakerCh = -1;
        nAVIndex = -1;
        bEnableAudio = false;
        bEnableVideo = false;
        bEnableSpeaker = false;
        memset(chSpeakSendToIp, 0, sizeof(char)*MAX_IP_LEN);
        nSpeakSendToPort = 0;
        nVideoDataLogNum = 0;
        nAudioDataLogNum = 0;
    }
    AV_CLIENT(const AV_CLIENT& other)
    {
        nClientSid = other.nClientSid;
        nSpeakerCh = other.nSpeakerCh;
        nAVIndex = other.nAVIndex;
        bEnableAudio = other.bEnableAudio;
        bEnableVideo = other.bEnableVideo;
        bEnableSpeaker = other.bEnableSpeaker;
        strncpy(chSpeakSendToIp, other.chSpeakSendToIp, MAX_IP_LEN-1);
        nSpeakSendToPort = other.nSpeakSendToPort;
        nVideoDataLogNum = 0;
        nAudioDataLogNum = 0;
    }
    AV_CLIENT& operator = (const AV_CLIENT& other)
    {
        if (this != &other)
        {
            nClientSid = other.nClientSid;
            nSpeakerCh = other.nSpeakerCh;
            nAVIndex = other.nAVIndex;
            bEnableAudio = other.bEnableAudio;
            bEnableVideo = other.bEnableVideo;
            bEnableSpeaker = other.bEnableSpeaker;
            strncpy(chSpeakSendToIp, other.chSpeakSendToIp, MAX_IP_LEN-1);
            nSpeakSendToPort = other.nSpeakSendToPort;
            nVideoDataLogNum = other.nVideoDataLogNum;
            nAudioDataLogNum = other.nAudioDataLogNum;
        }
        return *this;
    }
}AV_Client;

typedef struct AV_CLIENT_DST
{
    char chSpeakSendToIp[MAX_IP_LEN];
    int  nSpeakSendToPort;
}AV_Client_Dst;

typedef  map<int , AV_Client>  AVClientMap;
typedef	typename map<int, AV_Client>::iterator iterAVClientMap;

typedef  map<string, AVClientMap>  ServerLinkMap;//<devUUID, stClinetInfo> 设备编号跟 客户端的编号
typedef typename  map<string, AVClientMap>::iterator  iterServreLink;

typedef  map<string , AV_Client_Dst>  AVClientDstMap;
typedef typename  map<string, AV_Client_Dst>::iterator  iterClientDst;

class CTutkServer;
class ReConnRelayNode
{
 public:

  /**
   * @brief: ReConnRelayNode 
   *
   * @param pTutkSrv
   *     tutksrv handle, 
   * @param iTimerTm
   *      tms login tutk 线程的工作时间间隔。
   *      如果检测已经登录，则检测的时间间隔为 iTimerTm *2 
   *      如果检测未登录，下次检测时间间隔为 iTimerTm
   */
  ReConnRelayNode(CTutkServer* pTutkSrv, int32_t iTimerTm = 10);
  virtual ~ReConnRelayNode();
 

  /**
   * @brief: StartLoginCheck 
   *      创建并启动检测线程
   * @return 
   *     true: 创建并启动成功； false: 失败
   */
  bool StartLoginCheck();

  /**
   * @brief: StopLoginCheck 
   *    停止检测线程工作
   * @return 
   *    无返回
   */
  void  StopLoginCheck();


  /**
   * @brief: GetReConnRelayNode 
   *    提供ReConnRelayNode* 句柄接口 
   *    注意:该接口返回的是从堆上申请的资源，需要调用外部接口释放
   *
   * @param pTutkSrv
   *     tutkserver 句柄
   * @param iTimerTm
   *    线程工工作时间间隔
   *
   * @return 
   *     句柄
   */
  static ReConnRelayNode* GetReConnRelayNode(CTutkServer* pTutkSrv, int32_t iTimerTm);
  const std::atomic<bool> &GetRunStatus() const 
  {
      return m_bIsRun;
  }
  const int32_t& GetCheckInterTm() const 
  {
      return m_iCheckTms;
  }
  const pthread_t& GetCheckPthreadId() const 
  {
    return m_Tid;
  }
 private:
  static void*  CheckCallBack(void* pNode);
 private:

  /**
   * @brief: TimerCheckLoginTutk 
   *    检测mts 和 tutk服务的连接状态.
   *    调用 CTutkServer接口
   * @return 
   *    > 0 : mts login tutk ok
   *    == 0: mts disconn tutk 
   *    < 0 : call tutk api error.
   */
  int32_t TimerCheckLoginTutk();

  /**
   * @brief: ReLoginTutk 
   *     重新连接tutk 服务.
   *     调用 CTutkServer接口
   * @return 
   *     true: login succ.
   *     false: login fail
   */
  bool ReLoginTutk();

 private:
  CTutkServer* m_pTutkSrv;
  pthread_t  m_Tid;
  std::atomic<bool> m_bIsRun;
  int32_t m_iCheckTms;
};

class CTutkServer : public singleton_T<CTutkServer>
{
public:

	CTutkServer();
	~CTutkServer();
public:
    //初始化Tutk
	int Init(const string& strUUID);

    /**
     * @brief: DevLogin 
     *  实现媒体服务登录tutk远程服务
     * @param strUUID
     *   媒体服务使用的tutk。注意: 一定要保证每个媒体服务使用的uuid 唯一性。
     *   否则会出现和app连接异常结果
     * @return 
     *   true: 登录成功； false: 登录失败
     */
    bool DevLogin(const string& strUUID);  

    /**
     * @brief: TutkTimerCheckLogin 
     *     检测mts 登录 tutk服务的状态
     * @return 
     *    > 0 : mts login tutk ok
     *    == 0: mts disconn tutk 
     *    < 0 : call tutk api error.
     */
    int32_t TutkTimerCheckLogin();

    /**
     * @brief: SrvReLoginTutk 
     *    mts 重新登入tutk 服务接口
     * @return 
     *     true: login succ.
     *     false: login fail
     */
    bool SrvReLoginTutk();

    int Fini() ;
    //int Restart(string& strUUID);
    void SendFrameData(string& strDevUUID, char* pchDataBuf, int nBufLen);
    void SendAudioData(string& strDevUUID, char* pchDataBuf, int nBufLen);

    void DelServerLinkInfo(string& strDevUUID, int iSid);
    int  GetLinkInfoBySID(AV_Client& stClientOut, string& strDevUUID, int iSid);
    void UpdateLinkInfoBySID(string& strDevUUID, AV_Client& stClinetInfo, int iSid);
    
    void UpdateClientDstInfoByDevUUID(string& strDevUUID, string& strIp, int iPort);
    int  GetClientDstInfoByDevUUID(AV_Client_Dst& stClientDstOut, string& strDevUUID);

    //bool CreateAudioRecver(int AV_Channel_ID, AV_Client& client);
    void ClearServerLinkInfo(string& strDevUUID);
    void ClearDstInfo(string& strDevUUID);
    bool m_bIsRuning;
protected:
    friend void  Handle_IOCTRL_Cmd(int nSID, int nAVIndex, char* pchBuf, int nType);
    
private:
    pthread_t m_pthListenThreadID;
    
	pthread_mutex_t m_iServerLinkLock; 
	pthread_mutex_t m_iClientDstLock; 

    ServerLinkMap  m_mapServerLink;//<devUUID, stClinetInfo> 设备编号跟 客户端的编号
    AVClientDstMap m_mapClientDst;
    int m_iLogFrameNum ;
    int m_iLogVoiceNum ;

private:
    ReConnRelayNode* m_pTutkReconn;
    std::string m_sUUID;
    std::atomic<bool> m_bAtomicInit;
};

#endif
