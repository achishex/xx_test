///////////////////////////////////////////////////////////////
//
// FileName : deviceCall.cpp
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : deviceCall source file
//
///////////////////////////////////////////////////////////////

#include "handleDeviceCall.h"


HandleDeviceCall::HandleDeviceCall()
  : m_pUdpPortPool( NULL )
  , m_iClientPort( 0 )
  , m_iRecvClientVoicePort( 0 )
  , m_iRecvDevVoicePort( 0 )
  , m_bReplyStatus( false )
  , m_pHttpServer( NULL )
{
    //...
}

HandleDeviceCall::~HandleDeviceCall()
{
    //...
}

void HandleDeviceCall::init(std::string& urldata, HttpServer* httpserver)
{
    m_urlData = urldata;
    m_pHttpServer = httpserver;
    if( NULL == httpserver )
    {
        LOG_ERROR_("httpserver is null") ;
        return ;
    }
    m_pUdpPortPool = httpserver->GetPortPool();
    m_bReplyStatus = false ;
}

void HandleDeviceCall::deal(const char *peerIp)
{
    m_bReplyStatus = this->decodeHttpData(peerIp) ;
    if(  m_bReplyStatus == false )
    {
		WriteHttpReqTraceLog(m_urlData, "ERROR", "/voice/require");
        return ;
    }

    if ( NULL == m_pUdpPortPool )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("m_pUdpPortPool is null") ;
        return ;
    }

    //设备编码被占用就返回
    map<string,vector<int>>::iterator it ;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it != m_pUdpPortPool->m_mapDevecePort.end())
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("devicecode:%s been used. msgtag:%s", m_sDeviceCode.c_str(), GetMsgTag().c_str());
        return ;
    }
    // 从端口池获取端口
    m_iRecvClientVoicePort = m_pUdpPortPool->GetAndCheckUdpPort();
    LOG_INFO_("get RecvClientVoicePort:%d. msgtag:%s", m_iRecvClientVoicePort, GetMsgTag().c_str());
    if(m_iRecvClientVoicePort < m_iUdpPortStart || m_iRecvClientVoicePort > (m_iUdpPortStart + m_iUdpPortSize*2) )
    {	
		LOG_ERROR_("GetAndCheckUdpPort fail. RecvClientVoicePort:%d illegal. msgtag:%s", m_iRecvClientVoicePort, GetMsgTag().c_str());
		WriteMonitorLog("GetUdpPortFail", "/voice/require get voice udp port fail. deviceCode:"+GetMsgTag());
        return;
    }
    m_iRecvDevVoicePort = m_pUdpPortPool->GetAndCheckUdpPort();
    LOG_INFO_("get RecvDevVoicePort:%d. msgtag:%s", m_iRecvDevVoicePort, GetMsgTag().c_str());
    if(m_iRecvDevVoicePort < m_iUdpPortStart || m_iRecvDevVoicePort > (m_iUdpPortStart + m_iUdpPortSize*2) )
    {
		LOG_ERROR_("GetAndCheckUdpPort fail. RecvDevVoicePort:%d illegal. msgtag:%s", m_iRecvDevVoicePort, GetMsgTag().c_str());
		WriteMonitorLog("GetUdpPortFail", "/voice/require get voice udp port fail. deviceCode:"+GetMsgTag());
        return;
    }

	// ???
    if(m_iRecvClientVoicePort==0 || m_iRecvDevVoicePort==0)
    {
        return;
    }
    //  创建发送给udpserver的消息,通知udpserver创建视频监听服务
    pS_clientToIPCMsg portmessage = new S_clientToIPCMsg(m_sClientIp, m_iClientPort, m_iRecvDevVoicePort, VOICEVIDEO_START, GetMsgTag());
    if(NULL == portmessage)
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("creat portmessage error ,out of memory. msgtag:%s", GetMsgTag().c_str());
        return ;
    }

    LOG_INFO_("send VOICEVIDEO_START to udp server.dev receive internal port:%d,dev receive voiceIP:%s, dev receive voicePort:%d, msgtag:%s" 
    				, m_iRecvDevVoicePort
    				, m_sClientIp.c_str()
    				, m_iClientPort
    				, GetMsgTag().c_str());

	string logbody="push stream from port:"+std::to_string(m_iRecvDevVoicePort)+" to client "+m_sClientIp+":"+std::to_string(m_iClientPort)+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/voice/require");
	
    UdpClient udpclient;
    int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("send VOICEVIDEO_START to udp server error.dev receive internal port:%d, msgtag:%s", m_iRecvDevVoicePort, GetMsgTag().c_str());
        return ;
    }

    vector<int> vec;
    vec.push_back(m_iRecvDevVoicePort);
    vec.push_back(m_iRecvClientVoicePort);
    m_pUdpPortPool->m_mapDevecePort.insert(pair<string,vector<int> >(m_sDeviceCode, vec));

    m_bReplyStatus = encodeHttpData();
    if(m_bReplyStatus == false )
    {
        LOG_ERROR_("encodeHttpData error.msgtag:%s", GetMsgTag().c_str()) ;
        return ;
    }

    //just audio only  exist in client and dev.
    AudioVideoClient clientAV;
    clientAV.m_sDevCode                 = m_sDeviceCode;
    clientAV.sIpClientRcvAudio          = m_sClientIp;
    clientAV.uiPortClientRecvAudio      = m_iClientPort;
    clientAV.uiPortRelayAudioToClient   = m_iRecvDevVoicePort;
    
    //dev ip and port op in next step.
    clientAV.uiPortRelayAudioToDev      = m_iRecvClientVoicePort;
    m_pHttpServer->m_AudioVideoSession.insert(std::make_pair( m_sDeviceCode, clientAV ));
    m_bReplyStatus = true ;
}

bool HandleDeviceCall::encodeHttpData()
{
    Document doc;
    doc.SetObject();
    Document::AllocatorType &allocator = doc.GetAllocator(); //获取分配器

    doc.AddMember("errMsg", "success!", allocator);
    doc.AddMember("success", true, allocator);

    rapidjson::Value info_object(rapidjson::kObjectType);

    rapidjson::Value author;
    char buf[64];
    string sServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");
    int len = sprintf(buf, "%s", sServerIp.c_str()); //动态创建的字符串。
    author.SetString(buf, len, allocator);
    info_object.AddMember( "reClientVoiceip", author, allocator);
    info_object.AddMember( "reClientVoicePort", m_iRecvClientVoicePort, allocator);

    author.SetString(buf, len, allocator);
    info_object.AddMember( "reDevVoiceip", author, allocator);
    info_object.AddMember( "reDevVoicePort", m_iRecvDevVoicePort , allocator);

    const std::string&  sIpMtsHttp = HandleBase::GetMTSHttpIp();
    author.SetString(sIpMtsHttp.c_str(), sIpMtsHttp.size(), allocator);
    info_object.AddMember( "mtsIp", author, allocator);
    info_object.AddMember( "mtsPort", HandleBase::GetMTSHttpPort(), allocator);
    
    bzero(buf, sizeof(buf));

    doc.AddMember("data", info_object, allocator);

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    doc.Accept(writer);
    //log.info("respond to http: %s", buffer.GetString());

    m_bReplyStatus = true ;
    return true;
}

bool HandleDeviceCall::decodeHttpData(const char *peerIp)
{
	LOG_INFO_("http req:%s", m_urlData.c_str());
    if ( m_urlData.empty() )
    {
        LOG_ERROR_("m_urlData is empty ") ;
        return false;
    }

    rapidjson::Document document;
    document.Parse<0>(m_urlData.c_str());
    if( document.HasParseError() )
    {
        // 报错
        LOG_ERROR_("urlData: %s", m_urlData.c_str());
        return false;
    }

    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {
		LOG_ERROR_("http req parse deviceCode error.") ;
        return false ;
    }
    m_sDeviceCode = document["deviceCode"].GetString();

    //assert(document.IsObject());
    if( !document.HasMember("clientIp") || !document["clientIp"].IsString() )
    {
		LOG_ERROR_("http req parse clientIp error. msgtag:%s", m_sDeviceCode.c_str()) ;
        return false ;
    }
    m_sClientIp = document["clientIp"].GetString();


    if( !document.HasMember("clientPort") || !document["clientPort"].IsInt() )
    {
		LOG_ERROR_("http req parse clientPort error. msgtag:%s", m_sDeviceCode.c_str()) ;
        return false ;
    }
    m_iClientPort = document["clientPort"].GetInt();


	SetMsgTag(m_sDeviceCode);

	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {
		traceId = document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);
		InitUdpLogBase(traceId, spanId, _peerIp);
	}

    m_bReplyStatus =true ;
    LOG_INFO_("http req parse OK. url:%s, deviceCode:%s, clientIp:%s, clietPort:%d, msgtag:%s"
    					, "/voice/require"
    					, m_sDeviceCode.c_str()
						, m_sClientIp.c_str()
						, m_iClientPort
						, GetMsgTag().c_str()
    					);

    WriteTraceLogInternal(m_urlData, "INFO", "/voice/require");
    return true;
}

void HandleDeviceCall::getReplyData(string& replydata)
{
    replydata = "";
    if( "" == m_replydata)
    {
        replydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
    else
    {
        replydata = m_replydata;
    }

	string logbody="HttpRsp:"+replydata+", msgtag:"+GetMsgTag();
    LOG_INFO_(logbody.c_str());
    WriteHttpRspTraceLog(logbody, "INFO", "/voice/require");
}

HandleDeviceIntercall::HandleDeviceIntercall()
  : m_pUdpPortPool( NULL )
  , m_iDevicePort( 0 )
  , m_iRecvClientVoicePort( 0 )
  , m_pHttpServer( NULL )
{
    //...
}

HandleDeviceIntercall::~HandleDeviceIntercall()
{
    //...
}

void HandleDeviceIntercall::init(std::string& urldata, HttpServer* httpserver)
{
    m_pHttpServer = httpserver;
    m_urlData = urldata;
    m_pUdpPortPool = httpserver->GetPortPool();
    //m_iRecvClientVoicePort = localPort;
}

void HandleDeviceIntercall::deal(const char *peerIp)
{
    if (NULL == m_pUdpPortPool )
    {
        LOG_ERROR_("m_pUdpPortPool is null") ;
        return ;
    }

    if (decodeHttpData(peerIp) == false )
    {
		WriteHttpReqTraceLog(m_urlData, "ERROR", "/voice/start");
        return ;
    }


    map<string,vector<int> > ::iterator it;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it == m_pUdpPortPool->m_mapDevecePort.end())
    {
		string logbody="device not found. msgtag:" + m_sDeviceCode;
        LOG_ERROR_(logbody.c_str());
		WriteTraceLogInternal(logbody, "ERROR", "/voice/start");
        return ;
    }
    vector<int> vecport = m_pUdpPortPool->m_mapDevecePort[m_sDeviceCode] ;
    m_iRecvClientVoicePort = vecport[1];

    //log.info("m_iRecvClientVoicePort=%d",m_iRecvClientVoicePort);

    // 创建发送给udpserver的消息,通知udpserver创建视频监听服务
    pS_clientToIPCMsg portmessage = new S_clientToIPCMsg(m_sDeviceIp, m_iDevicePort, m_iRecvClientVoicePort, VOICEVIDEO_START, GetMsgTag());
    if(NULL == portmessage)
    {
        LOG_ERROR_("creat portmessage error ,out of memory. msgtag:%s", GetMsgTag().c_str());
        return ;
    }

    LOG_INFO_("send VOICEVIDEO_START to udp server.dev receive internal port:%d,dev receive voiceIP:%s, dev receive voicePort:%d, msgtag:%s" 
    				, m_iRecvClientVoicePort
    				, m_sDeviceIp.c_str()
    				, m_iDevicePort
    				, GetMsgTag().c_str());

	string logbody="push stream from port:"+std::to_string(m_iRecvClientVoicePort)+" to client "+m_sDeviceIp+":"+std::to_string(m_iDevicePort)+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/voice/start");
	
    UdpClient udpclient;
    int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        LOG_ERROR_("send VOICEVIDEO_START to udp server error.dev receive internal port:%d, msgtag:%s", m_iRecvClientVoicePort, GetMsgTag().c_str());
        return ;
    }

    vector<int> vec;
    vec.push_back(m_iRecvClientVoicePort);
    m_pUdpPortPool->m_mapDevecePort.insert(pair<string,vector<int> >(m_sDeviceCode, vec));

    m_replydata = "{\"errMsg\": \"success!\", \"success\": true}";
	
    //update dev ip/port for audio.
    auto itAv = m_pHttpServer->m_AudioVideoSession.find(m_sDeviceCode);
    if (itAv != m_pHttpServer->m_AudioVideoSession.end())
    {
        itAv->second.sIpDevRcvAudio    = m_sDeviceIp;
        itAv->second.uiPortDevRcvAudio = m_iDevicePort;
    }
}

bool HandleDeviceIntercall::decodeHttpData(const char *peerIp)
{
	LOG_INFO_("http req:%s", m_urlData.c_str());
    if ( m_urlData.empty() )
    {
        return false;
    }

    Document document;
    document.Parse<0>(m_urlData.c_str());
    if( document.HasParseError() )
    {
        // 报错
        LOG_INFO_("parse error, urldata: %s", m_urlData.c_str());
        return false;
    }

    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {
		LOG_ERROR_("http req parse deviceCode error.") ;
        return false ;
    }
    m_sDeviceCode = document["deviceCode"].GetString();

    if( !document.HasMember("deviceIp") || !document["deviceIp"].IsString() )
    {
		LOG_ERROR_("http req parse deviceIp error. msgtag:%s", m_sDeviceCode.c_str()) ;
        return false ;
    }
    m_sDeviceIp = document["deviceIp"].GetString();

    if( !document.HasMember("devicePort") || !document["devicePort"].IsInt() )
    {
		LOG_ERROR_("http req parse devicePort error. msgtag:%s", m_sDeviceCode.c_str()) ;
        return false ;
    }
    m_iDevicePort = document["devicePort"].GetInt();

	SetMsgTag(m_sDeviceCode);

	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {
		traceId = document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);
		InitUdpLogBase(traceId, spanId, _peerIp);
	}

    LOG_INFO_("http req parse OK. url:%s, deviceCOde:%s, deviceIp:%s, devicePort:%d, msgtag:%s"
    					, "/voice/start"
    					, m_sDeviceCode.c_str()
						, m_sDeviceIp.c_str()
						, m_iDevicePort
						, GetMsgTag().c_str()
    					);

    WriteTraceLogInternal(m_urlData, "INFO", "/voice/start");
    return true;
}

void HandleDeviceIntercall::getReplyData(string& replydata)
{
    replydata = "";
    if( "" == m_replydata)
    {
        replydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
    else
    {
        replydata = m_replydata;
    }
	
	string logbody="HttpRsp:"+replydata+", msgtag:"+GetMsgTag();
    LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/voice/start");
}

