//---------------------------------------------------------------------------
//
// FileName : udpServerEventBase.cpp
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : udpServerEventBase source file
//
//---------------------------------------------------------------------------

#include "udpServerEventBase.h"
#include <event2/thread.h>
#include "log.h"
#include <cassert>
//---------------------------------------------------------------------------
UdpServerEventBase::UdpServerEventBase( const int id )
  : m_id( id )
  , m_base( NULL )
{
    m_base  =  event_base_new();
    LOG_NOTICE_( "[%d] event_base_new %p",  id,  m_base ) ;
    assert( m_base  !=  NULL );

    evthread_make_base_notifiable( m_base ) ;
}
//---------------------------------------------------------------------------
UdpServerEventBase::~UdpServerEventBase()
{
//    if ( m_base )
//    {
        event_base_loopbreak( m_base );
        LOG_NOTICE_("UdpServerEventBase stop loop");
        event_base_free( m_base );
//    }
}
//---------------------------------------------------------------------------
void timeout_cb(int fd, short event, void *arg)
{
    struct timeval tv{86400, 0};
    event_add((struct event*)arg, &tv);
}
//---------------------------------------------------------------------------
int UdpServerEventBase::run()
{
    struct event timeout;
    event_assign(&timeout, m_base, -1, 0, timeout_cb, (void*)&timeout);
    // evtimer_set(&timeout, timeout_cb, (void*)&timeout);

    struct timeval tv{86400, 0};
    event_add(&timeout, &tv);

    LOG_NOTICE_("workPthread (UdpEventBase): %02d start loop", m_id);

    event_base_dispatch( m_base );

    return 0;
}
//---------------------------------------------------------------------------
