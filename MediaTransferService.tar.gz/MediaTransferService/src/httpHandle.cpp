///////////////////////////////////////////////////////////////
//
// FileName : http_handle.cpp
// Creator  : fan
// Date     : 2017-12-13
// Comment  : handle_stream_start source file
//
///////////////////////////////////////////////////////////////

#include "httpHandle.h"
#include <sstream>
#include <log.h>
#include <memory>
/**********
***@brief sendMSGtoUDPServer()向ＵＤＰserver发送客户端信息
***@param status　０　关闭端口　　１　开端口收流
***@return bool
***@remark
**********/
std::string HandleBase::m_stMTSHttpIp = "";
int HandleBase::m_stMTSHttpPort = 0;

static bool sendMSGtoUDPServer( string clientip, int clientport, string deviceCode, int localport, E_ClientRquestType status, string serverip , int serverport )
{
    //创建UDP消息发送给UDP服务
    pS_clientToIPCMsg portmessage = new S_clientToIPCMsg(clientip, clientport, localport, status, deviceCode);
    //portmessage->display();

    UdpClient  udpclient;
    int rec = udpclient.sendTo(serverip, serverport, (void*)portmessage, sizeof(S_clientToIPCMsg));
    if(rec < 0)
    {
        LOG_ERROR_("send Video portmessage error");
        return false;
    }

    return true;
}

/**********
***@brief receiveDataParse()生产客户端 保存客户端信息
***@param urldata http请求的数据
***@return bool
***@remark
**********/
static bool receiveDataParse(std::string& urldata, ClientSession* pClientSession, HandleBase *base, const char *peerIp)
{
    //创建客户端存储客户消息
    LOG_INFO_("http req:%s", urldata.c_str());
    if (pClientSession == NULL)
    {
        LOG_ERROR_(" ClientSession is NULL");
        return false;
    }

    if(urldata.empty())
    {
        LOG_ERROR_("urldata is NULL");
        return false;
    }

    //解析json
    rapidjson::Document document;
    try{
        document.Parse<0>(urldata.c_str());
        if( document.HasParseError() )
        {

            LOG_ERROR_("document.Parse error ") ;
            return false ;
        }
    }
    catch(exception& e)
    {
        LOG_ERROR_("parse json error %s",  e.what());
        return false;
    }

    //获取客户端的通道编码
    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {

		LOG_ERROR_("http req parse deviceCode error") ;
        return false ;
    }
    string devicecode = document["deviceCode"].GetString();
    pClientSession->SetClientDeviceCode(devicecode) ;

    //获取客户端ip
    if( !document.HasMember("receiveIp") || !document["receiveIp"].IsString() )
    {

		LOG_ERROR_("http req parse receiveIp error. msgtag:%s", devicecode.c_str()) ;
        return false ;
    }
    string clientip = document["receiveIp"].GetString();
    pClientSession->SetClientIp(clientip);

	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {
		traceId = document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);

		base->InitUdpLogBase(traceId, spanId, _peerIp);
	}

    //获取客户端ｐｏｒｔ
    if( !document.HasMember("receivePort") || !document["receivePort"].IsInt() )
    {

		LOG_ERROR_("http req parse receivePort error. msgtag:%s_%s", devicecode.c_str(), clientip.c_str()) ;
        return false ;
    }
    int clientport = document["receivePort"].GetInt() ;
    pClientSession->SetClientPort(clientport) ;

	base->SetMsgTag(devicecode);
    //获取主子码流
    if( !document.HasMember("streamProfile") || !document["streamProfile"].IsInt() )
    {

		LOG_ERROR_("http req parse streamProfile error. msgtag:%s",base->GetMsgTag().c_str()) ;
        return false ;
    }
    int streamprofile = document["streamProfile"].GetInt();
    pClientSession->SetClientStreamProfileCode(streamprofile);


    //获取取设备编码
    if( !document.HasMember("parentID") || !document["parentID"].IsString() )
    {

		LOG_ERROR_("http req parse parentID error. msgtag:%s",base->GetMsgTag().c_str()) ;
        return false ;
    }
    string parentid=document["parentID"].GetString();
    pClientSession->SetClientParentId(parentid);

    return true;

}

string HandleBase::GetMsgTag()
{
	return m_msgtag;
}

void HandleBase::SetMsgTag(std::string &deviceCode)
{
	m_msgtag = deviceCode;
}

HandleBase::HandleBase()
{
	m_iUdpPortStart = atoi(ConfigXml::getIns()->getValue("PortPool", "udpPortStart").c_str());
	m_iUdpPortSize = atoi(ConfigXml::getIns()->getValue("PortPool", "udpPortSize").c_str());
    m_localInterchangePort = atoi(ConfigXml::getIns()->getValue("UdpServer", "udpServerPort").c_str());
    m_sServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp"); 
}

HandleStreamStart::HandleStreamStart()
  : m_pClient(NULL)
  , m_pHttpServer(NULL)
  , m_bReplyStatus( false )
{
    LOG_DEBUG_("HandleStreamStart() construct");
    //... rapidjson/d
}

HandleStreamStart::~HandleStreamStart()
{
    //...
}

void HandleStreamStart::init(std::string& urldata , HttpServer* httpserver)
{
    m_sReceiveData=urldata ;
    m_pHttpServer = httpserver ;
    m_bReplyStatus = false  ;
    m_pClient = new ClientSession();
    LOG_DEBUG_("HandleStreamStart::init");
}

/**********
***@brief getReplyData()获取ｈｔｔｐ返回数据
***@param replaydata
***@return void
***@remark
**********/
void HandleStreamStart::getReplyData(std::string& replaydata)
{
	string logbody;
    if(true == m_bReplyStatus)
    {
        ostringstream oss;
        string sPart ="}";
        replaydata ="{\"errMsg\": \"success!\", \"success\": true,\"localPort\":";
        oss << replaydata << m_pClient->GetClientLocalPort();
        oss << ",\"mtsIp\":" << "\"" << HandleBase::GetMTSHttpIp() << "\"";
        oss << ",\"mtsPort\":" << HandleBase::GetMTSHttpPort() << sPart << endl;
        replaydata = oss.str();
		logbody="httpRsp:"+replaydata+", msgtag:"+GetMsgTag();
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
		logbody="httpRsp:"+replaydata+", msgtag:"+GetMsgTag();
		delete m_pClient;
		m_pClient = NULL;
    }

	LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/streaming/start");
}

/**********
***@brief getSendToMQData()获取发送给MQ的数据
***@param mqdata 发送给MQ的数据
***@return void
***@remark
**********/
bool HandleStreamStart::getSendToMQData(std::string& ssendMQData)
{
    //获取ＭＱ相关参数配置
    string topic = ConfigXml::getIns()->getValue("RabbitMQ", "topic") ;
    string appID = ConfigXml::getIns()->getValue("RabbitMQ", "appID") ;
    string token = ConfigXml::getIns()->getValue("RabbitMQ", "token") ;
    //string  messageID = ConfigXml::getIns()->getValue("RabbitMQ", "messageID");
    int eventTypeID = atoi(ConfigXml::getIns()->getValue("RabbitMQ", "eventTypeID").c_str()) ;
    int eventStatus = atoi(ConfigXml::getIns()->getValue("RabbitMQ", "eventStatus").c_str()) ;
    string replyFlag = ConfigXml::getIns()->getValue("RabbitMQ", "replyFlag") ;
    string replyToQueue = ConfigXml::getIns()->getValue("RabbitMQ", "replyToQueue") ;
   // string timestamp = ConfigXml::getIns()->getValue("RabbitMQ", "timestamp") ;
    time_t t = time(0);
    char ch[64];
    strftime(ch, sizeof(ch), "%Y-%m-%d %H-%M-%S", localtime(&t));
    string timestamp = ch;
    
    string gatewayID = ConfigXml::getIns()->getValue("RabbitMQ", "gatewayID") ;
    string correlationID = ConfigXml::getIns()->getValue("RabbitMQ", "correlationID") ;
    string isReplyMsg = ConfigXml::getIns()->getValue("RabbitMQ", "isReplyMsg") ;

    //组装json
    Document doc;
    doc.SetObject();

    Document::AllocatorType &allocator=doc.GetAllocator(); //获取分配器

    rapidjson::Value topic_;
    topic_.SetString( topic.c_str() , topic.length() , allocator ) ;
    doc.AddMember("topic", topic_, allocator);

    rapidjson::Value appID_;
    appID_.SetString( appID.c_str() , appID.length() , allocator ) ;
    doc.AddMember("appID", appID_, allocator);

    rapidjson::Value token_;
    token_.SetString( token.c_str() , token.length() , allocator ) ;
    doc.AddMember("token", token_, allocator);

    //设备ＩＤ
    rapidjson::Value deviceId_;
    string sParentID = m_pClient->GetClientParentId();
    deviceId_.SetString( sParentID.c_str() , sParentID.length() , allocator ) ;
    doc.AddMember("deviceID", deviceId_, allocator);

    //MQ消息ＩＤ服用客户端的ＩＤ是消息唯一
    rapidjson::Value messageID_;
	struct timeval tv;
	gettimeofday(&tv,NULL);
	uint64_t msTm = (uint64_t)tv.tv_sec *10000 + tv.tv_usec/100;
    string messageID = to_string(msTm);
    sMsgId.assign(messageID);
    
    //string sClientID = m_pClient->GetClientID();
    messageID_.SetString( messageID.c_str() , messageID.length() , allocator ) ;
    doc.AddMember("messageID", messageID_, allocator);

    doc.AddMember("eventTypeID", eventTypeID, allocator);

    doc.AddMember("eventStatus", eventStatus, allocator);

    rapidjson::Value replyFlag_;
    replyFlag_.SetString( replyFlag.c_str() , replyFlag.length() , allocator ) ;
    doc.AddMember("replyFlag", replyFlag_, allocator);

    rapidjson::Value replyToQueue_;
    replyToQueue_.SetString( replyToQueue.c_str() , replyToQueue.length() , allocator ) ;
    doc.AddMember("replyToQueue", replyToQueue_, allocator);

    rapidjson::Value timestamp_;
    timestamp_.SetString( timestamp.c_str() , timestamp.length() , allocator ) ;
    doc.AddMember("timestamp", timestamp_, allocator);

    rapidjson::Value gatewayID_;
    gatewayID_.SetString( gatewayID.c_str() , gatewayID.length() , allocator ) ;
    doc.AddMember("gatewayID", gatewayID_, allocator);

    rapidjson::Value correlationID_;
    correlationID_.SetString( correlationID.c_str() , correlationID.length() , allocator ) ;
    doc.AddMember("correlationID", correlationID_, allocator);

    rapidjson::Value isReplyMsg_;
    isReplyMsg_.SetString( isReplyMsg.c_str() , isReplyMsg.length() , allocator ) ;
    doc.AddMember("isReplyMsg", isReplyMsg_, allocator);

	RapidJsonAddStringMember(doc, "traceId", GetTraceId());
	IncSpanId();
	RapidJsonAddStringMember(doc, "spanId", GetSpanId());
    //获取网关的配置参数
    string subject = ConfigXml::getIns()->getValue("VAG", "subject") ;
    int vagid = atoi(ConfigXml::getIns()->getValue("VAG", "id").c_str()) ;

    //组装传递给网关的json 字符串
    rapidjson::Value object(rapidjson::kObjectType) ;


        rapidjson::Value info_object(rapidjson::kObjectType);
        info_object.SetObject();
        //通道ＩＤ
        string sDeviceCode = m_pClient->GetClientDeviceCode();
        deviceId_.SetString( sDeviceCode.c_str() , sDeviceCode.length() , allocator ) ;
        info_object.AddMember("DeviceID", deviceId_, allocator);

        //设备ＩＤ
        //string sParentID = m_pClient->GetClientParentId();
        deviceId_.SetString(sParentID.c_str(), sParentID.length(), allocator );
        info_object.AddMember("ParentID", deviceId_, allocator);


        //组装ＳＤＰ
        char buf[1024] ;
        memset(buf , 0, sizeof(char )*1024 ) ;
        string sSubjectID = m_pClient->GetClientSubjectId();
        int len = sprintf(buf,"%s,%s", sSubjectID.c_str(), subject.c_str() ) ;
        rapidjson::Value sdp_Subject;
        sdp_Subject.SetString( buf , len , allocator ) ;
        info_object.AddMember( "Subject", sdp_Subject, allocator);


            int localPort = m_pClient->GetClientLocalPort();
            int iStreamProfile = m_pClient->GetClientStreamProfileCode();
            string sServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");
            rapidjson::Value sdp_Object;
            memset(buf , 0, sizeof(char )*1024 ) ;
            len = sprintf(buf,
                        "v=0\r\n"                                             \
		                "o=34020000002000000001 0 0 IN IP4 %s\r\n"            \
		                "s=Play\r\n"                                          \
		                "c=IN IP4 %s\r\n"                                     \
		                "t=0 0\r\n"                                           \
		                "m=video %d RTP/AVP 96 97 98\r\n"                     \
		                "a=rtpmap:96 PS/90000\r\n"                            \
		                "a=rtpmap:97 MPEG4/90000\r\n"                         \
		                "a=rtpmap:98 H264/90000\r\n"                          \
		                "a=recvonly\r\n"                                      \
                        "a=streamprofile:%d\r\n",
                        sServerIp.c_str(), sServerIp.c_str(), localPort, iStreamProfile ) ;
            sdp_Object.SetString( buf , len , allocator ) ;
            info_object.AddMember( "SDP", sdp_Object, allocator);

    object.AddMember("method", "RequestVideo", allocator);
    object.AddMember("id", vagid, allocator);
    object.AddMember("params", info_object , allocator ) ;

    doc.AddMember( "payload" , object , allocator );

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    doc.Accept(writer);
    ssendMQData = buffer.GetString();
    LOG_INFO_("to MQ message:%s, msgtag:%s", ssendMQData.c_str(), GetMsgTag().c_str()) ;

    if( ssendMQData.empty() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("generate MQ payload error.msgtag:%s", GetMsgTag().c_str()) ;
        return false ;
    }
    return true ;
}

/**********
***@brief sendMSGtoMQ()向ＭＱ发送消息取流
***@param void
***@return void
***@remark
**********/
bool HandleStreamStart::sendMSGtoMQ( )
{

    //向物联网总线下发请求视频流的消息
    std::string ssendMQData ;
    m_bReplyStatus = this->getSendToMQData(ssendMQData) ;
    if( m_bReplyStatus == false )
    {
        return false;
    }

    if(m_pHttpServer->m_pRabbitMQ == NULL)
    {
        LOG_ERROR_("m_pRabbitMQ is null" ) ;
        m_bReplyStatus = false;
        return  false ;

    }

	WriteMQTraceLog(ssendMQData, "INFO", "/streaming/start");
    int iReturn = m_pHttpServer->m_pRabbitMQ->publishMessage(ssendMQData.c_str()) ;
    if( iReturn < 0 )
    {
		WriteMonitorLog("RabbitMQExeFail", ssendMQData);
        LOG_ERROR_(" rabbitMQ publish error.msgatag:%s", GetMsgTag().c_str());
        m_bReplyStatus = false;
        return  false ;
    }

    return true;
}

/**********
***@brief deal()业务逻辑处理
***@param void
***@return void
***@remark
**********/
void HandleStreamStart::deal(const char *peerIp)
{
    if(m_pClient == NULL)
    {
        return;
    }
    m_bReplyStatus = receiveDataParse(m_sReceiveData, m_pClient, this, peerIp);

	WriteHttpReqTraceLog(m_sReceiveData, "INFO", "/streaming/start");
    
    if( m_bReplyStatus == false )
    {
		WriteHttpReqTraceLog(m_sReceiveData, "ERROR", "/streaming/start");
        m_bReplyStatus = false;
        return ;
    }

    LOG_INFO_("http req parse OK. url:%s, deviceParent:%s, deviceCode:%s, streamProfile:%d, clientIP:%s, clientPort:%d, msgtag:%s"
    					, "/streaming/start"
    					, (*m_pClient).GetClientParentId().c_str()
    					, (*m_pClient).GetClientDeviceCode().c_str()
    					, (*m_pClient).GetClientStreamProfileCode()
						, (*m_pClient).GetClientIp().c_str()
						, (*m_pClient).GetClientPort()
						, GetMsgTag().c_str()
    					); 


    if (NULL == m_pHttpServer)
    {
        LOG_ERROR_( "m_pHttpServer is null ") ;
        m_bReplyStatus = false;
        return ;
    }

    int iLocalPort = 0 ;
    string sSubjectiter;
    string sClientID = m_pClient->GetClientID();
    ClientMapiterator it = m_pHttpServer->m_ClientSessionList.find(sClientID);
    if (it != m_pHttpServer->m_ClientSessionList.end())
    {
        LOG_ERROR_("client:%s is exist.msgtag:%s", sClientID.c_str(), GetMsgTag().c_str());
        m_bReplyStatus = false;
        return ;
    }

    string sClientSubject = m_pClient->GetClientSubjectId();
    it = m_pHttpServer->m_ClientSessionList.begin();
    for(;it!=m_pHttpServer->m_ClientSessionList.end(); )
    {
        //遍历ｍａｐ找到是否有流已经在推，如果存在就启动分发
        if(NULL == it->second)
        {
            it  =  m_pHttpServer->m_ClientSessionList.erase( it );
            continue ;
        }
		
        sSubjectiter = it->second->GetClientSubjectId();
        if( strcmp( sSubjectiter.c_str(), sClientSubject.c_str() ) == 0 )
        {
            //找到有相同的流将之前开辟的端口存储到当前客户中
            iLocalPort = it->second->GetClientLocalPort();
            m_pClient->SetClientLocalPort(iLocalPort);
            m_bReplyStatus = sendMSGtoUDPServer( m_pClient->GetClientIp(), m_pClient->GetClientPort(), GetMsgTag(), iLocalPort, COMMON_START,
                                                                m_sServerIp , m_localInterchangePort );
            if(m_bReplyStatus == false)
            {
                LOG_ERROR_("sendMSGtoUDPServer error. msgtag:%s", GetMsgTag().c_str());
                return;
            }

            m_pHttpServer->m_ClientSessionList.insert(pair<string, ClientSession*>(sClientID,m_pClient));

			string logbody="device already push stream. deviceCode:"+GetMsgTag();
            LOG_INFO_(logbody.c_str());
			WriteTraceLogInternal(logbody, "INFO", "/streaming/start");
            return ;
        }
        ++it ;
    }

    //从端口池获取端口
    PortPool* pPortPool = m_pHttpServer->GetPortPool(); 
    iLocalPort = pPortPool->GetAndCheckUdpPort();
    LOG_INFO_("get udp port:%d, msgtag:%s", iLocalPort, GetMsgTag().c_str());
    if(iLocalPort < m_iUdpPortStart || iLocalPort > (m_iUdpPortStart + m_iUdpPortSize*2) )
    {
		string logbody="get udp port fail. port:"+std::to_string(iLocalPort)+", msgtag:"+GetMsgTag();
    	LOG_ERROR_(logbody.c_str());
		WriteTraceLogInternal(logbody, "ERROR", "/streaming/start");
		WriteMonitorLog("GetUdpPortFail", logbody);
        return;
    }
	
    
	LOG_INFO_("client require IPC stream is new, send command:COMMON_START to udp server. internal port:%d, clientIp:%s, clientPort:%d, msgtag:%s"
						, iLocalPort
						, m_pClient->GetClientIp().c_str()
						, m_pClient->GetClientPort()
						, GetMsgTag().c_str());
	
	string logbody="push stream from port:"+std::to_string(iLocalPort)+" to client "+m_pClient->GetClientIp()+":"+std::to_string(m_pClient->GetClientPort())+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/streaming/start");

    m_pClient->SetClientLocalPort(iLocalPort);
    m_bReplyStatus = sendMSGtoUDPServer( m_pClient->GetClientIp(), m_pClient->GetClientPort(), GetMsgTag(), iLocalPort, COMMON_START, m_sServerIp , m_localInterchangePort );
    if(m_bReplyStatus == false)
    {
		LOG_ERROR_("send command:COMMON_START to udp server error.internal port:%d, msgtag:%s", iLocalPort, GetMsgTag().c_str());
        return;
    }

    //等待ＵＤＰ创建线程结束
    string sltime = ConfigXml::getIns()->getValue("HttpServer", "waitUDPTime") ;
    if(sltime.empty())
    {
        sltime = "100000";
    }
    int  sleeptime = atoi(sltime.c_str());
    usleep(sleeptime);

    // 向ＭＱ发送消息
    string sendRequestToMQ = ConfigXml::getIns()->getValue("HttpHandle", "sendRequestToMQ");
    // log.info("HandleStreamStart deal, sendRequestToMQ: %s", sendRequestToMQ.c_str());
    if ( sendRequestToMQ == "1" )
    {
        m_bReplyStatus = this->sendMSGtoMQ();
    }
    if(m_bReplyStatus == false)
    {
        LOG_ERROR_("sendMSGtoMQ error.send command STREAMING_STOP to udp server. release internal port:%d, msgtag:%s", iLocalPort, GetMsgTag().c_str());
		WriteTraceLogInternal("stop push stream from port:"+std::to_string(iLocalPort)+" because send mq fail.msgtag:"+GetMsgTag(), "ERROR", "/streaming/start");

        sendMSGtoUDPServer( m_pClient->GetClientIp(), m_pClient->GetClientPort(), GetMsgTag(), iLocalPort,STREAMING_STOP, m_sServerIp , m_localInterchangePort );
        m_pHttpServer->GetPortPool()->ReleaseUdpPort(iLocalPort);
        return;
    }
    
    if ( sendRequestToMQ == "1" )
    {
        m_pHttpServer->m_stDevInfo.SetMsgIdPort( GetMsgId(), iLocalPort, DevInfo::EM_DEV_START );
    }


    sClientID = m_pClient->GetClientID();

    m_pHttpServer->m_ClientSessionList.insert(pair<string, ClientSession*>(sClientID,m_pClient));

    m_bReplyStatus = true ;
}



/***
***...HandleStreamStop类相关函数实现...
***...主要实现停止音频视频流...
***/
HandleStreamStop::HandleStreamStop()
  : m_pHttpServer( NULL )
  , m_bReplyStatus( false )
{
    //...
}

HandleStreamStop::~HandleStreamStop()
{
    //...
}

void HandleStreamStop::init(std::string& urldata, HttpServer* httpserver)
{
    m_sReceiveData = urldata ;
    m_pHttpServer = httpserver ;
    m_bReplyStatus = true;
}

bool HandleStreamStop::sendMSGtoMQ()
{
    /*
    *...通知设备关闭流...
    */
    std::string ssendMQData ;
    m_bReplyStatus = this->getSendToMQData(ssendMQData) ;
    if( m_bReplyStatus == false )
    {
        return false;
    }
    
	LOG_INFO_("to MQ message: %s.msgtag:%s", ssendMQData.c_str(), GetMsgTag().c_str()) ;
    if(m_pHttpServer->m_pRabbitMQ == NULL)
    {
        LOG_ERROR_(" m_pRabbitMQ is null" ) ;
        m_bReplyStatus = false;
        return  false ;

    }
   
    //retry do three times
    bool RetryRet = true;
    for (int iRetryTms = 1; iRetryTms <= 1; ++iRetryTms)
    {
		WriteMQTraceLog(ssendMQData, "INFO", "/streaming/stop");

		int iReturn = m_pHttpServer->m_pRabbitMQ->publishMessage(ssendMQData.c_str());
		if( iReturn < 0 )
		{
			LOG_ERROR_("rabbitlogin error, retry times: %d, msgtag:%s", iRetryTms, GetMsgTag().c_str()) ;
			WriteMonitorLog("RabbitMQExeFail", ssendMQData);
		    RetryRet = false;
		} 
		else 
		{
			RetryRet = true;
		}
    }

    return RetryRet;
}

void HandleStreamStop::deal(const char *peerIp)
{
    bool status = receiveDataParse(m_sReceiveData, &m_sClientSession, this, peerIp) ;
	
	WriteHttpReqTraceLog(m_sReceiveData, "INFO", "/streaming/stop");

    if (false == status)
    {
		WriteHttpReqTraceLog(m_sReceiveData, "ERROR", "/streaming/stop");
        m_bReplyStatus = false ;
        return ;
    }
    
    LOG_INFO_("http req parse OK. url:%s, deviceParent:%s, deviceCode:%s, streamProfile:%d, clientIP:%s, clientPort:%d, msgtag:%s"
    					, "/streaming/stop"
    					, m_sClientSession.GetClientParentId().c_str()
    					, m_sClientSession.GetClientDeviceCode().c_str()
    					, m_sClientSession.GetClientStreamProfileCode()
						, m_sClientSession.GetClientIp().c_str()
						, m_sClientSession.GetClientPort()
						, GetMsgTag().c_str()
    					); 

    /***
    ***由设备编码获取端口值
    ***并从map中删除clientsession
    ***/
    int iLocalPort = 0 ;
    string sSubjectiter;
    string sClientID = m_sClientSession.GetClientID() ;
    string sClientSubject = m_sClientSession.GetClientSubjectId();

    ClientMapiterator it = m_pHttpServer->m_ClientSessionList.find(sClientID);
    if(it == m_pHttpServer->m_ClientSessionList.end())
    {
		string logbody = "stop client error , clientsessionis not exist.msgtag:"+ GetMsgTag();
        LOG_ERROR_(logbody.c_str());
		WriteTraceLogInternal(logbody, "ERROR", "/streaming/start");
        m_bReplyStatus = false;
        return ;
    }

    iLocalPort = it->second->GetClientLocalPort();

    //m_pHttpServer->m_ClientSessionList.erase(it);
    ClientSession* pclient = it->second ;
    m_pHttpServer->m_ClientSessionList.erase( it );
    if (pclient != NULL)
    {
        delete(pclient);
        pclient = NULL;
    }

    ClientMapiterator iter = m_pHttpServer->m_ClientSessionList.begin();
    for(;iter!=m_pHttpServer->m_ClientSessionList.end(); ++iter )
    {
        sSubjectiter = iter->second->GetClientSubjectId();
        if (strcmp(sSubjectiter.c_str(), sClientSubject.c_str()) == 0)
        {
            break;
        }
    }
    //查看关闭的是不是最后一个取流客户端，如果是通知设备关闭流
    if ( iter == m_pHttpServer->m_ClientSessionList.end() )
    {
		string logbody ="no client require IPC streaming. msgtag:" + GetMsgTag();
        LOG_INFO_(logbody.c_str());
		WriteTraceLogInternal(logbody, "INFO", "/streaming/stop");
        //释放端口池中的端口
        m_pHttpServer->GetPortPool()->ReleaseUdpPort(iLocalPort);

        // 向ＭＱ发送消息
        string sendRequestToMQ = ConfigXml::getIns()->getValue("HttpHandle", "sendRequestToMQ");
        if ( sendRequestToMQ == "1" )
        {
            this->sendMSGtoMQ();
            m_pHttpServer->m_stDevInfo.SetMsgIdPort( GetMsgId(), iLocalPort, DevInfo::EM_DEV_STOP );
        }
    }

    //如果客户信息存在，删除信息，并通知客户端关闭发送流
	LOG_INFO_("client ask to stop stream. send command STREAMING_STOP to udp server. internal port:%d, clientIp:%s, clientPort:%d, msgtag:%s"
					, iLocalPort
					, m_sClientSession.GetClientIp().c_str()
					, m_sClientSession.GetClientPort()
					, GetMsgTag().c_str());
	string logbody="client ask to stop stream. send STREAM_STOP to udp server.internal port:"+std::to_string(iLocalPort)+", clientIp:"+m_sClientSession.GetClientIp()+", clientPort:"+std::to_string(m_sClientSession.GetClientPort())+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/streaming/stop");

    status = sendMSGtoUDPServer( m_sClientSession.GetClientIp(), m_sClientSession.GetClientPort(), GetMsgTag(), iLocalPort, STREAMING_STOP, m_sServerIp, m_localInterchangePort);
    if (status == false )
    {
        m_bReplyStatus = false;
        LOG_ERROR_("send command STREAMING_STOP to udp server error.internal port:%d, msgtag:%s", iLocalPort, GetMsgTag().c_str());
    }

    return ;
}

void HandleStreamStop::getReplyData(std::string& replaydata)
{
    //replaydata="{\"errMsg\": \"success!\", \"success\": true}";
    if(true == m_bReplyStatus)
    {
        replaydata = "{\"errMsg\": \"success!\", \"success\": true}";
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }

	string logbody = "httpRsp:"+replaydata + ", msgtag:" +  GetMsgTag();
    LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/streaming/stop");
}

bool HandleStreamStop::getSendToMQData(std::string& ssendMQData)
{
    //获取ＭＱ相关参数配置
    string topic = ConfigXml::getIns()->getValue("RabbitMQ", "topic") ;
    string appID = ConfigXml::getIns()->getValue("RabbitMQ", "appID") ;
    string token = ConfigXml::getIns()->getValue("RabbitMQ", "token") ;
    //string  messageID = ConfigXml::getIns()->getValue("RabbitMQ", "messageID");
    int eventTypeID = atoi(ConfigXml::getIns()->getValue("RabbitMQ", "eventTypeID").c_str()) ;
    int eventStatus = atoi(ConfigXml::getIns()->getValue("RabbitMQ", "eventStatus").c_str()) ;
    string replyFlag = ConfigXml::getIns()->getValue("RabbitMQ", "replyFlag") ;
    string replyToQueue = ConfigXml::getIns()->getValue("RabbitMQ", "replyToQueue") ;
    string timestamp = ConfigXml::getIns()->getValue("RabbitMQ", "timestamp") ;
    string gatewayID = ConfigXml::getIns()->getValue("RabbitMQ", "gatewayID") ;
    string correlationID = ConfigXml::getIns()->getValue("RabbitMQ", "correlationID") ;
    string isReplyMsg = ConfigXml::getIns()->getValue("RabbitMQ", "isReplyMsg") ;

    //组装json
    Document doc;
    doc.SetObject();

    Document::AllocatorType &allocator=doc.GetAllocator(); //获取分配器

    rapidjson::Value topic_;
    topic_.SetString( topic.c_str() , topic.length() , allocator ) ;
    doc.AddMember("topic", topic_, allocator);

    rapidjson::Value appID_;
    appID_.SetString( appID.c_str() , appID.length() , allocator ) ;
    doc.AddMember("appID", appID_, allocator);

    rapidjson::Value token_;
    token_.SetString( token.c_str() , token.length() , allocator ) ;
    doc.AddMember("token", token_, allocator);

    rapidjson::Value deviceId_;//给物联网总线的device是parentID
    string sParentID = m_sClientSession.GetClientParentId();
    deviceId_.SetString( sParentID.c_str() , sParentID.length() , allocator ) ;
    doc.AddMember("deviceID", deviceId_, allocator);

    rapidjson::Value messageID_;//messageID用subject 通道编码和主子麻溜唯一

	struct timeval tv;
	gettimeofday(&tv,NULL);
	uint64_t msTm = (uint64_t)tv.tv_sec *10000 + tv.tv_usec/100;
    string messageID = to_string(msTm);
    sMsgId.assign(messageID);

    messageID_.SetString( messageID.c_str() , messageID.length() , allocator ) ;
    doc.AddMember("messageID", messageID_, allocator);

    doc.AddMember("eventTypeID", eventTypeID, allocator);

    doc.AddMember("eventStatus", eventStatus, allocator);

    rapidjson::Value replyFlag_;
    replyFlag_.SetString( replyFlag.c_str() , replyFlag.length() , allocator ) ;
    doc.AddMember("replyFlag", replyFlag_, allocator);

    rapidjson::Value replyToQueue_;
    replyToQueue_.SetString( replyToQueue.c_str() , replyToQueue.length() , allocator ) ;
    doc.AddMember("replyToQueue", replyToQueue_, allocator);

    rapidjson::Value timestamp_;
    timestamp_.SetString( timestamp.c_str() , timestamp.length() , allocator ) ;
    doc.AddMember("timestamp", timestamp_, allocator);

    rapidjson::Value gatewayID_;
    gatewayID_.SetString( gatewayID.c_str() , gatewayID.length() , allocator ) ;
    doc.AddMember("gatewayID", gatewayID_, allocator);

    rapidjson::Value correlationID_;
    correlationID_.SetString( correlationID.c_str() , correlationID.length() , allocator ) ;
    doc.AddMember("correlationID", correlationID_, allocator);

    rapidjson::Value isReplyMsg_;
    isReplyMsg_.SetString( isReplyMsg.c_str() , isReplyMsg.length() , allocator ) ;
    doc.AddMember("isReplyMsg", isReplyMsg_, allocator);

	RapidJsonAddStringMember(doc, "traceId", GetTraceId());
	IncSpanId();
	RapidJsonAddStringMember(doc, "spanId", GetSpanId());
	
    rapidjson::Value object(rapidjson::kObjectType) ;

    rapidjson::Value info_object(rapidjson::kObjectType);
    info_object.SetObject();
    //通道ID
    string sDeviceCode = m_sClientSession.GetClientDeviceCode();
    deviceId_.SetString( sDeviceCode.c_str() , sDeviceCode.length() , allocator ) ;
    info_object.AddMember("DeviceID", deviceId_, allocator);

    //设备ID
    //string sParentID = m_sClientSession.GetClientParentId();
    deviceId_.SetString(sParentID.c_str(), sParentID.length(), allocator );
    info_object.AddMember("ParentID", deviceId_, allocator);

    //获取网关的配置参数
    string subject = ConfigXml::getIns()->getValue("VAG", "subject") ;
    int id = atoi(ConfigXml::getIns()->getValue("VAG", "id").c_str()) ;

    char buf[1024] ;
    memset(buf , 0, sizeof(char )*1024 ) ;
    string sSubjectID = m_sClientSession.GetClientSubjectId();
    int len = sprintf(buf,"%s,%s", sSubjectID.c_str(),  subject.c_str() )  ;
    rapidjson::Value sdp_Subject;
    sdp_Subject.SetString( buf , len , allocator ) ;
    info_object.AddMember( "Subject", sdp_Subject, allocator);

    object.AddMember("method", "StopVideo", allocator);
    object.AddMember("id", id, allocator);
    object.AddMember("params", info_object , allocator ) ;

    doc.AddMember( "payload" , object , allocator );

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    doc.Accept(writer);
    ssendMQData = buffer.GetString();

    if( ssendMQData.empty() )
    {
        m_bReplyStatus = false ;
      	LOG_ERROR_("generate MQ payload error.msgtag:%s", GetMsgTag().c_str());
        return false ;
    }
    return true ;
}

