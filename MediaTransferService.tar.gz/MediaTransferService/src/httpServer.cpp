///////////////////////////////////////////////////////////////
//
// FileName : httpServer.cpp
// Creator  : fan
// Date     : 2017-12-13
// Comment  : httpServer source file
//
///////////////////////////////////////////////////////////////

#include "httpServer.h"


#include "httpHandle.h"
#include "HandleHeartbeat.h"
#include "handleVoiceVideo.h"
#include "handleDeviceCall.h"
#include "handleCloudSpeak.h"
#include "handleConfigChange.h"
#include "mts_statistics.hpp"

const int HttpServer::iArrRegxLen;

typedef void (HttpServer::*TypeUriMatchFunc)(const std::string& sUri, HandleBase* phandlObj, const std::string& sPartten);
struct HttpServer::UriRegexRegist
{
    std::string msRegistUri;
    HandleBase* pHandleBase;
    std::string msParrten;
    TypeUriMatchFunc mUriMatchFunc;
};

class HttpServer::UriRegex
{
 public:
  UriRegex(const std::string& sRegexPatten):m_sRegexPatten(sRegexPatten)
  {}
  virtual ~UriRegex()
  {}

  inline bool IsMatch(const std::string& sSubject);

 private:
  std::string m_sRegexPatten;
};

bool HttpServer::UriRegex::IsMatch(const std::string& sSubject)
{
    if (sSubject.empty())
    {
        return false;
    }
    //LOG_INFO_("pattern: %s, subject: %s", m_sRegexPatten.c_str(), sSubject.c_str());
    bool iRet = false;
    try {
        iRet = std::regex_match(sSubject, std::regex(m_sRegexPatten));
    } 
    catch (std::exception& ex)
    {
        LOG_ERROR_("regex_match() err, msg: %s", ex.what()); 
    }
    if (iRet == true)
    {
        if (strncmp("/streaming/heartbeat", sSubject.c_str(), sizeof("/streaming/heartbeat")) != 0)
        {
            LOG_DEBUG_("uri match, regex pattern: [ %s ], subject: [ %s ]", m_sRegexPatten.c_str(), sSubject.c_str());
        }
    }
    else 
    {
        //LOG_DEBUG_("url not match");
    }
    return iRet;
}

void HttpServer::InitUriMeth(const std::string& sUri, HandleBase* phandlObj, const std::string& sPartten)
{
    auto pairInsert = m_reqTyp2Handler.insert(std::make_pair(sUri, phandlObj));
    assert(pairInsert.second);

    std::shared_ptr<UriRegex> uriRegPtr(new UriRegex(sPartten));
    m_mpUriRegex.insert(std::pair<std::shared_ptr<UriRegex>, HandleBase*>(uriRegPtr, pairInsert.first->second));
    LOG_DEBUG_("http obj addr: %p, register url: %s", phandlObj, sUri.c_str())
    return ;
}



//char *peerIp = "192.168.0.111";
/***
 * http回调函数;
 * 主要处理http请求消息(post)
 * 接受到消息后调用相关业务处理类进行消息处理
 **/
void HttpGenericCallback(struct evhttp_request* request, void* arg)
{
    HttpServer* phttpser = static_cast<HttpServer*>(arg);

    /* 请求方式 */
    switch(evhttp_request_get_command(request))
    {
        case EVHTTP_REQ_POST:
            break ;
        case EVHTTP_REQ_GET:
            phttpser->DoHttpGetReq(request);
            return;
        default:
            return;
    }

    /* 解析HTTP中的uri */
    // const char *host = evhttp_request_get_host(request);
    const char *uri = evhttp_request_get_uri(request) ;
    if ( strncmp(uri, "/streaming/heartbeat", 20) != 0 )
    {
        LOG_INFO_("http request: %s", uri);
    }

    /* 获取数据 */
    char post_data[1024] ;
    memset(post_data , 0, sizeof(char )*1024 ) ;
    memcpy(post_data , (char*)EVBUFFER_DATA(request->input_buffer) ,
    EVBUFFER_LENGTH(request->input_buffer)>1024?1024:EVBUFFER_LENGTH(request->input_buffer) ) ;
    std::string spost_data(post_data);
    std::string replydata /*=req.GetReply()*/;

    std::map<std::string, HandleBase*>::iterator it ;
    HandleBase* pHandleBase = NULL;
    for (auto itReg = phttpser->m_mpUriRegex.begin(); itReg != phttpser->m_mpUriRegex.end(); ++itReg)
    {
        if (itReg->first && itReg->first->IsMatch(uri))
        {
            //it = itReg->second;
            pHandleBase = itReg->second;
        
            if ( strncmp(uri, "/streaming/heartbeat", 20) != 0 )
            {
                LOG_DEBUG_("get http obj addr: %p, url: %s", pHandleBase, uri);
            }
            break;
        }
    }

	uint16_t peerPort;
	static char peerIp[64];
	memset(peerIp, 0, sizeof(peerIp));
	char *ipaddr = NULL;
	evhttp_connection_get_peer(evhttp_request_get_connection(request), &ipaddr, &peerPort);
	strcpy(peerIp, ipaddr);
    
    if (pHandleBase != NULL)
    {
        pHandleBase->init(spost_data, phttpser);
        pHandleBase->deal(peerIp);
        pHandleBase->getReplyData(replydata);
    }

    struct evbuffer* evbuf = evbuffer_new();
    if ( !evbuf )
    {
        printf("create evbuffer failed!\n");
        return ;
    }

    evhttp_add_header(evhttp_request_get_output_headers(request), "Content-Type", "application/json; charset=UTF-8");
    if(!replydata.empty())
    {
        uri=replydata.c_str();
    }

    evbuffer_add_printf(evbuf, "%s", uri);

    evhttp_send_reply(request, HTTP_OK, "OK", evbuf);

    evbuffer_free(evbuf);
    //LOG_DEBUG_(" HttpGenericCallback  over ");
}

UdpLogBase udplog;
//定时器超时处理
void TimeoutCallback(int fd,  short event, void * arg )
{
    HttpServer* phttpser = static_cast<HttpServer*>(arg);
    //time_t  oldtv ;
    time_t nowtv = time(NULL);

    phttpser->DealVoicVideoExpireNode(nowtv);

    int outTimeMax = 30;
    if ( !phttpser->m_sOutTimeMax.empty() )
    {
        outTimeMax = atoi(phttpser->m_sOutTimeMax.c_str());
    }

    ClientMapiterator it = phttpser->m_ClientSessionList.begin();
    for(;it!=phttpser->m_ClientSessionList.end();)
    {
        //oldtv = ;
        int outtime = nowtv - it->second->GetClientUpdate(); //超时时间
        if ( outtime < outTimeMax )
        {
            ++it ;
            continue ;//没有超时不用删除客户信息
        }

        //超时处理
        //发送给udp服务删除客户信息
        LOG_INFO_("client %s timeout  lost connection ", it->first.c_str());
		udplog.WriteMonitorLog("ClientOffline", "client:"+it->first);
        string clientip = it->second->GetClientIp();
        int clientport = it->second->GetClientPort();
        int localport = it->second->GetClientLocalPort();
        string sClientSubject = it->second->GetClientSubjectId() ;

		string msgtag=it->second->GetClientDeviceCode();
		
        S_clientToIPCMsg portmessage(clientip, clientport, localport, STREAMING_STOP, msgtag);
        portmessage.display();

        int localInterchangePort = phttpser->m_ilocalInterPort;
        string ServerIp = phttpser->m_sServerIp ;
        UdpClient  udpclient;
        LOG_INFO_("serverip:%s,port:%d",ServerIp.c_str(),localInterchangePort );
        int rec = udpclient.sendTo(ServerIp, localInterchangePort, (void*)&portmessage, sizeof(S_clientToIPCMsg));
        if(rec < 0)
        {
            LOG_ERROR_("time out close  clientSession error ip：%s, port: %d",clientip.c_str(), clientport );
            ++ it ;
            continue ;
        }
        //　构造关闭设备取流对象
        HandleStreamStop handStop;
        handStop.setClientSession(*(it->second));
         //　删除客户端信息
        ClientSession* pclient = it->second ;
        //ClientMapiterator iter = it;
        it  =  phttpser->m_ClientSessionList.erase( it );
        if (pclient != NULL)
        {
            delete(pclient);
        }
        //查看关闭的是不是最后一个取流客户端，如果是通知设备关闭流
        string sSubjectiter;
        ClientMapiterator iter = phttpser->m_ClientSessionList.begin();
        for(;iter!=phttpser->m_ClientSessionList.end(); ++iter )
        {
            sSubjectiter = iter->second->GetClientSubjectId();
            if (strcmp(sSubjectiter.c_str(), sClientSubject.c_str()) == 0)
            {
                break ;
            }
        }

        //最后一个取流客户端 ,释放端口池中的端口,通知设备关闭流
        if ( iter == phttpser->m_ClientSessionList.end() )
        {
            LOG_INFO_("no client require IPC streaming :%s ", sClientSubject.c_str() );
            phttpser->GetPortPool()->ReleaseUdpPort(localport);
            //停止设备取流
            handStop.setHttpServer(phttpser);
            bool bReply = handStop.sendMSGtoMQ();
            if(bReply == false)
            {
                handStop.sendMSGtoMQ();   
            }
            phttpser->m_stDevInfo.SetMsgIdPort( handStop.GetMsgId(), localport, DevInfo::EM_DEV_STOP ); 
        }
    }
}

/***
 *  HttpServer相关实现
 **/
HttpServer::HttpServer()
  : m_ip( "0.0.0.0" )
  , m_base( NULL )
  , m_http( NULL )
  , m_pTimer( NULL )
  , m_pUdpPortPool( NULL )
  , m_pRabbitMQ(NULL)
{
    m_port = 10001;
    m_ilocalInterPort = 0 ;
    if ( 0 == init() )
    {
        LOG_INFO_("init the http_server success, m_ip: %s, m_port: %d", m_ip.c_str(), m_port);
    }
    else
    {
        LOG_INFO_("init the http_server failed, m_ip: %s, m_port: %d", m_ip.c_str(), m_port);
    }
}

HttpServer::HttpServer(int port)
  : m_ip( "0.0.0.0" )
  , m_base( NULL )
  , m_http( NULL )
  , m_pTimer( NULL )
  , m_pUdpPortPool( NULL )
  , m_pRabbitMQ(NULL)
{

    m_port = port;
    m_ilocalInterPort = 0 ;
    if ( 0 == init() )
    {
        LOG_INFO_("create the http_server success!m_ip: %s , m_port: %d", m_ip.c_str(), m_port);
    }
    else
    {
        LOG_INFO_("create the http_server failed!m_ip: %s , m_port: %d", m_ip.c_str(), m_port);
    }
}

HttpServer::HttpServer(string ip, int port)
  : m_ip( ip )
  , m_base( NULL )
  , m_http( NULL )
  , m_pTimer( NULL )
  , m_pUdpPortPool( NULL )
  , m_pRabbitMQ(NULL)
{
    m_port = port;
    m_ilocalInterPort = 0 ;
    if ( 0 == init() )
    {
        LOG_INFO_("create the http_server success!m_ip: %s , m_port: %d", m_ip.c_str(), m_port);
    }
    else
    {
        LOG_INFO_("create the http_server failed!m_ip: %s , m_port: %d", m_ip.c_str(), m_port);
    }
}

int HttpServer::init()
{
    if( m_port < 1 )
    {
        LOG_ERROR_("create the http_server failed!m_ip: %s , m_port: %d", m_ip.c_str(), m_port) ;
        return -1 ;
    }

    m_ilocalInterPort = atoi(ConfigXml::getIns()->getValue("UdpServer", "udpServerPort").c_str());
    m_sServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");
    m_sOutTimeMax = ConfigXml::getIns()->getValue("HandleHeartBeat", "heartBeatTimeOut");
    m_sVoiceVideoExpTm = ConfigXml::getIns()->getValue("HandleHeartBeat", "VoiceVideoExpTm");
    
    m_pUdpPortPool = new PortPool();
    
    HandleBase::SetMTSHttpIp(m_sServerIp);
    HandleBase::SetMTSHttpPort(m_port);

    if(NULL == m_pUdpPortPool)
    {
        LOG_ERROR_("PortPool failed");
        return -1;
    }

    m_base = event_base_new();
    if (!m_base)
    {
        LOG_INFO_("event_base_new failed!");
        return -1;
    }

    m_http = evhttp_new(m_base);
    if (!m_http)
    {
        LOG_INFO_("evhttp_new failed!");
        exit(-1);
    }

    if (evhttp_bind_socket(m_http, m_ip.c_str(), m_port) != 0)
    {
        LOG_INFO_("evhttp_bind_socket failed! exit!! m_ip: %s , m_port: %d", m_ip.c_str(), m_port);
        exit(-1);
    }

    pArrRegex = new UriRegexRegist[iArrRegxLen];

    m_stDevInfo.SetUdpSrvIp(m_sServerIp);
    return 0;
}

int HttpServer::run(pFuncCallBackHttp func, void* arg)
{
    //设置事件处理函数
    if ( !func )
    {
        return -1;
    }
    //创建定时器
    m_pTimer = new TimerEvent(m_base, 5, TimeoutCallback, this );
    if(m_pTimer == NULL)
    {
        LOG_ERROR_("TimerEvent creant error");
        return 0;
    }

    //创建ＭＱ并启动消费线程
    m_pRabbitMQ = new RabbitMQClient();
    if(NULL == m_pRabbitMQ)
    {
        LOG_ERROR_("rabbitMQ create failed");
        return -1;
    }
    m_pRabbitMQ->SetDevInfoHandle( &(this->m_stDevInfo) );

    string sendRequestToMQ = ConfigXml::getIns()->getValue("HttpHandle", "sendRequestToMQ");
    if ( sendRequestToMQ == "1" )
    {
        m_pRabbitMQ->consumerRun();
    }

    int iIndex = 0;
    pArrRegex[iIndex++] = {"/streaming/start/", (new HandleStreamStart()), "^/streaming/start/+[[:alnum:]].*", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/streaming/start", (new HandleStreamStart()), "^/streaming/start$", &HttpServer::InitUriMeth };

    pArrRegex[iIndex++] = {"/streaming/stop", (new HandleStreamStop()), "^/streaming/stop$", &HttpServer::InitUriMeth };
    
    pArrRegex[iIndex++] = {"/streaming/heartbeat", (new HandleHeartbeat()), "^/streaming/heartbeat$", &HttpServer::InitUriMeth };
   
    pArrRegex[iIndex++] = {"/voicevideo/start/", (new HandleVoiceVideoStart()),"^/voicevideo/start/+[[:alnum:]].*", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/voicevideo/start", (new HandleVoiceVideoStart()),"^/voicevideo/start$", &HttpServer::InitUriMeth };
    
    pArrRegex[iIndex++] = {"/voicevideo/stop", (new HandleVoiceVideoStop()), "^/voicevideo/stop$", &HttpServer::InitUriMeth };
    
    pArrRegex[iIndex++] = {"/voice/require/", (new HandleDeviceCall()), "^/voice/require/+[[:alnum:]].*", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/voice/require", (new HandleDeviceCall()), "^/voice/require$", &HttpServer::InitUriMeth };

    pArrRegex[iIndex++] = {"/voice/start/",  (new HandleDeviceIntercall()), "^/voice/start/+[[:alnum:]].*", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/voice/start",  (new HandleDeviceIntercall()), "^/voice/start$", &HttpServer::InitUriMeth };
    
    pArrRegex[iIndex++] = {"/videoapp/heartbeat", (new HandleVideoAppHeartbeat()), "^/videoapp/heartbeat$", &HttpServer::InitUriMeth };

    pArrRegex[iIndex++] = {"/cloudvoicevideo/start/", (new HandleCloudVoiceVideoStart()), "^/cloudvoicevideo/start/+[[:alnum:]].*", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/cloudvoicevideo/start", (new HandleCloudVoiceVideoStart()), "^/cloudvoicevideo/start$", &HttpServer::InitUriMeth };
    
    pArrRegex[iIndex++] = {"/cloudvoicevideo/stop", (new HandleCloudVoiceVideoStop()), "^/cloudvoicevideo/stop$", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/config/change",(new HandleConfigChange()), "^/config/change$", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"/mts/sts", (new MTS::HandleStatistics()), "^/mts/sts$", &HttpServer::InitUriMeth };
    pArrRegex[iIndex++] = {"", (NULL), "", &HttpServer::InitUriMeth };
    
    LOG_DEBUG_("End Regex Index: %d", iIndex);
    for (int iNum = 0; iNum < iIndex; ++iNum)
    {
        if (pArrRegex[iNum].pHandleBase == NULL)
        {
            LOG_DEBUG_("has register nums: %d",iNum);
            break;
        }

        TypeUriMatchFunc InitRegexFunc = pArrRegex[iNum].mUriMatchFunc;
        ((*this).*InitRegexFunc)(pArrRegex[iNum].msRegistUri, 
                                 pArrRegex[iNum].pHandleBase,
                                 pArrRegex[iNum].msParrten);
    }

    evhttp_set_gencb(m_http, func, /*m_pUdpPortPool*/this);

    //启动事件循环，当有http请求的时候会调用指定的回调
    event_base_dispatch(m_base);

    // evhttp_free(m_http);

    return 0;
}

int HttpServer::run()
{
    return run(HttpGenericCallback, NULL);
}

HttpServer::~HttpServer()
{
    if (pArrRegex)
    {
        delete [] pArrRegex; pArrRegex = NULL;
    }
    
    // m_pfun_cb = NULL;
    //evhttp_free(m_http);
    //delete point
}

PortPool* HttpServer::GetPortPool()
{
    return m_pUdpPortPool;
}


void HttpServer::DoHttpGetReq(struct evhttp_request* request)
{
	if (request == NULL)
	{
        return ;
	}
    const char *uri = evhttp_request_get_uri(request) ;
    if ( strncmp(uri, "/streaming/heartbeat", 20) != 0 )
    {
        LOG_INFO_("http request: %s", uri);
    }

    if (strncmp("/mts/sts", uri, sizeof("/mts/sts")) != 0)
    {
        LOG_INFO_("not mts/sts req, omit it");
        return ;
    }

    std::map<std::string, HandleBase*>::iterator it;
    HandleBase* pHandleBase = NULL;
    for (auto itReg = m_mpUriRegex.begin(); itReg != m_mpUriRegex.end(); ++itReg)
    {
        if (itReg->first && itReg->first->IsMatch(uri))
        {
            //it = itReg->second;
            pHandleBase = itReg->second;
            break;
        }
    }

    std::string spost_data, replydata;
    if (pHandleBase)
    {
        pHandleBase->init(spost_data, this);
        pHandleBase->deal();
        pHandleBase->getReplyData(replydata);
    }
    struct evbuffer* evbuf = evbuffer_new();
    if ( !evbuf )
    {
        printf("create evbuffer failed!\n");
        return ;
    }

    evhttp_add_header(evhttp_request_get_output_headers(request), 
                     "Content-Type", "text/html; charset=UTF-8");
    if(!replydata.empty())
    {
        uri=replydata.c_str();
    }

    evbuffer_add_printf(evbuf, "%s", uri);

    evhttp_send_reply(request, HTTP_OK, "OK", evbuf);

    evbuffer_free(evbuf);
}

void HttpServer::DealVoicVideoExpireNode(time_t tNow)
{
    if (tNow <= 0)
    {
        return ;
    }

    int iExpireTmDef = 120; //default 2 minute
    if (m_sVoiceVideoExpTm.empty() == false)
    {
        iExpireTmDef = ::atoi(m_sVoiceVideoExpTm.c_str());
    }

    for (auto it = m_mpVoiceVideNodes.begin(); it != m_mpVoiceVideNodes.end();)
    {
        int iTmDur = tNow - it->second;
        if (iTmDur < iExpireTmDef)
        {
            ++it; //not expire for voicevideo start node
            continue;
        }
        LOG_ERROR_("voicevideo start node expire, devcode: %s", it->first.c_str());
        
        PortPool* pmpPort = GetPortPool();
        if (pmpPort == NULL)
        {
            LOG_ERROR_("get port pool handle fail, is null");
            //m_mpVoiceVideNodes.erase(it++);
            return ;
        }
        
        auto itPort = pmpPort->m_mapDevecePort.find(it->first);
        if (itPort == pmpPort->m_mapDevecePort.end())
        {
            LOG_DEBUG_("not find devcode in dev port pool, devcode: %s", it->first.c_str());
            m_mpVoiceVideNodes.erase(it++);
            continue;
        }
       
        //construct stop handle, then call release udp port function.
        HandleVoiceVideoStop instanceVoiceVideStop;
        instanceVoiceVideStop.SetDevCode(it->first);

        std::string sUrlDef = "{}";
        instanceVoiceVideStop.init(sUrlDef, this);
       
        //call release udp port;
        instanceVoiceVideStop.ReleaseRelayPort();

        LOG_INFO_("release voicevideo start node port, devcode: %s", it->first.c_str());
        m_mpVoiceVideNodes.erase(it++);
    }
}

bool HttpServer::InsertDevCodeInVoiceVideoNode(const std::string& sDevCode)
{
    auto it = m_mpVoiceVideNodes.find(sDevCode);
    if (it != m_mpVoiceVideNodes.end())
    {
        LOG_ERROR_("dev code has exist in voicevideo start node, dev code: %s", sDevCode.c_str());
        return false;
    }
    m_mpVoiceVideNodes.insert(std::pair<std::string, time_t>(sDevCode,time(NULL)));
    return true;
}

bool HttpServer::DelDevCodeFromVoiceVideoNode(const std::string& sDevCode)
{
    auto it = m_mpVoiceVideNodes.find(sDevCode);
    if (it != m_mpVoiceVideNodes.end())
    {
        m_mpVoiceVideNodes.erase(it);
        return true;
    }
    return true;
}
