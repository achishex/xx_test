///////////////////////////////////////////////////////////////
//
// FileName : configXml.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : configXml head file
//
///////////////////////////////////////////////////////////////

#ifndef _RAPID_XML_H_
#define _RAPID_XML_H_

#include <iostream>
#include <map>
#include <string>
#include "rapidxml.hpp"
#include "rapidxml_utils.hpp"
#include "rapidxml_print.hpp"

using namespace rapidxml;
using std::map;
using std::string;
using std::cout;
using std::endl;

typedef map<string, string> myConfigType;
typedef map<string, string>::iterator myConfigIter;
typedef std::pair<string, string> myConfigPair;

class ConfigXml
{
public:
    int init(string fileName = "./config.xml");
    ~ConfigXml();
    string getValue(string keyBelong, string key);
    bool appendValue(string keyBelong, string key, string value);
    bool modifyValue(string keyBelong, string key, string value);
    void print() const;
    void display();

    static ConfigXml* getIns();

private:
    ConfigXml();
    myConfigType m_map_data;
    string m_data;
    string m_sConfigFileName;
    static ConfigXml* m_instance;
};


#endif