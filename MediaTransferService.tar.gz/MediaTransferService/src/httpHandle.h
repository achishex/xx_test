///////////////////////////////////////////////////////////////
//
// FileName : http_handle.h
// Creator  : fan
// Date     : 2017-12-18
// Comment  : handle_stream head file
//
///////////////////////////////////////////////////////////////

#ifndef _HANDLE_STREAM_H_
#define _HANDLE_STREAM_H_

#include "common.h"
#include "PortPool.h"
#include "udpClient.h"
#include "rabbitMQClient.h"
#include "httpServer.h"

#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/prettywriter.h"  
#include "udpLogBase.h"
using namespace rapidjson;


/**
*** 事务处理基础类
**/
class HandleBase: public UdpLogBase
{
public:
    // 统一事务处理接口
    virtual void deal(const char *peerIp="") = 0;
    virtual void init(std::string& urldata, HttpServer* httpserver) { };
    virtual void init(std::string& urldata, PortPool* pool) {};
    virtual void getReplyData(std::string& replaydata) {};
    virtual ~HandleBase(){}

    HandleBase();
	string GetMsgTag();
	void SetMsgTag(std::string &deviceCode);

    static void SetMTSHttpIp(const std::string& sHttpIp) 
    {
        m_stMTSHttpIp = sHttpIp;
    }
    static void SetMTSHttpPort(const int iHttpPort)
    {
        m_stMTSHttpPort = iHttpPort;
    }

    static std::string GetMTSHttpIp()
    {
        return m_stMTSHttpIp;
    }
    static int GetMTSHttpPort()
    {
        return m_stMTSHttpPort;
    }
public:
    int m_localInterchangePort;
    std::string m_sServerIp ;
    int m_iUdpPortStart;
    int m_iUdpPortSize;
	string m_msgtag;
    //
    static std::string m_stMTSHttpIp;
    static int m_stMTSHttpPort;
};

/**
*** 取流响应的事物处理类
**/
class HandleStreamStart : public HandleBase
{
public:
    HandleStreamStart();
    ~HandleStreamStart();
    //Handle_stream_start(std::string& urldata):m_sReceiveData(urldata){}
    void init(std::string&  urldata , HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);
    std::string GetMsgId() 
    {
        return sMsgId;
    }

private:
    bool getSendToMQData(std::string& mqdata);
    bool sendMSGtoMQ();
private:
    string m_sReceiveData;
    ClientSession* m_pClient ;
    HttpServer* m_pHttpServer;
    bool m_bReplyStatus ;
    std::string sMsgId;
};

/**
*** 请求停止流操作类
**/
class HandleStreamStop : public HandleBase
{
public:
    HandleStreamStop();
    ~HandleStreamStop();
    //Handle_stream_start(std::string& urldata):m_sReceiveData(urldate){}
    void init(std::string&  urldata , HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);
    void setClientSession(ClientSession& client)
    {  m_sClientSession = client; }
    void setHttpServer(HttpServer* httpserver)
    {  m_pHttpServer = httpserver;  }
    bool sendMSGtoMQ(); 
    std::string GetMsgId() 
    {
        return sMsgId;
    }
private:
    bool getSendToMQData(std::string& ssendMQData); 
private:
    string m_sReceiveData;
    ClientSession m_sClientSession;
   
    HttpServer* m_pHttpServer;
    bool m_bReplyStatus ;
    std::string sMsgId;
};

#endif
