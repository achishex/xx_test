///////////////////////////////////////////////////////////////
//
// FileName : udpClient.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : udpClient head file
//
///////////////////////////////////////////////////////////////

#ifndef _UDP_CLIENT_H_
#define _UDP_CLIENT_H_

#include "common.h"

class UdpClient
{
public:
    UdpClient();
    UdpClient(int localport);
    UdpClient(string ip, int localport);
    UdpClient(const char *ip, int localport, bool do_connect);
    ~UdpClient();
    UdpClient(const UdpClient &copy);
    UdpClient &operator=(const UdpClient &copy);
    int sendTo(string dstIp, int dstPort, string str);
    int sendTo(string dstIp, int dstPort, const void* buf, int len);
	int SendData(const char *buf, int len);
	void Init(const char *ip, int localport, bool do_connect);
public:
    int m_sock;
    string m_ip;
    int m_port;
    struct sockaddr_in m_remoteAddr;
    bool m_doConnect;
};


#endif
