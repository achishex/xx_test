///////////////////////////////////////////////////////////////
//
// FileName : HandleConfigChange.h
// Creator  : liupc123
// Date     : 2018-03-23
// Comment  : HandleConfigChange head file
//
///////////////////////////////////////////////////////////////

#ifndef _HANDLE_CONFIG_CHANGE_H_
#define _HANDLE_CONFIG_CHANGE_H_

#include "httpHandle.h"

// 上游下达信令，修改某些配置
class HandleConfigChange : virtual public HandleBase
{
public:
    HandleConfigChange() ;
    ~HandleConfigChange() ;
    void init(std::string& urldata, HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);

private:
    bool receiveDataParse(std::string& urldata);

private:
    string m_sMQHost;
    string m_sMQAppId;
    string m_sTutkUuid;
    string m_sMQUsername;
    string m_sMQReplyToQueue;
    string m_sReceiveData;
    string m_sLocalIp;
    HttpServer* m_pHttpServer;
    bool m_bReplyStatus;
};

#endif
