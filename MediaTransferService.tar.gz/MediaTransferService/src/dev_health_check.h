#ifndef _DEV_HEALTH_CHECK_H_
#define _DEV_HEALTH_CHECK_H_

/**
 * @file: dev_health_check.h
 * @brief: 实现定期对下游设备状态(推流)进行健康性检查
 * @author:  
 * @version: dev4
 * @date: 2018-05-10
 */
#include <stdint.h>
#include <string>
#include <sstream>

#include <event2/event.h>
#include <event2/buffer.h>
#include <event.h>

namespace DEV_CHECK
{

class DevCheck
{
    public:
     DevCheck(event_base* pBase, int32_t iCheckTimeDur, int32_t uiPort, uint32_t uiNeedRecvPkgNum);
     virtual ~DevCheck();
     
     bool StartCheckPoint( void (*pCheckPointCallBack)(int fd, short event, void* arg) );
     bool UpdteCheckTimer();

     bool MarkStopStream();
     std::string ToString();
     bool CheckDevSendPkgEnough();

    private:
     event_base* m_pEventBase;
     struct event* m_pCheckPointEvent;
     int32_t m_iDisConnNums;
     int32_t m_iCheckTimeDur;
     int32_t m_uiRecvDevPort;
     std::string m_uiDevCode;
     std::ostringstream m_ssBuf;
     void (*m_pCheckPointCallback)(int fd, short event, void *);
     uint32_t m_uiRecvPkgNums;
     uint32_t m_uiNeedRcvPkgNums;
	 uint32_t m_uiLastUpdateTm;

};

}
#endif
