///////////////////////////////////////////////////////////////
//
// FileName : mutexClass.h
// Creator : zhuxiaojing
// Date : 2018-1-19 10:13:00
// Comment :
//
///////////////////////////////////////////////////////////////



#ifndef _MUTEXCLASS_H_
#define _MUTEXCLASS_H_

#include <pthread.h>

namespace hdtool {
    class CMutexClass
    {
    public:
        CMutexClass(void);
        ~CMutexClass(void);
        bool m_bCreated;
        void Lock();
        void Unlock();
    private:
        pthread_mutex_t m_mutex;
        pthread_t       m_owner;
    };
}


#endif