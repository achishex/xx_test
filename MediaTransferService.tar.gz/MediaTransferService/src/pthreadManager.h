//---------------------------------------------------------------------------
//
// FileName : pthreadManager.h
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : pthreadManager head file
//
//---------------------------------------------------------------------------
#ifndef PthreadManager_H
#define PthreadManager_H
#include <vector>
#include <cstring>

#include "udpServerEventBase.h"

struct Client  // 1个客户端的信息
{
    int           m_port ;   // 本地端口
    char          m_client_ip[ 64 ] ; // 客户端收流 ip
    int           m_client_port ;     // 客户端收流 port

    UdpEvent  *   m_event ;  // udp event
    UdpServerEventBase * m_base ; // base thread

    Client() ;
    Client( const int port,  const char * client_ip,  const int client_port,  UdpEvent * event,  UdpServerEventBase * base ) ; //
    bool operator == ( const Client & o ) const ;
};

class ClientInfo  // 全局客户端列表
{
    std::vector< Client >  m_list ; //
public:
    bool add       ( const int port,  const char * client_ip,  const int client_port,  UdpEvent *  event,  UdpServerEventBase * base ) ; // 增加1个客户端
    bool find_event( const int port,  int & client_count,  UdpEvent ** event,  UdpServerEventBase ** base ) ; // 查找端口上的 event 与 客户数量

    bool del_client( const int port,  const char * client_ip,  const int client_port ) ; // 删除1个客户端. 返回值: true=找到并删除 false=未找到
    int   del_event( const int port ) ; // 删除端口上的所有客户端. 返回值: 被删的客户端个数
    void dump( const char * );
};

class PthreadManager  // 管理线程类
{
    friend int main(int argc, char* argv[]) ;
public:
    ~PthreadManager();
    int  init( int workThreadCount = 10 ) ; // 初始化. 创建base线程

    static PthreadManager * getInstance();       //单例

    void analyseHttpMessage( void * buf,  int buf_len ); // 处理 udp server 来的数据. called by udp server

private:
    UdpServerEventBase * get_idle_thread() ; // 获取空闲base线程
private:
    PthreadManager();
    static PthreadManager* m_instance;

    ClientInfo   m_client_info ;
    int          m_cur_thread_index ;
    std::vector< UdpServerEventBase * >  m_thread_list ;
};

#endif
