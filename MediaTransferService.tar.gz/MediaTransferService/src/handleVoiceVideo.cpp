///////////////////////////////////////////////////////////////
//
// FileName : http_handle.cpp
// Creator  : fan
// Date     : 2018-01-18
// Comment  : handle_stream_start source file
//
///////////////////////////////////////////////////////////////

#include "handleVoiceVideo.h"


HandleVoiceVideoStart::HandleVoiceVideoStart()
  : m_iVoicePort( 0 )
  , m_iVideoPort( 0 )
  , m_idevReceivePort( 0 )
  , m_pUdpPortPool( NULL )
  , m_pHttpServer( NULL )
  , m_bReplyStatus( false )
{

}

HandleVoiceVideoStart::~HandleVoiceVideoStart()
{
    //...
}

void HandleVoiceVideoStart::init(std::string&  urldata, HttpServer* httpserver)
{
    m_sReceiveData = urldata;
    if( httpserver == NULL )
    {
        LOG_ERROR_("httpserver is null in HandleVoiceVideoStart::init()") ;
        m_bReplyStatus = false ;
        return ;
    }
    m_pUdpPortPool = httpserver->GetPortPool();
    m_bReplyStatus = false;

    m_pHttpServer = httpserver;
}

void HandleVoiceVideoStart::deal(const char *peerIp)
{
    m_bReplyStatus = this->receiveDataParse(m_sReceiveData, peerIp) ;
    if( m_bReplyStatus == false )
    {
		WriteHttpReqTraceLog(m_sReceiveData, "ERROR", "/voicevideo/start");
        return ;
    }

    if (NULL == m_pUdpPortPool)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("m_pUdpPortPool is null in HandleVoiceVideoStart::getReplyData") ;
        return ;
    }

    /**
     * ...如果设备编码映射中没有...
     * ...从端口池获取端口....
     * ...并将端口和设备编码建立映射关系添加到端口池map中
     *
    */

    map<string,vector<int>>::iterator it ;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it != m_pUdpPortPool->m_mapDevecePort.end())
    {
        m_bReplyStatus = false;
        LOG_ERROR_("devicecode been used.msgtag:%s", GetMsgTag().c_str());
		WriteTraceLogInternal("device:"+GetMsgTag()+" has been used.", "ERROR", "/voicevideo/start");
        return ;
    }
    
    int receiveDevVoicePort = m_pUdpPortPool->GetAndCheckUdpPort() ;
    LOG_INFO_("get receiveDevVoicePort:%d.msgtag:%s", receiveDevVoicePort, GetMsgTag().c_str());
    if(receiveDevVoicePort < m_iUdpPortStart || receiveDevVoicePort > (m_iUdpPortStart + m_iUdpPortSize*2) )
    {
    	LOG_ERROR_("GetAndCheckUdpPort fail. receiveDevVoicePort:%d illegal. msgtag:%s", receiveDevVoicePort, GetMsgTag().c_str());
		WriteMonitorLog("GetUdpPortFail", "/voicevideo/start get udp port fail. device:"+GetMsgTag());
        return;
    }
    
    int receiveDevVideoPort = m_pUdpPortPool->GetAndCheckUdpPort() ;
    LOG_INFO_("get receiveDevVideoPort:%d.msgtag:%s", receiveDevVideoPort, GetMsgTag().c_str());
    if(receiveDevVideoPort < m_iUdpPortStart || receiveDevVideoPort > (m_iUdpPortStart + m_iUdpPortSize*2) )
    { 
		LOG_ERROR_("GetAndCheckUdpPort fail. receiveDevVideoPort:%d illegal. msgtag:%s", receiveDevVideoPort, GetMsgTag().c_str());
		WriteMonitorLog("GetUdpPortFail", "/voicevideo/start get udp port fail. device:"+GetMsgTag());
        return;
    }
    
    int receiveCltVoicePort = m_pUdpPortPool->GetAndCheckUdpPort() ;
    LOG_INFO_("get receiveCltVoicePort:%d.msgtag:%s", receiveCltVoicePort, GetMsgTag().c_str());
    if(receiveCltVoicePort < m_iUdpPortStart || receiveCltVoicePort > (m_iUdpPortStart + m_iUdpPortSize*2) )
    {
		LOG_ERROR_("GetAndCheckUdpPort fail. receiveCltVoicePort:%d illegal. msgtag:%s", receiveCltVoicePort, GetMsgTag().c_str());
		WriteMonitorLog("GetUdpPortFail", "/voicevideo/start get udp port fail. device:"+GetMsgTag());
        return;
    }
    vector<int> vecport;
    vecport.push_back(receiveDevVoicePort);
    vecport.push_back(receiveDevVideoPort);
    vecport.push_back(receiveCltVoicePort);

    m_pUdpPortPool->m_mapDevecePort.insert(make_pair(m_sDeviceCode,vecport));

    // LOG_INFO_("%d - %d - %d", receiveDevVoicePort, receiveDevVideoPort, receiveCltVoicePort);
    // LOG_INFO_("%d - %d - %d", m_iVoicePort, m_iVideoPort, m_idevReceivePort);

    /**
    * ... 创建发送给udpserver的消息 ...
    * ... 通知udpserver创建视频监听服务....
    */
    pS_clientToIPCMsg portmessage = new S_clientToIPCMsg(m_sVoiceIp, m_iVoicePort, receiveDevVoicePort, VOICEVIDEO_START, GetMsgTag() );
    if(NULL == portmessage)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("creat portmessage error.out of memory.msgtag:%s", GetMsgTag().c_str());
        return ;
    }
    UdpClient udpclient;
    
	LOG_INFO_("send VOICEVIDEO_START to udp server.voice internal port:%d,client voiceIp:%s, client voicePort:%d,msgtag:%s" 
				, receiveDevVoicePort
				, m_sVoiceIp.c_str()
				, m_iVoicePort
				, GetMsgTag().c_str());
				
	string logbody="push voice stream from port:"+std::to_string(receiveDevVoicePort)+" to client "+m_sVoiceIp+":"+std::to_string(m_iVoicePort)+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/voicevideo/start");

    int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("send VOICEVIDEO_START to udp server fails.msgtag:%s", GetMsgTag().c_str());
        return ;
    }


    /**
    * ... 创建发送给udpserver的消息 ...
    * ... 通知udpserver创建设备音频监听服务....
    */
    bzero(portmessage, sizeof(S_clientToIPCMsg));
    // portmessage->sendtoip = m_sVoiceIp;
    strncpy(portmessage->sendToIp, m_sVideoIp.c_str(), 64);
    portmessage->sendToPort = m_iVideoPort;
    portmessage->localPort = receiveDevVideoPort;
    portmessage->command = VOICEVIDEO_START;
    strncpy(portmessage->chDevIndeCode, GetMsgTag().c_str(), GetMsgTag().size());
    
    LOG_INFO_("send VOICEVIDEO_START to udp server.video internal port:%d,client videoIP:%s, client videoPort:%d,msgtag:%s" 
    				, receiveDevVideoPort
    				, m_sVideoIp.c_str()
    				, m_iVideoPort
    				, GetMsgTag().c_str());

	logbody="push video stream from port:"+std::to_string(receiveDevVideoPort)+" to client "+m_sVideoIp+":"+std::to_string(m_iVideoPort)+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/voicevideo/start");

    rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("send VOICEVIDEO_START to udp server fails.msgtag:%s", GetMsgTag().c_str());
        return ;
    }



    /**
    * ... 创建发送给udpserver的消息 ...
    * ... 通知udpserver创建监听客户端音频的服务....
    */
    bzero(portmessage, sizeof(S_clientToIPCMsg));
    // portmessage->sendtoip = m_sdevReceiveIp;
    strncpy(portmessage->sendToIp, m_sdevReceiveIp.c_str(), 64);
    portmessage->sendToPort = m_idevReceivePort;
    portmessage->localPort = receiveCltVoicePort;
    portmessage->command =VOICEVIDEO_START;
    strncpy(portmessage->chDevIndeCode, GetMsgTag().c_str(), GetMsgTag().size());

    LOG_INFO_("send VOICEVIDEO_START to udp server.dev receive internal port:%d,dev receive voiceIP:%s, dev receive voicePort:%d,msgtag:%s" 
    				, receiveCltVoicePort
    				, m_sdevReceiveIp.c_str()
    				, m_idevReceivePort
    				, GetMsgTag().c_str());

	logbody="push video stream from port:"+std::to_string(receiveCltVoicePort)+".receive stream from client "+m_sdevReceiveIp+":"+std::to_string(m_idevReceivePort)+", msgtag:"+GetMsgTag();
	WriteTraceLogInternal(logbody, "INFO", "/voicevideo/start");

    rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("send VOICEVIDEO_START to udp server fails.msgtag:%s", GetMsgTag().c_str());
        return ;
    }

    delete portmessage;
    portmessage = NULL;

    m_bReplyStatus = encodeSuccessData(receiveDevVideoPort, receiveDevVoicePort, receiveCltVoicePort);
    //
    AudioVideoClient clientAV;
    clientAV.m_sDevCode                 = m_sDeviceCode;

    clientAV.sIpDevRcvAudio             = m_sdevReceiveIp;
    clientAV.uiPortDevRcvAudio          = m_idevReceivePort;
    clientAV.uiPortRelayAudioToDev      = receiveCltVoicePort;

    clientAV.sIpClientRcvStream         = m_sVideoIp;
    clientAV.uiPortClientRcvStream      = m_iVideoPort;
    clientAV.uiPortRelayVideoToClient   = receiveDevVideoPort;

    clientAV.sIpClientRcvAudio          = m_sVoiceIp;
    clientAV.uiPortClientRecvAudio      = m_iVoicePort;
    clientAV.uiPortRelayAudioToClient   = receiveDevVoicePort;

    m_pHttpServer->m_AudioVideoSession.insert(std::make_pair( m_sDeviceCode, clientAV ));
    
    m_pHttpServer->InsertDevCodeInVoiceVideoNode(m_sDeviceCode);
    //
}

/**********
***@brief encodeSuccessData 封装返回给可视对讲客户端的数据
***@param devvideoport videoport
***@param devvoiceport voiceport
***@param cltvoiceport 接收客户端音频的服务的端口
***@return bool　　ture 成功
***@remark 后期可以考虑一些数据从配置文件获取
**********/
bool HandleVoiceVideoStart::encodeSuccessData(int devvideoport,int devvoiceport,int cltvoiceport )
{
    Document doc;
    doc.SetObject();
    Document::AllocatorType &allocator = doc.GetAllocator(); //获取分配器

    doc.AddMember("errMsg", "success!", allocator);
    doc.AddMember("success", true, allocator);

    rapidjson::Value info_object(rapidjson::kObjectType);

    Value author;
    char buf[64];
    string sServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");
    int len = sprintf(buf, "%s", sServerIp.c_str()); // 动态创建的字符串。
    author.SetString(buf, len, allocator);

    info_object.AddMember( "receiveDevVideoIp", author, allocator);
    info_object.AddMember( "receiveDevVideoPort", devvideoport, allocator);

    author.SetString(buf, len, allocator);
    info_object.AddMember( "receiveDevVoiceIp", author, allocator);
    info_object.AddMember( "receiveDevVoicePort", devvoiceport , allocator);

    author.SetString(buf, len, allocator);
    info_object.AddMember( "receiveCltVoiceIp", author, allocator);
    info_object.AddMember( "receiveCltVoicePort", cltvoiceport , allocator);

    const std::string&  sIpMtsHttp = HandleBase::GetMTSHttpIp();
    author.SetString(sIpMtsHttp.c_str(), sIpMtsHttp.size(), allocator);
    info_object.AddMember( "mtsIp", author, allocator);
    info_object.AddMember( "mtsPort", HandleBase::GetMTSHttpPort(), allocator);

    bzero(buf, sizeof(buf));

    doc.AddMember("data", info_object, allocator);

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    doc.Accept(writer);
    //cout << buffer.GetString() << endl;

    m_sSuccessData = buffer.GetString();
    LOG_DEBUG_("send resp: %s", m_sSuccessData.c_str());

    return true;
}
/**********
***@brief receiveDataParse 客户端json数据解析
***@param urldata 客户端的json数据
***@return bool　　ture 成功
***@remark
**********/
bool HandleVoiceVideoStart::receiveDataParse(std::string& urldata, const char *peerIp )
{
	LOG_INFO_("http req:%s", urldata.c_str());
    if(urldata.empty())
    {
        LOG_ERROR_("urldata is NULL");
        return false;
    }

    Document document;
    document.Parse<0>(urldata.c_str());
    if( document.HasParseError() )
    {
        /* 报错 */
        //cout<<"Parse错误描述:"<<rapidjson::GetParseError_En(document.GetParseError())<<endl ;
        cout<<"urldata"<<urldata<<endl ;
        m_bReplyStatus = false ;
        LOG_ERROR_("document parse error") ;
        return false ;
    }

    if( !document.IsObject() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document parse error") ;
        return false ;
    }

    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse deviceCode error") ;
        return false ;
    }

    m_sDeviceCode = document["deviceCode"].GetString();

    if( !document.HasMember("voiceIp") || !document["voiceIp"].IsString())
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("http req parse voiceIp error.msgtag:%s", m_sDeviceCode.c_str());
        return false ;
    }

    m_sVoiceIp = document["voiceIp"].GetString();

    if( !document.HasMember("voicePort") || !document["voicePort"].IsInt() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse voicePort error.msgtag:%s", m_sDeviceCode.c_str());
        return false ;
    }
    m_iVoicePort = document["voicePort"].GetInt();

	SetMsgTag(m_sDeviceCode);

	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {	
		traceId=document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);
		InitUdpLogBase(traceId, spanId, _peerIp);
	}

    if( !document.HasMember("videoIp") || !document["videoIp"].IsString() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse videoIp error.msgtag:%s", GetMsgTag().c_str());
        return false ;
    }
    m_sVideoIp = document["videoIp"].GetString();

    if( !document.HasMember("videoPort") || !document["videoPort"].GetInt() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse videoPort error.msgtag:%s", GetMsgTag().c_str());
        return false ;
    }
    m_iVideoPort = document["videoPort"].GetInt();

    if( !document.HasMember("devReceiveIp") || !document["devReceiveIp"].IsString() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse devReceiveIp error.msgtag:%s", GetMsgTag().c_str());
        return false ;
    }
    m_sdevReceiveIp = document["devReceiveIp"].GetString();

    if( !document.HasMember("devReceivePort") || !document["devReceivePort"].IsInt() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse devReceivePort error.msgtag:%s", GetMsgTag().c_str());
        return false ;
    }
    m_idevReceivePort = document["devReceivePort"].GetInt();
    
    LOG_INFO_("http req parse OK. url:%s, deviceCode:%s, voiceIp:%s, voicePort:%d, videoIp:%s, videoPort:%d, devReceiveIp:%s, devReceivePort:%d.msgtag:%s"
    					, "/voicevideo/start"
    					, m_sDeviceCode.c_str()
   						, m_sVoiceIp.c_str()
						, m_iVoicePort
						, m_sVideoIp.c_str()
						, m_iVideoPort
						, m_sdevReceiveIp.c_str()
						, m_idevReceivePort
						, GetMsgTag().c_str()
    					);


    WriteHttpReqTraceLog(urldata, "INFO", "/voicevideo/start");
    m_bReplyStatus = true ;
    return true;
}

void HandleVoiceVideoStart::getReplyData(std::string& replaydata)
{
    //test 
    //m_bReplyStatus = true;

    if(true == m_bReplyStatus)
    {
        replaydata = m_sSuccessData;
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
	string logbody="HttpRsp:"+replaydata+", msgtag:"+GetMsgTag();
    LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/voicevideo/start");
}


HandleVoiceVideoStop::HandleVoiceVideoStop()
  : m_pUdpPortPool( NULL )
  , m_bReplyStatus( false )
  , m_pHttpServer( NULL )
  , m_iReceivePort( 0 )
  , m_iStreamProfile( 0 )
{
    //...
}

HandleVoiceVideoStop::~HandleVoiceVideoStop()
{
    //...
}

void HandleVoiceVideoStop::init(std::string& urldata, HttpServer* httpserver)
{
    m_sReceiveData = urldata ;
    m_pUdpPortPool = httpserver->GetPortPool() ;
    m_sServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");

    m_pHttpServer = httpserver;
}

void HandleVoiceVideoStop::deal(const char *peerIp )
{
    bool status = this->receiveDataParse(m_sReceiveData, peerIp) ;
    if (false == status)
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("receiveData Parse error.msgtag:%s", GetMsgTag().c_str());
		WriteHttpReqTraceLog(m_sReceiveData, "ERROR", "/voicevideo/stop");
        return ;
    }

    /***
    ***由设备编码获取端口值
    ***并从map中删除设备数据
    ***/
    map<string,vector<int> >::iterator it;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it == m_pUdpPortPool->m_mapDevecePort.end())
    {
        m_bReplyStatus = false;
        LOG_ERROR_("not find the devicecode: %s, maybe had been released.msgtag:%s", m_sDeviceCode.c_str(), GetMsgTag().c_str());
        return ;
    }

    //创建停止监听端口的消息
    pS_clientToIPCMsg portmessage = NULL ;

    /***
    ***循环遍历端口向量
    ***获取端口并在端口池释放
    ***发送释放监听socket
    ***/

    // LOG_INFO_("start release........ port");
    vector<int> valueport = m_pUdpPortPool->m_mapDevecePort[m_sDeviceCode];
    vector<int>::const_iterator iter = valueport.begin();
    for (; iter!=valueport.end(); ++iter )
    {
		string logbody="stop push stream to port:"+std::to_string(*iter)+", msgtag:"+GetMsgTag();
        LOG_ERROR_(logbody.c_str());
		WriteTraceLogInternal(logbody, "INFO", "/voicevideo/stop");

        m_pUdpPortPool->ReleaseUdpPort(*iter );
        string clientip = "0.0.0.0";
        portmessage = new S_clientToIPCMsg(clientip.c_str(), 0, *iter, VOICEVIDEO_STOP, GetMsgTag() );
        //portmessage->display();
        if(NULL == portmessage)
        {
            m_bReplyStatus = false;
            LOG_ERROR_("creat portmessage error.out of memory.msgtag:%s", GetMsgTag().c_str());
            return ;
        }

        LOG_INFO_("send VOICEVIDEO_STOP to udp server.internal port:%d.msgtag:%s" , *iter, GetMsgTag().c_str());

        UdpClient  udpclient;
        int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
        if(rec < 0)
        {
            m_bReplyStatus = false;
            LOG_ERROR_("send VOICEVIDEO_STOP to udp server fails.msgtag:%s", GetMsgTag().c_str());
            return ;
        }

       // usleep(5000);
        if(NULL != portmessage)
        {
            delete portmessage;
            portmessage = NULL;
        }
    }

    if(NULL != portmessage)
    {
        delete portmessage;
        portmessage = NULL;
    }

    m_pUdpPortPool->m_mapDevecePort.erase (it);

    auto itAV = m_pHttpServer->m_AudioVideoSession.find(m_sDeviceCode);
    if ( itAV != m_pHttpServer->m_AudioVideoSession.end() )
    {
        m_pHttpServer->m_AudioVideoSession.erase(itAV);
    }

    m_pHttpServer->DelDevCodeFromVoiceVideoNode(m_sDeviceCode);
    m_bReplyStatus = true ;
}

bool HandleVoiceVideoStop::receiveDataParse(std::string& urldata, const char *peerIp )
{
    LOG_INFO_("http req:%s", urldata.c_str());
    if(urldata.empty())
    {
        LOG_ERROR_("urldata is NULL");
        return false;
    }

    Document document;
    document.Parse<0>(urldata.c_str());
    if( document.HasParseError() )
    {
        /* 报错 */
        LOG_INFO_("Parse错误描述:%s",rapidjson::GetParseError_En(document.GetParseError())) ;

        return false ;
    }
    if( !document.IsObject() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("json parse error") ;
        return false ;
    }

    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse deviceCode error") ;
        return false ;
    }
    m_sDeviceCode = document["deviceCode"].GetString();
    
	SetMsgTag(m_sDeviceCode);

	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {
		traceId = document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);
		InitUdpLogBase(traceId, spanId, _peerIp);
	}

    LOG_INFO_("http req parse OK. url:%s, deviceCode:%s"
    					, "/voicevideo/stop"
    					, m_sDeviceCode.c_str()
    					);

    WriteHttpReqTraceLog(urldata, "INFO", "/voicevideo/stop");
    return true;
}

void HandleVoiceVideoStop::getReplyData(std::string& replaydata)
{
    if(true == m_bReplyStatus)
    {
        replaydata = "{\"errMsg\": \"success!\", \"success\": true}";
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }

	string logbody="HttpRsp:"+replaydata+", msgtag:"+GetMsgTag();
    LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/voicevideo/stop");
}

void HandleVoiceVideoStop::ReleaseRelayPort()
{
    /***
    ***由设备编码获取端口值
    ***并从map中删除设备数据
    ***/
    map<string,vector<int> >::iterator it;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it == m_pUdpPortPool->m_mapDevecePort.end())
    {
        m_bReplyStatus = false;
        LOG_ERROR_("not find the devicecode: %s, maybe had been released.msgtag:%s", m_sDeviceCode.c_str(), GetMsgTag().c_str());
        return ;
    }

    //创建停止监听端口的消息
    pS_clientToIPCMsg portmessage = NULL ;

    /***
    ***循环遍历端口向量
    ***获取端口并在端口池释放
    ***发送释放监听socket
    ***/

    // LOG_INFO_("start release........ port");
    vector<int> valueport = m_pUdpPortPool->m_mapDevecePort[m_sDeviceCode];
    vector<int>::const_iterator iter = valueport.begin();
    for (; iter!=valueport.end(); ++iter )
    {
        LOG_ERROR_("release port: %d.msgtag:%s", *iter, GetMsgTag().c_str());
        m_pUdpPortPool->ReleaseUdpPort(*iter );
        string clientip = "0.0.0.0";
        portmessage = new S_clientToIPCMsg(clientip.c_str(), 0, *iter, VOICEVIDEO_STOP, GetMsgTag() );
        //portmessage->display();
        if(NULL == portmessage)
        {
            m_bReplyStatus = false;
            LOG_ERROR_("creat portmessage error.out of memory.msgtag:%s", GetMsgTag().c_str());
            return ;
        }

        LOG_INFO_("send VOICEVIDEO_STOP to udp server.internal port:%d.msgtag:%s" , *iter, GetMsgTag().c_str());

        UdpClient  udpclient;
        int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, (void*)portmessage, sizeof(S_clientToIPCMsg));
        if(rec < 0)
        {
            m_bReplyStatus = false;
            LOG_ERROR_("send VOICEVIDEO_STOP to udp server fails.msgtag:%s", GetMsgTag().c_str());
            return ;
        }

       // usleep(5000);
        if(NULL != portmessage)
        {
            delete portmessage;
            portmessage = NULL;
        }
    }

    if(NULL != portmessage)
    {
        delete portmessage;
        portmessage = NULL;
    }

    m_pUdpPortPool->m_mapDevecePort.erase (it);

    auto itAV = m_pHttpServer->m_AudioVideoSession.find(m_sDeviceCode);
    if ( itAV != m_pHttpServer->m_AudioVideoSession.end() )
    {
        m_pHttpServer->m_AudioVideoSession.erase(itAV);
    }
}


