///////////////////////////////////////////////////////////////
//
// FileName : tutkServer.cpp
// Creator : chenbo
// Date : 2018-2-24 
// Comment :
//
///////////////////////////////////////////////////////////////

#include "tutkServer.h"
#include "udpClient.h"
#include <thread>
#include "log.h"
#include "udpLogBase.h"

#define AUDIO_BUF_SIZE	1024

//重新定义tutk模块日志
#define TUTK_LOG_INFO(args, ...)  do { \
	char  buffer[FMT_LEN];\
	snprintf(buffer,FMT_LEN,"[%s %s (%d) ]:ClouldSpeakSession %s",__FILE__, __FUNCTION__, __LINE__,args);\
	pMTSLog->info(buffer,##__VA_ARGS__);\
 } while(0) 

#define  TUTK_LOG_ERROR(args, ...) do { \
	char  buffer[FMT_LEN];\
	snprintf(buffer,FMT_LEN,"[%s %s (%d) ]:ClouldSpeakSession %s",__FILE__, __FUNCTION__, __LINE__,args);\
	pMTSLog->error(buffer,##__VA_ARGS__);\
} while(0)

#define TUTK_LOG_DEBUG(args, ...) do { \
	char  buffer[FMT_LEN];\
	snprintf(buffer,FMT_LEN,"[%s %s (%d) ]:ClouldSpeakSession %s",__FILE__, __FUNCTION__, __LINE__,args);\
	pMTSLog->debug(buffer,##__VA_ARGS__);\
} while(0)

#define TUTK_LOG_NOTICE(args, ...) do { \
	char  buffer[FMT_LEN];\
	snprintf(buffer,FMT_LEN,"[%s %s (%d) ]:ClouldSpeakSession %s",__FILE__, __FUNCTION__, __LINE__,args);\
	pMTSLog->error(buffer,##__VA_ARGS__);\
} while(0)


void tutk_recv_func(int AV_Channel_ID, AV_Client client)
{
	int SID = client.nClientSid;
	int  nResend = 0;

	unsigned int servType;
	int avIndex = avClientStart2(SID, NULL, NULL, 30, &servType, client.nSpeakerCh, &nResend);

	LOG_NOTICE_("ClouldSpeakSession Tutk ReceiveAudio Client start ok idx[%d], ip[%s] port[%d]", avIndex, client.chSpeakSendToIp, client.nSpeakSendToPort);

	if(avIndex > -1)
	{
		char buf[AUDIO_BUF_SIZE];
		FRAMEINFO_t frameInfo;
		unsigned int frmNo = 0;

        avClientCleanAudioBuf(client.nSpeakerCh);

        UdpClient udpclient;
        int nRecvAudioLog = 0;
		while(client.bEnableSpeaker)
		{
			int ret = avRecvAudioData(avIndex, buf, AUDIO_BUF_SIZE, (char *)&frameInfo, sizeof(FRAMEINFO_t), &frmNo);
			if(ret == AV_ER_SESSION_CLOSE_BY_REMOTE)
			{
			    LOG_NOTICE_("ClouldSpeakSession avRecvAudioData AV_ER_SESSION_CLOSE_BY_REMOTE");
				break;
			}
			else if(ret == AV_ER_REMOTE_TIMEOUT_DISCONNECT)
			{
			    LOG_NOTICE_("ClouldSpeakSession avRecvAudioData AV_ER_REMOTE_TIMEOUT_DISCONNECT");
				break;
			}
			else if(ret == IOTC_ER_INVALID_SID)
			{
			    LOG_NOTICE_("ClouldSpeakSession avRecvAudioData Session[%d] cant be used anymore", SID);
				break;
			}
			else if(ret == AV_ER_LOSED_THIS_FRAME)
			{
			    LOG_NOTICE_("ClouldSpeakSession Audio LOST[%d] ", frmNo);
				continue;
			}
			else if (ret == AV_ER_DATA_NOREADY)
            {
                usleep(40000);
                continue;
            }
			else if(ret < 0)
			{
			    LOG_NOTICE_("ClouldSpeakSession avRecvAudioData Other error[%d]!!!", ret);
				break;
			}
			else
			{
			    //printf("avRecvAudioData[%d], idx[%d]", ret, avIndex);
				//TODO...
			}
            if(nRecvAudioLog < 20)
            {
                nRecvAudioLog ++;
                LOG_NOTICE_("ClouldSpeakSession send Tutk Auduio Data start Ip[%s] port[%d] SID[%d] AV[%d]", client.chSpeakSendToIp, \
                    client.nSpeakSendToPort, SID, avIndex);
            }
            
            int rec = udpclient.sendTo(client.chSpeakSendToIp, client.nSpeakSendToPort, (void*)buf, ret);
            if(rec <= 0)
            {
                LOG_NOTICE_("ClouldSpeakSession send Tutk Auduio Data Fail ret[%d]", rec);
                break;
            }

		}
	}

	avClientStop(avIndex);
    LOG_NOTICE_("ClouldSpeakSession Tutk ReceiveAudio Client Stop idx[%d]", avIndex);
}

bool CreateAudioRecver(int AV_Channel_ID, AV_Client& client)
 {
		try
		{
			std::thread th(tutk_recv_func, AV_Channel_ID, client);
			th.detach();
		}
		catch (...)
		{
            LOG_NOTICE_("ClouldSpeakSession Tutk CreateAudioRecver Create Recver Fail");
			return false;
		}
        return true;
 }


unsigned int GetTimeStamp()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (tv.tv_sec*1000 + tv.tv_usec/1000);
}

void Handle_IOCTRL_Cmd(int nSID, int nAVIndex, char* pchBuf, int nType)
{
    switch(nType)
	{
		case IOTYPE_USER_IPCAM_START:
		{
			SMsgAVIoctrlAVStream *pstAVIoctrlInfo = (SMsgAVIoctrlAVStream *)pchBuf;
            string strDevUUID((char*)pstAVIoctrlInfo->dev_uuid);
            AV_Client stClientLinkInfo ;
            CTutkServer::instance()->GetLinkInfoBySID(stClientLinkInfo, strDevUUID, nSID);
            stClientLinkInfo.nAVIndex = nAVIndex;
            stClientLinkInfo.bEnableVideo = true;
            stClientLinkInfo.nClientSid = nSID;
            stClientLinkInfo.nVideoDataLogNum = 0;
            CTutkServer::instance()->UpdateLinkInfoBySID(strDevUUID, stClientLinkInfo, nSID);
            
            LOG_NOTICE_("ClouldSpeakSession IOTYPE_USER_IPCAM_START DevUUID[%s] AvIndex[%d] SID[%d] ", strDevUUID.c_str(), nAVIndex, nSID);
		}
		break;
		case IOTYPE_USER_IPCAM_STOP:
		{
			SMsgAVIoctrlAVStream *pstAVIoctrlInfo = (SMsgAVIoctrlAVStream *)pchBuf;
            string strDevUUID((char*)pstAVIoctrlInfo->dev_uuid);
            AV_Client stClientLinkInfo ;
            CTutkServer::instance()->GetLinkInfoBySID(stClientLinkInfo, strDevUUID, nSID);
            //stClientLinkInfo.nAVIndex = nAVIndex;
            stClientLinkInfo.bEnableVideo = false;
            stClientLinkInfo.nVideoDataLogNum = 0;
            CTutkServer::instance()->UpdateLinkInfoBySID(strDevUUID, stClientLinkInfo, nSID);
            
            LOG_NOTICE_("ClouldSpeakSession IOTYPE_USER_IPCAM_STOP  DevUUID[%s] SID[%d]", strDevUUID.c_str(),nSID);
		}
		break;
        case IOTYPE_USER_IPCAM_AUDIOSTART:
		{
			SMsgAVIoctrlAVStream *pstAVIoctrlInfo = (SMsgAVIoctrlAVStream *)pchBuf;
			string strDevUUID((char*)pstAVIoctrlInfo->dev_uuid);
            AV_Client stClientLinkInfo ;
                                     
            CTutkServer::instance()->GetLinkInfoBySID(stClientLinkInfo, strDevUUID, nSID);
            stClientLinkInfo.bEnableAudio = true;
            stClientLinkInfo.nClientSid = nSID;
            stClientLinkInfo.nAudioDataLogNum = 0;
            CTutkServer::instance()->UpdateLinkInfoBySID(strDevUUID, stClientLinkInfo, nSID);

            LOG_NOTICE_("ClouldSpeakSession IOTYPE_USER_IPCAM_AUDIOSTART  DevUUID[%s] AvIndex[%d] ", strDevUUID.c_str(), nAVIndex);
		}
		break;
        case IOTYPE_USER_IPCAM_AUDIOSTOP:
		{
			SMsgAVIoctrlAVStream *pstAVIoctrlInfo = (SMsgAVIoctrlAVStream *)pchBuf;
            string strDevUUID((char*)pstAVIoctrlInfo->dev_uuid);
            AV_Client stClientLinkInfo ;
            CTutkServer::instance()->GetLinkInfoBySID(stClientLinkInfo, strDevUUID, nSID);

            stClientLinkInfo.bEnableAudio = false;
            stClientLinkInfo.nAudioDataLogNum = 0;
            CTutkServer::instance()->UpdateLinkInfoBySID(strDevUUID, stClientLinkInfo, nSID);
            LOG_NOTICE_("ClouldSpeakSession IOTYPE_USER_IPCAM_AUDIOSTOP  DevUUID[%s] SID[%d]", strDevUUID.c_str(), nSID);
		}
		break;
        case IOTYPE_USER_IPCAM_SPEAKERSTART:
		{
            //APP Start Speak
		    SMsgAVIoctrlAVStream *pstAVIoctrlInfo = (SMsgAVIoctrlAVStream *)pchBuf;
            string strDevUUID((char*)pstAVIoctrlInfo->dev_uuid);
            AV_Client stClientLinkInfo ;
            CTutkServer::instance()->GetLinkInfoBySID(stClientLinkInfo, strDevUUID, nSID);
            stClientLinkInfo.nAVIndex = nAVIndex;
            stClientLinkInfo.nSpeakerCh = pstAVIoctrlInfo->channel;
            stClientLinkInfo.bEnableSpeaker = true;
            stClientLinkInfo.nClientSid = nSID;
            CTutkServer::instance()->UpdateLinkInfoBySID(strDevUUID, stClientLinkInfo, nSID);

            LOG_INFO_("ClouldSpeakSession Tutk Recv IOTYPE_USER_IPCAM_SPEAKERSTART dev[%s] chnl[%d] idx[%d] sid[%d]",strDevUUID.c_str(), pstAVIoctrlInfo->channel,nAVIndex,nSID);

            //获取目的端口
            AV_Client_Dst stClientDstOut;
            int iRet = CTutkServer::instance()->GetClientDstInfoByDevUUID(stClientDstOut, strDevUUID);
            if(-1 == iRet)
            {
                LOG_NOTICE_("ClouldSpeakSession IOTYPE_USER_IPCAM_SPEAKERSTART get Dst fail [%s] ", strDevUUID.c_str());   
            }
                
            stClientLinkInfo.nSpeakSendToPort = stClientDstOut.nSpeakSendToPort;
            strncpy(stClientLinkInfo.chSpeakSendToIp , stClientDstOut.chSpeakSendToIp, MAX_IP_LEN-1);
            
            CreateAudioRecver(nAVIndex, stClientLinkInfo);

		}
		break;
        case IOTYPE_USER_IPCAM_SPEAKERSTOP:
		{
            //APP Stot Speak

            SMsgAVIoctrlAVStream *pstAVIoctrlInfo = (SMsgAVIoctrlAVStream *)pchBuf;
            string strDevUUID((char*)pstAVIoctrlInfo->dev_uuid);
            AV_Client stClientLinkInfo ;
            CTutkServer::instance()->GetLinkInfoBySID(stClientLinkInfo, strDevUUID, nSID);
            stClientLinkInfo.bEnableSpeaker = false;
            CTutkServer::instance()->UpdateLinkInfoBySID(strDevUUID, stClientLinkInfo, nSID);
            
            LOG_NOTICE_("ClouldSpeakSession IOTYPE_USER_IPCAM_SPEAKERSTOP  DevUUID[%s] ", strDevUUID.c_str());

		}
		break;
		default:
		break;
	}	
}

void pfnLoginInfoCBCallBack(unsigned int uLoginInfo)
{
	if((uLoginInfo & 0x04))
    {   
        LOG_ERROR_("ClouldSpeakSession pfnLoginInfoCBCallBack_: I can be connected via Internet!");
    }
	else if((uLoginInfo & 0x08))
    {
        LOG_ERROR_("ClouldSpeakSession pfnLoginInfoCBCallBack_: I am be banned by IOTC Server because UID multi-login!");
    }   
        
}

int pfnAuthCallBack(char *viewAcc,char *viewPwd)
{
	if(strcmp(viewAcc, "admin") == 0 && strcmp(viewPwd, "888888") == 0)
		return 1;

	return 0;
}


void *thread_ForAVServerStart(void *arg)
{
    unsigned int uIOType;
    char chIOCtrlBuf[TUTK_MAX_SIZE_IOCTRL_BUF];
    struct st_SInfo stSinfo;

    if(NULL==arg)
    {
        return (void*)NULL;
    }
    
	int nSid = *(int *)arg;
	free(arg);
	
	int nResend=-1;
	int nAVIndex = avServStart3(nSid, pfnAuthCallBack, 0, TUTK_SERVTYPE_STREAM_SERVER, 0, &nResend);
	
	if(nAVIndex < 0)
	{
		IOTC_Session_Close(nSid);
		//gOnlineNum--;
		pthread_exit(0);
	}
	if(IOTC_Session_Check(nSid, &stSinfo) == IOTC_ER_NoERROR)
	{
	    LOG_NOTICE_("ClouldSpeakSession IOTC_Session_Check sucessed! sid[%d], idx[%d]", nSid, nAVIndex);
        
        LOG_NOTICE_("Client is from[IP:%s, Port:%d]  VPG[%d:%d:%d] VER[%X] NAT[%d] AES[%d]\n", stSinfo.RemoteIP,\
            stSinfo.RemotePort,  stSinfo.VID, stSinfo.PID, stSinfo.GID, stSinfo.IOTCVersion, stSinfo.NatType, stSinfo.isSecure);
	}
    int sizeResendBufLen = 1024;
	avServSetResendSize(nAVIndex, sizeResendBufLen);
    unsigned int getResendBufLen = 0;
    int iRet = avServGetResendSize(nAVIndex, &getResendBufLen);
	LOG_NOTICE_("get resendbuf ret: %d, channel id: %d, reSednBufLen: %d", iRet, nAVIndex, getResendBufLen);
	while(1)
	{
		int nRet = avRecvIOCtrl(nAVIndex, &uIOType, (char *)&chIOCtrlBuf, TUTK_MAX_SIZE_IOCTRL_BUF, 1000);
		if(nRet >= 0)
		{
			Handle_IOCTRL_Cmd(nSid, nAVIndex, chIOCtrlBuf, uIOType);
		}
		else if(nRet != AV_ER_TIMEOUT)
		{
			LOG_ERROR_("ClouldSpeakSession avIndex[%d], avRecvIOCtrl error, code[%d]\n",nAVIndex, nRet);
			break;
		}
	}

	avServStop(nAVIndex);
	IOTC_Session_Close(nSid);
	pthread_exit(0);
}


void *thread_TutkListenStart(void *arg)
{
    CTutkServer* pcTutkObj = static_cast<CTutkServer*>(arg);
    int nSID = 0;
    usleep(1000);
    while (true == pcTutkObj->m_bIsRuning)
    {
        int* pnSid = NULL;
        int nRet = 0;  
        
        // Accept connection only when IOTC_Listen() calling
        nSID = IOTC_Listen(0);
        if(nSID < 0)
        {
            LOG_NOTICE_("ClouldSpeakSession IOTC_Listen fail %d",nSID);
            if(nSID == IOTC_ER_EXCEED_MAX_SESSION)
            {
            }
            sleep(5);
            continue;
        }
        
        pnSid = (int *)malloc(sizeof(int));
        *pnSid = nSID;
        pthread_t Thread_ID;
        nRet = pthread_create(&Thread_ID, NULL, &thread_ForAVServerStart, (void *)pnSid);
        if(nRet < 0)
        {
             LOG_NOTICE_("ClouldSpeakSession pthread_create failed ret[%d] ", nRet);
        }
        else
        {
            pthread_detach(Thread_ID);
        }
    }
    LOG_NOTICE_("ClouldSpeakSession thread_TutkListenStart exit SID[%d]",nSID );
    pthread_exit(0);
}


CTutkServer::CTutkServer()
{
    m_iLogFrameNum      = 0;
    m_iLogVoiceNum      = 0;
    m_pthListenThreadID = 0;
    pthread_mutex_init(&m_iServerLinkLock,NULL);
    pthread_mutex_init(&m_iClientDstLock,NULL);
    m_bIsRuning     = true;
	m_pTutkReconn   = NULL;
    m_bAtomicInit   = false;
}

CTutkServer::~CTutkServer()
{
    Fini();
}


int CTutkServer::Init(const string& strUUID)
{
	LOG_NOTICE_("ClouldSpeakSession Init start");
	m_bIsRuning = true;
    m_sUUID = strUUID;
    
    if ( DevLogin(strUUID) == false )
    {
        LOG_ERROR_("ClouldSpeakSession login fail in main pthread, uuid: %s", strUUID.c_str());
		UdpLogBase logclient;
		logclient.WriteMonitorLog("TutkLoginFail", "uuid:"+strUUID);
    }

    int32_t iRelogInterTm = 60;
    std::string sRelogInterTm;
    sRelogInterTm = ConfigXml::getIns()->getValue( "Tutk",  "ReLogInterTms" );
    if (sRelogInterTm.empty() == false)
    {
        iRelogInterTm = ::atoi(sRelogInterTm.c_str());
    }
    m_pTutkReconn = ReConnRelayNode::GetReConnRelayNode(this, iRelogInterTm);
    if (m_pTutkReconn)
    {
        if ( false == m_pTutkReconn->StartLoginCheck() )
        {
            TUTK_LOG_ERROR("start check mts login pthread fail");
        }
        else 
        {
            TUTK_LOG_DEBUG("start check mts login pthread succ, check interval tm: %d, uuid: %s",
                           iRelogInterTm, strUUID.c_str());
        }
    }

    //创建监听线程
    int nRet = pthread_create(&m_pthListenThreadID, NULL, &thread_TutkListenStart, (void *)this);
    if(nRet < 0)
    {
         LOG_NOTICE_("ClouldSpeakSession pthread_create failed ret[%d] ", nRet);
    }
    else
    {
        pthread_detach(m_pthListenThreadID);     
    }
    LOG_NOTICE_("ClouldSpeakSession Init done ");
    return 0;
}

bool CTutkServer::DevLogin(const string& strUUID)
{
	TUTK_LOG_INFO("DevLogin begin");
    if (strUUID.empty())
    {
        TUTK_LOG_ERROR("mts use uuid is empty,  ===> please check config.xml");
        return false;
    }

    int nRet = IOTC_ER_NoERROR;
    int nReLoginNum = 3;
    
    if (m_bAtomicInit == false)
    {
        IOTC_Set_Max_Session_Number(TUTK_MAX_CLIENT_NUMBER);

        nRet = IOTC_Initialize2(0);
        if(nRet != IOTC_ER_NoERROR && nRet != IOTC_ER_ALREADY_INITIALIZED)
        {
            TUTK_LOG_INFO("ClouldSpeakSession IOTC_Initialize2 err! %d, Tutk UUID: %s", nRet, strUUID.c_str());
            return false;
        }

        //IOTC_Get_Login_Info_ByCallBackFn(pfnLoginInfoCBCallBack);
        avInitialize(TUTK_MAX_CLIENT_NUMBER*3);
        m_bAtomicInit = true;
    }
    IOTC_Get_Login_Info_ByCallBackFn(pfnLoginInfoCBCallBack);

    do
    {
        nRet = IOTC_Device_Login(strUUID.c_str(), NULL, NULL);
        TUTK_LOG_INFO("IOTC_Device_Login result <%d> , Tutk UUID: %s", nRet, strUUID.c_str());
        if(nRet == IOTC_ER_NoERROR)
        {
            break;
        }
        else if( IOTC_ER_LOGIN_ALREADY_CALLED ==  nRet )
        {
            TUTK_LOG_INFO("is relogin status, Tutk UUID: %s", strUUID.c_str());
            return false;
        }
        else 
        {
            sleep(1);
        }
        --nReLoginNum;
    } while(nReLoginNum!=0);

    if (nReLoginNum <=0)
    {
        TUTK_LOG_ERROR("ClouldSpeakSession IOTC_Device_Login err! %d", nRet);
        return false;
    }
	TUTK_LOG_INFO("DevLogin end");
    return true;
}

int CTutkServer::Fini() 
{
    LOG_NOTICE_("ClouldSpeakSession Fini start");
    m_bIsRuning = false;
    if (m_pTutkReconn)
    {
        delete m_pTutkReconn;
        m_pTutkReconn = NULL;
    }
    
    if(m_pthListenThreadID > 0)
    {
       //pthread_join(m_listenThreadID,)
        m_pthListenThreadID = 0;
    }
    if (m_bAtomicInit == true)
    {
        avDeInitialize();
        IOTC_DeInitialize();
        m_bAtomicInit = false;
    }

    pthread_mutex_destroy(&m_iServerLinkLock); 
    pthread_mutex_destroy(&m_iClientDstLock); 
    
   
    LOG_NOTICE_("ClouldSpeakSession Fini sucessed ");
    return 0;
}


void CTutkServer::SendFrameData(string& strDevUUID, char* pchDataBuf, int nBufLen)
{
    
    //m_serverLinkMutex.Lock();
    iterServreLink iterLink = m_mapServerLink.find(strDevUUID);
    if (m_mapServerLink.end() == iterLink)
    {
        return;
    }
    //m_serverLinkMutex.Unlock();
    m_iLogFrameNum ++;
    FRAMEINFO_t frameInfo; 
    
    memset(&frameInfo, 0, sizeof(FRAMEINFO_t));
    frameInfo.codec_id = MEDIA_CODEC_VIDEO_H264;
    frameInfo.flags = IPC_FRAME_FLAG_IFRAME;
    frameInfo.timestamp = GetTimeStamp();
    frameInfo.onlineNum = 1;
    
    iterAVClientMap iterClient = iterLink->second.begin(); 
    for (; iterLink->second.end() != iterClient; ++iterClient)
    {
        if(true == iterClient->second.bEnableVideo)
        {
            iterClient->second.nVideoDataLogNum++;
            if(iterClient->second.nVideoDataLogNum < 20)
            {
                LOG_DEBUG_("ClouldSpeakSession SendFrameData start  DevUUID[%s] SID[%d] AVIndex[%d], sendtoLen: %d", strDevUUID.c_str(), \
                        iterClient->second.nClientSid, iterClient->second.nAVIndex, nBufLen);
            }
            int iRet = avSendFrameData(iterClient->second.nAVIndex, pchDataBuf, nBufLen, &frameInfo, sizeof(FRAMEINFO_t));
            if((iRet == AV_ER_SESSION_CLOSE_BY_REMOTE) 
                || (iRet == AV_ER_REMOTE_TIMEOUT_DISCONNECT)
                || (iRet == IOTC_ER_INVALID_SID)
                || (iRet < 0))
            {
                if (m_iLogFrameNum % 60 == 0)
                {
                    LOG_NOTICE_("ClouldSpeakSession SendFrameData fail  DevUUID[%s] SID[%d] ERR[%d] AVIndex[%d], sendtoLen: %d", strDevUUID.c_str(), \
                        iterClient->second.nClientSid, iRet, iterClient->second.nAVIndex, nBufLen);
                }
                iterClient->second.bEnableVideo = false;
            }
        }
        
    }
 
}

void CTutkServer::SendAudioData(string& strDevUUID, char* pchDataBuf, int nBufLen)
{
    iterServreLink iterLink = m_mapServerLink.find(strDevUUID);
    if (m_mapServerLink.end() == iterLink)
    {
        return;
    }
    //m_serverLinkMutex.Unlock();
    m_iLogVoiceNum ++;
    FRAMEINFO_t frameInfo; 
    
    memset(&frameInfo, 0, sizeof(FRAMEINFO_t));
	frameInfo.codec_id = AUDIO_CODEC;
	frameInfo.flags = (AUDIO_SAMPLE_8K << 2) | (AUDIO_DATABITS_16 << 1) | AUDIO_CHANNEL_MONO;

    frameInfo.timestamp = GetTimeStamp();
    frameInfo.onlineNum = 1;

    iterAVClientMap iterClient = iterLink->second.begin(); 
    for (; iterLink->second.end() != iterClient; ++iterClient)
    {
        if(true == iterClient->second.bEnableAudio)
        {
            iterClient->second.nAudioDataLogNum++;
            if(iterClient->second.nVideoDataLogNum < 20)
            {
                LOG_NOTICE_("ClouldSpeakSession SendAudioData start  DevUUID[%s] SID[%d] AVIndex[%d], audio sendtoLen[%d]", strDevUUID.c_str(), \
                        iterClient->second.nClientSid, iterClient->second.nAVIndex, nBufLen);
            }
            
            int iRet = avSendAudioData(iterClient->second.nAVIndex, pchDataBuf, nBufLen, &frameInfo, sizeof(FRAMEINFO_t));
            if((iRet == AV_ER_SESSION_CLOSE_BY_REMOTE) 
                || (iRet == AV_ER_REMOTE_TIMEOUT_DISCONNECT)
                || (iRet == IOTC_ER_INVALID_SID))
            {
                if(m_iLogVoiceNum % 60==0)
                {
                    LOG_NOTICE_("ClouldSpeakSession SendAudioData fail  DevUUID[%s] SID[%d] ERR[%d] AVIndex[%d], audio sendtoLen[%d]", strDevUUID.c_str(), \
                        iterClient->second.nClientSid, iRet, iterClient->second.nAVIndex, nBufLen);
                }
                iterClient->second.bEnableAudio = false;
            }
        }
     
    }
}

void CTutkServer::ClearServerLinkInfo(string& strDevUUID)
{
    pthread_mutex_lock(&m_iServerLinkLock);
    LOG_NOTICE_("ClouldSpeakSession LinkInfo ClearServerLinkInfo start DevUUID[%s] ", strDevUUID.c_str());
    iterServreLink iterLink = m_mapServerLink.find(strDevUUID);
    if (m_mapServerLink.end() == iterLink)
    {
        pthread_mutex_unlock(&m_iServerLinkLock);
        return;
    }
    m_mapServerLink.erase(iterLink);

    pthread_mutex_unlock(&m_iServerLinkLock);
    
    return;
}

void CTutkServer::DelServerLinkInfo(string& strDevUUID, int iSid)
{
    pthread_mutex_lock(&m_iServerLinkLock);
    LOG_NOTICE_("ClouldSpeakSession LinkInfo DelServerLinkInfo start DevUUID[%s] ", strDevUUID.c_str());
    iterServreLink iterLink = m_mapServerLink.find(strDevUUID);
    if (m_mapServerLink.end() == iterLink)
    {
        pthread_mutex_unlock(&m_iServerLinkLock);
        return;
    }

    iterAVClientMap iterClient = iterLink->second.find(iSid); 
    
    if (iterLink->second.end() == iterClient)
    {
    
        LOG_NOTICE_("ClouldSpeakSession LinkInfo DelServerLinkInfo AvClient is Empty DevId[%s] Sid[%d]", strDevUUID.c_str(), iSid);
        m_mapServerLink.erase(iterLink);
        pthread_mutex_unlock(&m_iServerLinkLock);
        return ;
    }
    
    LOG_NOTICE_("ClouldSpeakSession LinkInfo DelServerLinkInfo AV[%d] EA[%d] EV[%d] Sid[%d] ES[%d] ChS[%d] SPort[%d] SIp[%s]", iterClient->second.nAVIndex, \
                iterClient->second.bEnableAudio, iterClient->second.bEnableVideo, iterClient->second.nClientSid, iterClient->second.bEnableSpeaker, \
                iterClient->second.nSpeakerCh, iterClient->second.nSpeakSendToPort, iterClient->second.chSpeakSendToIp);
    iterLink->second.erase(iterClient);
    pthread_mutex_unlock(&m_iServerLinkLock);
    
    return;
}
int CTutkServer::GetLinkInfoBySID(AV_Client& stClientOut, string& strDevUUID, int iSid)
{
    pthread_mutex_lock(&m_iServerLinkLock);
    LOG_NOTICE_("ClouldSpeakSession LinkInfo GetLinkInfoByDevUUID start DevUUID[%s] SID[%d]", strDevUUID.c_str(), iSid);
    iterServreLink iterLink = m_mapServerLink.find(strDevUUID);
    if (m_mapServerLink.end() == iterLink)
    {
        pthread_mutex_unlock(&m_iServerLinkLock);
        return -1;
    }

    iterAVClientMap iterClient = iterLink->second.find(iSid); 
    
    if (iterLink->second.end() == iterClient)
    {
        pthread_mutex_unlock(&m_iServerLinkLock);
        return -1;
    }
    
    stClientOut.nAVIndex = iterClient->second.nAVIndex;
    stClientOut.bEnableAudio = iterClient->second.bEnableAudio;
    stClientOut.bEnableVideo = iterClient->second.bEnableVideo;
    stClientOut.nClientSid = iterClient->second.nClientSid;
    stClientOut.bEnableSpeaker = iterClient->second.bEnableSpeaker;
    stClientOut.nSpeakerCh = iterClient->second.nSpeakerCh;
    stClientOut.nSpeakSendToPort = iterClient->second.nSpeakSendToPort;
    strncpy(stClientOut.chSpeakSendToIp , iterClient->second.chSpeakSendToIp, MAX_IP_LEN-1);
    
    
    LOG_NOTICE_("ClouldSpeakSession LinkInfo GetLinkInfoByDevUUID AV[%d] EA[%d] EV[%d] Sid[%d] ES[%d] ChS[%d] SPort[%d] SIp[%s]", stClientOut.nAVIndex, \
                stClientOut.bEnableAudio, stClientOut.bEnableVideo, stClientOut.nClientSid, stClientOut.bEnableSpeaker, stClientOut.nSpeakerCh, \
                stClientOut.nSpeakSendToPort, stClientOut.chSpeakSendToIp);
    pthread_mutex_unlock(&m_iServerLinkLock);
    return 0;
}

void CTutkServer::UpdateLinkInfoBySID(string& strDevUUID, AV_Client& stClinetInfo, int iSid)
{
    
    pthread_mutex_lock(&m_iServerLinkLock);
    LOG_NOTICE_("ClouldSpeakSession LinkInfo UpdateLinkInfoByDevUUID start DevUUID[%s] ", strDevUUID.c_str());
    iterServreLink iterLink = m_mapServerLink.find(strDevUUID);
    if (m_mapServerLink.end() == iterLink)
    {
        
        AVClientMap map_AVClient;
        map_AVClient.insert(std::pair<int, AV_Client>(iSid, stClinetInfo));
        
        m_mapServerLink.insert(std::pair<string, AVClientMap>(strDevUUID, map_AVClient));

        
        LOG_NOTICE_("ClouldSpeakSession LinkInfo UpdateLinkInfoByDevUUID new insert AV[%d] EA[%d] EV[%d] Sid[%d] ES[%d] ChS[%d] SPort[%d] SIp[%s]", stClinetInfo.nAVIndex, \
                     stClinetInfo.bEnableAudio, stClinetInfo.bEnableVideo, stClinetInfo.nClientSid, stClinetInfo.bEnableSpeaker, stClinetInfo.nSpeakerCh, \
                     stClinetInfo.nSpeakSendToPort, stClinetInfo.chSpeakSendToIp);
        pthread_mutex_unlock(&m_iServerLinkLock);
        return ;
    }
    else
    {
        iterLink->second[iSid] = stClinetInfo;
        LOG_NOTICE_("ClouldSpeakSession LinkInfo UpdateLinkInfoByDevUUID update insert AV[%d] EA[%d] EV[%d] Sid[%d] ES[%d] ChS[%d] SPort[%d] SIp[%s]", stClinetInfo.nAVIndex, 
                    stClinetInfo.bEnableAudio,stClinetInfo.bEnableVideo, stClinetInfo.nClientSid, stClinetInfo.bEnableSpeaker, stClinetInfo.nSpeakerCh, 
                    stClinetInfo.nSpeakSendToPort, stClinetInfo.chSpeakSendToIp);
        pthread_mutex_unlock(&m_iServerLinkLock);
        return ;

    }
    pthread_mutex_unlock(&m_iServerLinkLock);
    
    return;
}


void CTutkServer::UpdateClientDstInfoByDevUUID(string& strDevUUID, string& strIp, int iPort)
{
    
    pthread_mutex_lock(&m_iClientDstLock);
    AV_Client_Dst stDstInfo = {0};
    strncpy(stDstInfo.chSpeakSendToIp , strIp.c_str(), MAX_IP_LEN);
    stDstInfo.nSpeakSendToPort = iPort;
    m_mapClientDst.insert(std::pair<string, AV_Client_Dst>(strDevUUID, stDstInfo));
    LOG_NOTICE_("ClouldSpeakSession LinkInfo UpdateClientDstInfoByDevUUID new insert DevUUID[%s] SPort[%d] SIp[%s]",strDevUUID.c_str(), iPort, strIp.c_str());

    pthread_mutex_unlock(&m_iClientDstLock);
    return;
}


int CTutkServer::GetClientDstInfoByDevUUID(AV_Client_Dst& stClientDstOut, string& strDevUUID)
{
    pthread_mutex_lock(&m_iClientDstLock);
    LOG_NOTICE_("ClouldSpeakSession LinkInfo GetClientDstInfoByDevUUID start DevUUID[%s] ", strDevUUID.c_str());

    iterClientDst iterDst = m_mapClientDst.find(strDevUUID);
    if (m_mapClientDst.end() == iterDst)
    {
        pthread_mutex_unlock(&m_iClientDstLock);
        return -1;
    }
    
    stClientDstOut.nSpeakSendToPort = iterDst->second.nSpeakSendToPort;
    strncpy(stClientDstOut.chSpeakSendToIp , iterDst->second.chSpeakSendToIp, MAX_IP_LEN-1);
    
    LOG_NOTICE_("ClouldSpeakSession LinkInfo GetClientDstInfoByDevUUID  DevUUID[%s] SPort[%d] SIp[%s]",strDevUUID.c_str(), stClientDstOut.nSpeakSendToPort, stClientDstOut.chSpeakSendToIp);
    pthread_mutex_unlock(&m_iClientDstLock);
    return 0;
}

void CTutkServer::ClearDstInfo(string& strDevUUID)
{

    pthread_mutex_lock(&m_iClientDstLock);
    LOG_NOTICE_("ClouldSpeakSession LinkInfo ClearServerLinkInfo start DevUUID[%s] ", strDevUUID.c_str());
    iterClientDst iterDst = m_mapClientDst.find(strDevUUID);
    if (m_mapClientDst.end() == iterDst)
    {
        pthread_mutex_unlock(&m_iClientDstLock);
        return;
    }
    m_mapClientDst.erase(iterDst);

    pthread_mutex_unlock(&m_iClientDstLock);
    
    return;
}


/**
 * @brief: TutkTimerCheckLogin 
 *
 * @return 
 *    > 0 : mts login tutk ok
 *    == 0: mts disconn tutk 
 *    < 0 : call tutk api error.
 */
int32_t CTutkServer::TutkTimerCheckLogin()
{
    uint32_t iLoginInfo = 0;
    int32_t iRet = 0;
	iRet = IOTC_Get_Login_Info( &iLoginInfo );
	//TUTK_LOG_DEBUG("get login info ret: %d, login info: %d", iRet, iLoginInfo);
    if ( iRet < 0 )
    {
        if (iRet == IOTC_ER_NOT_INITIALIZED)
        {
            TUTK_LOG_ERROR("The IOTC module is not initialized yet");
            return 0;
        }
        else 
        {
            TUTK_LOG_ERROR("The IOTC module inner error");
        }
        return -1;
    }
	if (iRet != 0)
	{
		TUTK_LOG_ERROR("mts fail login tutk nums: %d", iRet);
		return 0;
	}
    int8_t istatusLan =  iLoginInfo & 0x01;
    int8_t  istatusInternet = iLoginInfo & 0x02;
    int8_t  istatusRet = iLoginInfo & 0x03;
    if (istatusLan | istatusInternet | istatusRet)
    {
        return 1;
    }
    return 0;
}

bool CTutkServer::SrvReLoginTutk()
{
   return this->DevLogin(m_sUUID); 
}
//==================================================================================//
//
ReConnRelayNode::ReConnRelayNode(CTutkServer* pTutkSrv, int32_t iTimerTm)
    : m_pTutkSrv(pTutkSrv), m_Tid(0), m_bIsRun(false), m_iCheckTms(iTimerTm)
{
}

ReConnRelayNode::~ReConnRelayNode()
{
    m_bIsRun = false;
    pthread_join(m_Tid, NULL); 
    TUTK_LOG_INFO("recv check mts login mts thread exit, tid: %lu", m_Tid);
    m_pTutkSrv = NULL;
}

bool ReConnRelayNode::StartLoginCheck()
{
    if (m_pTutkSrv == NULL)
    {
        return false;
    }
    m_bIsRun = true;
    int iRet = pthread_create(&m_Tid,  NULL, CheckCallBack, this);
    if (iRet < 0 )
    {
        TUTK_LOG_ERROR("pthread_create() fail");
        return false;
    }
    TUTK_LOG_INFO("create check login remote tutk pthread succ, tid: [ %lu ]", m_Tid);
    return true;
}

void* ReConnRelayNode::CheckCallBack(void* pNodeParam)
{
	 TUTK_LOG_INFO("entry check login pthread: [ %lu ]", pthread_self());
     ReConnRelayNode* pNode = (ReConnRelayNode*) pNodeParam;
     if (pNode == NULL)
     {
         return NULL;
     }
     
     bool bStatus = true;
     while(pNode->GetRunStatus())
     {
         int iRet = pNode->TimerCheckLoginTutk() ;
         if ( iRet == 0 )
         {
             TUTK_LOG_ERROR("check => login status:  disconnected");
			 UdpLogBase logclient;
			 logclient.WriteMonitorLog("TutkLoginFail", "will relogin later");
             if (pNode->ReLoginTutk() == false)
             {
                 TUTK_LOG_ERROR("relogin remote tutk srv fail, now sleep tm: %d", pNode->GetCheckInterTm());
				 logclient.WriteMonitorLog("TutkLoginFail", "relogin fail");
                 bStatus = false;
                 sleep(pNode->GetCheckInterTm());
                 continue;
             }
             else 
             {
                TUTK_LOG_INFO("relogin remote tutk srv succ. now  sleep tm: %d", pNode->GetCheckInterTm()*2);
                bStatus = true;
                sleep( pNode->GetCheckInterTm()*2 );
                continue;
             }
         }
         else if ( iRet > 0 )
         {
             if (bStatus == false)
             {
                 TUTK_LOG_DEBUG("check => login status: logined. now sleep tm: %d", pNode->GetCheckInterTm()*2);
                 bStatus = true;
             }
             sleep( pNode->GetCheckInterTm()*2 );
             continue;
         }
         else 
         {
             bStatus = false;
             TUTK_LOG_DEBUG("check => check login fail, tutk api inner error, now sleep tm: %d", pNode->GetCheckInterTm()*2 );
             sleep( pNode->GetCheckInterTm()*2 );
             continue;
         }
     }
     pthread_exit(0);

     TUTK_LOG_INFO("check mts login tutk pthread exist now, tid: [ %lu ]", pNode->GetCheckPthreadId());
     return NULL;
}

void ReConnRelayNode::StopLoginCheck()
{
    LOG_INFO_("stop mts login tutk srv check pthread");
    m_bIsRun = false;
}


/**
 * @brief: TimerCheckLoginTutk 
 *      定时检测mts 和 tutk服务的连接状态.
 * @return 
 *    > 0 : mts login tutk ok
 *    == 0: mts disconn tutk 
 *    < 0 : call tutk api error.
 */
int32_t ReConnRelayNode::TimerCheckLoginTutk()
{
    if (m_pTutkSrv == NULL)
    {
        return -1;
    }
    return m_pTutkSrv->TutkTimerCheckLogin();
}

/**
 * @brief: ReLoginTutk 
 *     重新连接tutk 服务.
 *     调用 CTutkServer接口
 * @return 
 *     true: login succ.
 *     false: login fail
 */
bool ReConnRelayNode::ReLoginTutk()
{
    if (m_pTutkSrv == NULL)
    {
        return false;
    }
    return m_pTutkSrv->SrvReLoginTutk();
}

ReConnRelayNode* ReConnRelayNode::GetReConnRelayNode(CTutkServer* pTutkSrv, int32_t iTimerTm)
{
    static ReConnRelayNode* pNode = NULL;
    if (pNode == NULL)
    {
        pNode = new ReConnRelayNode(pTutkSrv, iTimerTm);
    }
    return pNode;
}
