//////////////////////////////////////////////////////////////
//
// FileName : handleCloudSpeak.cpp
// Creator  : chenbo
// Date     : 2018-02-28
// Comment  :
//
///////////////////////////////////////////////////////////////

#include "handleCloudSpeak.h"
#include "httpServer.h"
#include "tutkServer.h"

HandleCloudVoiceVideoStart::HandleCloudVoiceVideoStart() 
                            : m_iVoicePort( 0 ), m_iVideoPort( 0 ), 
                            m_idevReceivePort( 0 ), m_pUdpPortPool( NULL ),
                            m_bReplyStatus( false )
{

}

HandleCloudVoiceVideoStart::~HandleCloudVoiceVideoStart()
{
    //...
}

void HandleCloudVoiceVideoStart::init(std::string&  urldata, HttpServer* httpserver)
{
    m_sReceiveData = urldata;
    m_pUdpPortPool = httpserver->GetPortPool();
    m_bReplyStatus = false;
    m_pHttpServer  = httpserver;
}

void HandleCloudVoiceVideoStart::deal(const char *peerIp)
{
    m_bReplyStatus = this->receiveDataParse(m_sReceiveData, peerIp) ;
    if (m_bReplyStatus == false)
    {
		WriteHttpReqTraceLog(m_sReceiveData, "ERROR", "/cloudvoicevideo/start");
        return ;
    }

    if (NULL == m_pUdpPortPool)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("m_pUdpPortPool is null") ;
        return ;
    }

    /**
     * ...如果设备编码映射中没有...
     * ...从端口池获取端口....
     * ...并将端口和设备编码建立映射关系添加到端口池map中
     *
    */

    map<string,vector<int>>::iterator it ;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it != m_pUdpPortPool->m_mapDevecePort.end())
    {
        m_bReplyStatus = false;
        LOG_INFO_("ClouldSpeakSession devicecode been used.msgtag:%s", m_sDeviceCode.c_str());
		WriteMonitorLog("GetUdpPortFail", "/cloudvoicevideo/start get udp port fail, msgtag:"+m_sDeviceCode);
        return ;
    }

    //tutk接收app端音频由tutk通道决定 无需获取接收端口
    int receiveDevVoicePort = m_pUdpPortPool->GetAndCheckUdpPort() ;
    int receiveDevVideoPort = m_pUdpPortPool->GetAndCheckUdpPort() ;

    vector<int> vecport;
    vecport.push_back(receiveDevVoicePort);
    vecport.push_back(receiveDevVideoPort);

    m_pUdpPortPool->m_mapDevecePort.insert(make_pair(m_sDeviceCode,vecport));

    /**
    * ... 创建发送给udpserver的消息 ...
    * ... 通知udpserver创建视频监听服务....
    */
    S_clientToIPCMsg portmessage("", 0, receiveDevVideoPort, CLOUDVIDEO_START, m_sDeviceCode );

	
	LOG_INFO_("send CLOUDVIDEO_START to udp server.video internal port:%d, msgtag:%s" , receiveDevVideoPort, m_sDeviceCode.c_str());
	WriteTraceLogInternal("push stream from port:"+std::to_string(receiveDevVideoPort), "INFO", "/cloudvoicevideo/start");
	
    UdpClient udpclient;
    int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort, 
                               (void*)&portmessage, sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("ClouldSpeakSession send msg to udp server error, receiveDeviceVideoPort:%d, msgtag:%s", receiveDevVideoPort, m_sDeviceCode.c_str());
        return ;
    }
    // portmessage->print();

    /**
    * ... 创建发送给udpserver的消息 ...
    * ... 通知udpserver创建设备音频监听服务....
    */
    bzero( & portmessage, sizeof(S_clientToIPCMsg));
    // portmessage->sendtoip = m_sVoiceIp;
    // strncpy(portmessage->sendToIp, m_sVideoIp.c_str(), 64);
    strncpy( portmessage.chDevIndeCode, m_sDeviceCode.c_str(), 36);
    portmessage.sendToPort = 0;
    portmessage.localPort = receiveDevVoicePort;
    portmessage.command = CLOUDVOICE_START;

	LOG_INFO_("send CLOUDVIDEO_START to udp server.audio internal port:%d, msgtag:%s" , receiveDevVoicePort, m_sDeviceCode.c_str());
	WriteTraceLogInternal("push stream from port:"+std::to_string(receiveDevVoicePort), "INFO", "/cloudvoicevideo/start");

    
    rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort,  & portmessage,  sizeof(S_clientToIPCMsg));
    if(rec <= 0)
    {
        m_bReplyStatus = false;
        LOG_ERROR_("ClouldSpeakSession send msg to udp server error, receiveDeviceAudioPort:%d, msgtag:%s", receiveDevVoicePort, m_sDeviceCode.c_str());
        return ;
    }
    // portmessage->print();

    //AV_Client stClientLinkInfo ;
    string strDevIndexCode = portmessage.chDevIndeCode;

    CTutkServer::instance()->UpdateClientDstInfoByDevUUID(
                            strDevIndexCode, m_sdevReceiveIp,
                            m_idevReceivePort);

    LOG_INFO_("ClouldSpeakSession Start deal dev[%s] DstIp[%s] "
              "DstPort[%d] RecvVoicePort[%d] RecvVideoPort[%d] ",
              strDevIndexCode.c_str(), m_sdevReceiveIp.c_str(), \
              m_idevReceivePort, receiveDevVoicePort, receiveDevVideoPort);

    m_bReplyStatus = encodeSuccessData(receiveDevVideoPort, receiveDevVoicePort, 0);

    CloudAVClient avCloudClient;  
    avCloudClient.m_sDevCode                =   m_sDeviceCode;
    avCloudClient.sIpDevRecvAudio           =  m_sdevReceiveIp;
    avCloudClient.uiPortDevRecvAudio        =  m_idevReceivePort;
    avCloudClient.uiPortMtsRelayAudioToApp  = receiveDevVoicePort;
    avCloudClient.uiPortMtsRelayVideoToApp  = receiveDevVideoPort;
    m_pHttpServer->m_mpCloudAVSession.insert(std::make_pair(m_sDeviceCode, avCloudClient));

    m_pHttpServer->InsertDevCodeInVoiceVideoNode(m_sDeviceCode);
}

/**********
***@brief encodeSuccessData 封装返回给可视对讲客户端的数据
***@param devvideoport videoport
***@param devvoiceport voiceport
***@param cltvoiceport 接收客户端音频的服务的端口
***@return bool　　ture 成功
***@remark 后期可以考虑一些数据从配置文件获取
**********/
bool HandleCloudVoiceVideoStart::encodeSuccessData(int devvideoport,int devvoiceport,int cltvoiceport )
{
    Document doc;
    doc.SetObject();
    Document::AllocatorType &allocator = doc.GetAllocator(); //获取分配器

    doc.AddMember("errMsg", "success!", allocator);
    doc.AddMember("success", true, allocator);

    rapidjson::Value info_object(rapidjson::kObjectType);

    Value author;
    char buf[64];
    int len = sprintf(buf, "%s", m_sServerIp.c_str()); // 动态创建的字符串。
    author.SetString(buf, len, allocator);

    info_object.AddMember( "receiveDevVideoIp", author, allocator);
    info_object.AddMember( "receiveDevVideoPort", devvideoport, allocator);

    author.SetString(buf, len, allocator);
    info_object.AddMember( "receiveDevVoiceIp", author, allocator);
    info_object.AddMember( "receiveDevVoicePort", devvoiceport , allocator);

    author.SetString(buf, len, allocator);
    info_object.AddMember( "receiveCltVoiceIp", author, allocator);
    info_object.AddMember( "receiveCltVoicePort", cltvoiceport , allocator);

    string strUUID =  ConfigXml::getIns()->getValue( "Tutk",  "UUID"   ) ;
    len = sprintf(buf, "%s", strUUID.c_str());
    author.SetString(buf, len, allocator);
    info_object.AddMember( "tutkServerUUID", author, allocator);

    const std::string&  sIpMtsHttp = HandleBase::GetMTSHttpIp();
    author.SetString(sIpMtsHttp.c_str(), sIpMtsHttp.size(), allocator);
    info_object.AddMember( "mtsIp", author, allocator);
    info_object.AddMember( "mtsPort", HandleBase::GetMTSHttpPort(), allocator);

    bzero(buf, sizeof(buf));

    doc.AddMember("data", info_object, allocator);

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    doc.Accept(writer);
    //cout << buffer.GetString() << endl;

    m_sSuccessData = buffer.GetString();
    return true;
}
/**********
***@brief receiveDataParse 客户端json数据解析
***@param urldata 客户端的json数据
***@return bool　　ture 成功
***@remark
**********/
bool HandleCloudVoiceVideoStart::receiveDataParse(std::string& urldata, const char *peerIp)
{
	LOG_INFO_("http req:%s", urldata.c_str());
    if(urldata.empty())
    {
        LOG_ERROR_("http req is empty.");
        return false;
    }

    Document document;
    document.Parse<0>(urldata.c_str());
    if( document.HasParseError() )
    {

        m_bReplyStatus = false ;
        LOG_ERROR_("document parse error") ;
        return false ;
    }


    if( !document.IsObject() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("not an object") ;
        return false ;
    }

    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("http req parse deviceCode error") ;
        return false ;
    }

    m_sDeviceCode = document["deviceCode"].GetString();

	SetMsgTag(m_sDeviceCode);

    if( !document.HasMember("devReceiveIp") || !document["devReceiveIp"].IsString() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse devReceiveIp error, msgtag:%s", m_sDeviceCode.c_str()) ;
        return false ;
    }
    m_sdevReceiveIp = document["devReceiveIp"].GetString();

    if( !document.HasMember("devReceivePort") || !document["devReceivePort"].IsInt() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse devReceivePort error, msgtag:%s", m_sDeviceCode.c_str()) ;
        return false ;
    }
    m_idevReceivePort = document["devReceivePort"].GetInt();
	
	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {
		traceId = document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);
		InitUdpLogBase(traceId, spanId, _peerIp);
	}

    LOG_INFO_("http req parse OK. url:%s, deviceCode:%s, devReceiveIp:%s, devReceivePort:%d"
    					, "/cloudvoicevideo/start"
    					, m_sDeviceCode.c_str()
						, m_sdevReceiveIp.c_str()
						, m_idevReceivePort
    					);

	WriteHttpReqTraceLog(urldata, "INFO", "/cloudvoicevideo/start");
    m_bReplyStatus = true ;
    return true;
}

void HandleCloudVoiceVideoStart::getReplyData(std::string& replaydata)
{
    //replaydata="{\"errMsg\": \"success!\", \"success\": true}";
    //test
    //m_bReplyStatus = true;
    if(true == m_bReplyStatus)
    {
        replaydata = m_sSuccessData;
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
	string logbody="HttpRsp:"+replaydata+", msgtag:"+m_sDeviceCode;
    LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/cloudvoicevideo/start");
}

HandleCloudVoiceVideoStop::HandleCloudVoiceVideoStop() : m_pUdpPortPool( NULL ),  m_bReplyStatus( false ),  m_iReceivePort( 0 ), m_iStreamProfile( 0 )
{
    //...
}

HandleCloudVoiceVideoStop::~HandleCloudVoiceVideoStop()
{
    //...
}

void HandleCloudVoiceVideoStop::init(std::string& urldata, HttpServer* httpserver)
{
    m_pHttpServer   = httpserver;
    m_sReceiveData  = urldata ;
    m_pUdpPortPool  = httpserver->GetPortPool() ;
    m_sServerIp     = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");
}

void HandleCloudVoiceVideoStop::deal(const char *peerIp)
{
    bool status = this->receiveDataParse(m_sReceiveData, peerIp) ;
    if (false == status)
    {
		WriteHttpReqTraceLog(m_sReceiveData, "ERROR", "/cloudvoicevideo/stop");
        m_bReplyStatus = false ;
        return ;
    }

    /***
    ***由设备编码获取端口值
    ***并从map中删除设备数据
    ***/
    map<string,vector<int> >::iterator it;
    it = m_pUdpPortPool->m_mapDevecePort.find(m_sDeviceCode) ;
    if (it == m_pUdpPortPool->m_mapDevecePort.end())
    {
        m_bReplyStatus = false;
        LOG_INFO_("ClouldSpeakSession not find the devicecode: %s, maybe had been released", m_sDeviceCode.c_str());
        return ;
    }
    
    LOG_INFO_("ClouldSpeakSession Stop deal dev[%s]", m_sDeviceCode.c_str());

    //创建停止监听端口的消息

    /***
    ***循环遍历端口向量
    ***获取端口并在端口池释放
    ***发送释放监听socket
    ***/

    // log.info("start release........ port");
    vector<int> valueport = m_pUdpPortPool->m_mapDevecePort[m_sDeviceCode];
    vector<int>::const_iterator iter = valueport.begin();
    for (; iter!=valueport.end(); ++iter)
    {
        LOG_INFO_("release port: %d",*iter);
		WriteTraceLogInternal("stop push stream. port:"+std::to_string(*iter), "INFO", "/cloudvoicevideo/stop");
        m_pUdpPortPool->ReleaseUdpPort(*iter );
        string clientip = "0.0.0.0";

        S_clientToIPCMsg portmessage(clientip.c_str(), 0,*iter, VOICEVIDEO_STOP, m_sDeviceCode );
        portmessage.display();
        
		LOG_INFO_("send VOICEVIDEO_STOP to udp server.dev receive internal port:%d, msgtag:%s" , *iter, m_sDeviceCode.c_str());


        UdpClient  udpclient;
        int rec = udpclient.sendTo(m_sServerIp, m_localInterchangePort,  & portmessage, sizeof(S_clientToIPCMsg));
        if(rec < 0)
        {
            m_bReplyStatus = false;
            LOG_ERROR_("send Video portmessage error, msgtag:%s", m_sDeviceCode.c_str());
            return ;
        }
       // usleep(5000);
    }

    //清除app信息
 
    CTutkServer::instance()->ClearServerLinkInfo(m_sDeviceCode);
    CTutkServer::instance()->ClearDstInfo(m_sDeviceCode);

    LOG_INFO_("Clould Speak Stop deal dev[%s]", m_sDeviceCode.c_str());

    m_pUdpPortPool->m_mapDevecePort.erase (it);
    
    auto itCloudClient = m_pHttpServer->m_mpCloudAVSession.find( m_sDeviceCode );
    if (itCloudClient != m_pHttpServer->m_mpCloudAVSession.end())
    {
        m_pHttpServer->m_mpCloudAVSession.erase(itCloudClient);
    }

    m_pHttpServer->DelDevCodeFromVoiceVideoNode(m_sDeviceCode);
    m_bReplyStatus = true ;
}

bool HandleCloudVoiceVideoStop::receiveDataParse(std::string& urldata, const char *peerIp)
{
	LOG_INFO_("http req:%s", urldata.c_str());
    if(urldata.empty())
    {
        LOG_ERROR_("http req is empty.");
        return false;
    }

    Document document;
    document.Parse<0>(urldata.c_str());
    if( document.HasParseError() )
    {
        LOG_INFO_("Parse Document error") ;
        return false ;
    }
    if( !document.IsObject() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("not an object") ;
        return false ;
    }

    if( !document.HasMember("deviceCode") || !document["deviceCode"].IsString() )
    {
        m_bReplyStatus = false ;
		LOG_ERROR_("http req parse deviceCode error") ;
        return false ;
    }
    m_sDeviceCode = document["deviceCode"].GetString();

	SetMsgTag(m_sDeviceCode);

	string traceId;
    if( document.HasMember("traceId") && document["traceId"].IsString() )
    {
		traceId = document["traceId"].GetString();
    }

	string spanId;
    if( document.HasMember("spanId") && document["spanId"].IsString() )
    {
		spanId = document["spanId"].GetString();
    }

	if(traceId != "" && spanId != "")
	{
		string _peerIp(peerIp);
		InitUdpLogBase(traceId, spanId, _peerIp);
	}

    LOG_INFO_("http req parse OK. url:%s, deviceCode:%s"
    					, "/cloudvoicevideo/stop"
    					, m_sDeviceCode.c_str()
    					);

	WriteHttpReqTraceLog(urldata, "INFO", "/cloudvoicevideo/stop");
    return true;
}

void HandleCloudVoiceVideoStop::getReplyData(std::string& replaydata)
{
    //replaydata="{\"errMsg\": \"success!\", \"success\": true}";
    if(true == m_bReplyStatus)
    {
        replaydata = "{\"errMsg\": \"success!\", \"success\": true}";
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
	string logbody="HttpRsp:"+replaydata+", msgtag:"+m_sDeviceCode;
    LOG_INFO_(logbody.c_str());
	WriteHttpRspTraceLog(logbody, "INFO", "/cloudvoicevideo/stop");
}

