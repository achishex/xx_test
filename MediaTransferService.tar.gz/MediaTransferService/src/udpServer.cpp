//---------------------------------------------------------------------------
//
// FileName : udpServer.cpp
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : udpServer source file
//
//---------------------------------------------------------------------------
#include "udpServer.h"
#include "pthreadManager.h"
#include <cassert>
//---------------------------------------------------------------------------
void * UdpServer::thread_func(void* arg)
{
    assert( arg  !=  NULL ) ;

    struct event_base * base =   event_base_new();
    LOG_INFO_( "udp server base = %p",  base );
    assert( base  !=  NULL ) ;

    UdpServer * s  =  reinterpret_cast<UdpServer*>( arg );
    int rc = s->init();
    LOG_INFO_( "udp server init = %d",  rc );
    assert( rc  ==  0 );

    LOG_NOTICE_( "create the udp server success! %s:%d",  s->m_ip.c_str(),  s->m_port );

    s->run( base ) ;

    event_base_free( base );

    return NULL;
}
//---------------------------------------------------------------------------
UdpServer::~UdpServer()
{
    if( m_sock > 0 )  { close( m_sock );  m_sock = -1 ; }
    if( m_event )
    {
        event_del(m_event);
        event_free(m_event);
    }
}
//---------------------------------------------------------------------------
UdpServer::UdpServer( int port,  const std::string & ip )
  : m_ip( ip )
  , m_port( port )
  , m_sock( -1 )
  , m_event( NULL )
{
    bzero( & m_clientAddr,  sizeof(m_clientAddr));
}
//---------------------------------------------------------------------------
int UdpServer::init()
{
    m_sock  =  socket( AF_INET,  SOCK_DGRAM | SOCK_NONBLOCK,  0 ) ;
    if ( m_sock  <  0 )
    {
        LOG_NOTICE_("create udp socket failed, ip: %s, port: %d", m_ip.c_str(), m_port);
        return -1;
    }

    // Set socket option
    int onePortMapServerCount = 1 ;
    int RECV_BUF_SIZE  =  1024 * 1024 * 64 ; //
    int SEND_BUF_SIZE  =  1024 * 1024 *  4 ; //
    struct timeval udpRecvTimeOut = {1,0};    //1s
    struct timeval udpSendTimeOut = {1,0};    //1s

    int rc = setsockopt(m_sock, SOL_SOCKET, SO_REUSEADDR, &onePortMapServerCount, sizeof(int));// 同一个端口绑定服务器数量
    LOG_INFO_( "setsockopt: reuse addr = %d!", rc );
    if ( rc < 0)
    {
        LOG_NOTICE_("setsockopt onePortMapServerCount failed: %d!", errno);
        return -1;
    }

    rc = setsockopt(m_sock, SOL_SOCKET, SO_RCVTIMEO,  & udpRecvTimeOut, sizeof(udpRecvTimeOut)); // 发送时限
    LOG_INFO_( "setsockopt: recv time out = %d", rc );

    rc = setsockopt(m_sock, SOL_SOCKET, SO_SNDTIMEO,  & udpSendTimeOut, sizeof(udpSendTimeOut));// 接收时限
    LOG_INFO_( "setsockopt: send time out = %d", rc );


    rc = setsockopt( m_sock,  SOL_SOCKET,  SO_RCVBUF,  & RECV_BUF_SIZE,  sizeof( RECV_BUF_SIZE ) ); // 接收缓冲区
    LOG_INFO_( "setsockopt: recv buf %d = %d",  RECV_BUF_SIZE,  rc );
    if ( rc != 0 )
    {
        LOG_NOTICE_("setsockopt udpRecvBuffer failed: %d!", errno);
    }

    rc = setsockopt( m_sock,  SOL_SOCKET,  SO_SNDBUF,  & SEND_BUF_SIZE,  sizeof( SEND_BUF_SIZE ) ); // 发送缓冲区
    LOG_INFO_( "setsockopt: send buf %d = %d",  SEND_BUF_SIZE,  rc );
    if ( rc != 0 )
    {
        LOG_NOTICE_("setsockopt udpSendBuffer failed: %d!", errno);
    }

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port   = htons( m_port ) ;
    if ( m_ip.empty() )
    {
        serverAddr.sin_addr.s_addr = INADDR_ANY;
    }
    else
    {
        serverAddr.sin_addr.s_addr = inet_addr(const_cast<char*>(m_ip.c_str()));
    }
    bzero( & serverAddr.sin_zero, sizeof(serverAddr.sin_zero));
    rc  =  bind(m_sock, (sockaddr*)&serverAddr, sizeof(serverAddr));
    LOG_INFO_( "udp server: bind() = %d",  rc );
    if ( rc )
    {
       LOG_ERROR_( "bind udp sockaddr failed!" ) ;
       return -1;
    }

    return 0;
}
//---------------------------------------------------------------------------
void UdpServer::callBackFuncUdpSrv(int fd, short event, void *arg)
{
    //LOG_INFO_( "callBackFuncUdpSrv()......");

    struct sockaddr_in addr;
    socklen_t size = sizeof(addr);
    bzero( & addr,  size ) ;

    char buf[ sizeof( S_clientToIPCMsg ) ] = { 0 } ;
    int len = recvfrom( fd,  buf,  sizeof( buf ),  0,  (struct sockaddr *) & addr,  & size ) ; // Recv the data, store the address of the sender in the server_sin
    if ( len < 0 )
    {
        LOG_ERROR_( "udp server recvfrom error!" );
        return ;
    }
    // log.notice("recv %d data from %s", len, inet_ntoa(addr.sin_addr));    // buf.display();
    PthreadManager::getInstance()->analyseHttpMessage( buf,  len );
}
//---------------------------------------------------------------------------
int UdpServer::run( struct event_base * base )
{
    m_event  =  event_new( base,  m_sock,  EV_READ | EV_PERSIST,  callBackFuncUdpSrv,  this );
    if ( m_event == NULL )
    {
        LOG_ERROR_( "udp server event_new() error!" );
        return -1;
    }

    int ret = event_add( m_event,  NULL ) ;
    if ( ret < 0 )
    {
        LOG_ERROR_( "udp server event_add() failed!");
        return -1;
    }

    event_base_dispatch( base ); // loop

    return 0;
}
//---------------------------------------------------------------------------
/*
int UdpServer::sendTo(const void* buf, int len, const char * dstIp, int dstPort)
{
    if ( m_sock < 0 )
    {
        log.notice("the server sock was uninitialized");
        return -1;
    }

    struct sockaddr_in sock_addr;
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_port   = htons((short)dstPort);
    sock_addr.sin_addr.s_addr = inet_addr( const_cast<char*>( dstIp ) );
    int rc  =  sendto( m_sock,  buf,  len,  0,  (sockaddr*)&sock_addr, sizeof(sock_addr));
    if ( rc  <  0 )
    {
        log.notice("the udp send buf error!");
    }
    return rc ;
}
*/
//---------------------------------------------------------------------------

