///////////////////////////////////////////////////////////////
//
// FileName : HandleConfigChange.cpp
// Creator  : liupc123
// Date     : 2018-03-23
// Comment  : HandleConfigChange source file
//
///////////////////////////////////////////////////////////////

#include "handleConfigChange.h"

HandleConfigChange::HandleConfigChange() 
{
    m_pHttpServer = NULL ;
    m_bReplyStatus = false ;
}

HandleConfigChange::~HandleConfigChange() 
{
    //...
}

void HandleConfigChange::init(std::string& urldata, HttpServer* httpserver)
{
    m_sReceiveData = urldata ;
    m_pHttpServer = httpserver ;   
}

bool HandleConfigChange::receiveDataParse(std::string& urldata)
{
    if(urldata.empty())
    {
        LOG_ERROR_("urldata is NULL");
        return false;
    }

    Document document;
    document.Parse<0>(urldata.c_str());
    if( document.HasParseError() )
    {
        cout<<"Parse错误描述:"<<rapidjson::GetParseError_En(document.GetParseError())<<endl ;
        LOG_ERROR_("urldata is: %s", urldata.c_str());
        return false ;
    }

    if( !document.IsObject() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("json parse error") ;
        return false ;
    }

    if( !document.HasMember("MQHost") || !document["MQHost"].IsString() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document Parse MQHost eror") ;
        return false ;
    }
    m_sMQHost = document["MQHost"].GetString();

    if( !document.HasMember("MQAppId") || !document["MQAppId"].IsString() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document Parse MQAppId eror ") ;
        return false ;
    }
    m_sMQAppId = document["MQAppId"].GetString();
    m_sMQUsername = m_sMQAppId + "_User";
    m_sMQReplyToQueue = "MSG_OUTBOUND_" + m_sMQAppId;

    if( !document.HasMember("TutkUuid") || !document["TutkUuid"].IsString() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document Parse TutkUuid eror ");
        return false;
    }
    m_sTutkUuid = document["TutkUuid"].GetString();

    if( !document.HasMember("LocalIp") || !document["LocalIp"].IsString() )
    {
        m_bReplyStatus = false ;
        LOG_ERROR_("document Parse LocalIp eror ");
        return false;
    }
    m_sLocalIp = document["LocalIp"].GetString();

    return true;
}

void  HandleConfigChange::deal(const char *peerIp)
{
    // m_bReplyStatus = this->receiveDataParse(m_sReceiveData);
    // if( m_bReplyStatus == false )
    // {
    //     return;
    // }

    // ConfigXml::getIns()->modifyValue("RabbitMQ", "host", m_sMQHost);
    // ConfigXml::getIns()->modifyValue("RabbitMQ", "appID", m_sMQAppId);
    // ConfigXml::getIns()->modifyValue("RabbitMQ", "username", m_sMQUsername);
    // ConfigXml::getIns()->modifyValue("RabbitMQ", "replyToQueue", m_sMQReplyToQueue);
    // ConfigXml::getIns()->modifyValue("Tutk", "UUID", m_sTutkUuid);
    // ConfigXml::getIns()->modifyValue("UdpServer", "udpServerIp", m_sLocalIp);

    // if ( !m_pHttpServer || !m_pHttpServer->m_pRabbitMQ )
    // {
    //     return;
    // }
    // m_pHttpServer->m_pRabbitMQ->logIn();
    // m_pHttpServer->m_pRabbitMQ->consumerInit();
    m_bReplyStatus = true;
    return ;
}

void HandleConfigChange::getReplyData(std::string& replaydata)
{
    if(true == m_bReplyStatus)
    {
        replaydata = "{\"errMsg\": \"success!\", \"success\": true}";
    }
    else
    {
        replaydata = "{\"errMsg\": \"false!\", \"success\": false}";
    }
}
