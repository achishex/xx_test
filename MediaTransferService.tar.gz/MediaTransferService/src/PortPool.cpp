///////////////////////////////////////////////////////////////
//
// FileName : PortPool.cpp
// Creator  : fan
// Date     : 2017-12-13
// Comment  :  file
//
///////////////////////////////////////////////////////////////
#include "PortPool.h"
//#include "HD_Guard.h"
//#include "HD_Socket.h"

#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <algorithm>


PortPool::PortPool()
: m_nTcpPortBase(0)
, m_nTcpPortCount(0)
, m_nUdpPortBase(0)
, m_nUdpPortCount(0)
, m_bInit(false)
{
	m_listTcpPortPool.clear();
	m_listUdpPortPool.clear();

	pthread_mutex_init(&m_iTcpPortPoolLock,NULL);
	pthread_mutex_init(&m_iUdpPortPoolLock,NULL);

    int tcp_port_start = atoi(ConfigXml::getIns()->getValue("PortPool", "tcpPortStart").c_str());
    int tcp_port_size = atoi(ConfigXml::getIns()->getValue("PortPool", "tcpPortSize").c_str());
    int udp_port_start = atoi(ConfigXml::getIns()->getValue("PortPool", "udpPortStart").c_str());
    int udp_port_size = atoi(ConfigXml::getIns()->getValue("PortPool", "udpPortSize").c_str());
    InitPortPool(tcp_port_start, tcp_port_size, udp_port_start, udp_port_size);
}

PortPool::~PortPool()
{
	pthread_mutex_destroy(&m_iTcpPortPoolLock); 
	pthread_mutex_destroy(&m_iUdpPortPoolLock); 
}

void PortPool::InitPortPool(unsigned short nTcpPortBase, unsigned short nTcpPortCount, unsigned short nUdpPortBase, unsigned short nUdpPortCount)
{
	if (!m_bInit)
	{
		m_nTcpPortBase = nTcpPortBase;
		m_nTcpPortCount = nTcpPortCount;
		m_nUdpPortBase = nUdpPortBase;
		m_nUdpPortCount = nUdpPortCount;
		m_listTcpPortPool.clear();
		for (int i=0; i<m_nTcpPortCount; i++)
		{
			m_listTcpPortPool.push_back(m_nTcpPortBase + i*2);
		}
		m_listUdpPortPool.clear();
		for (int i=0; i<m_nUdpPortCount; i++)
		{
			m_listUdpPortPool.push_back(m_nUdpPortBase + i*2);
		}
		m_bInit = true;
	}
}

unsigned short PortPool::GetTcpPort()
{
	//HPR_Guard lock(&m_iTcpPortPoolLock);
	pthread_mutex_lock(&m_iTcpPortPoolLock); 
	unsigned short nPort = 0;
	if (m_listTcpPortPool.size() > 0)
	{
		nPort = m_listTcpPortPool.front();
		m_listTcpPortPool.pop_front();
	}
	pthread_mutex_unlock(&m_iTcpPortPoolLock); 
	return nPort;
}

unsigned short PortPool::GetUdpPort() 
{
	//HPR_Guard lock(&m_iUdpPortPoolLock);
	pthread_mutex_lock(&m_iUdpPortPoolLock); 
	unsigned short nPort = 0;
	if (m_listUdpPortPool.size() > 0)
	{
		nPort = m_listUdpPortPool.front();
		m_listUdpPortPool.pop_front();
	}
	pthread_mutex_unlock(&m_iUdpPortPoolLock); 
	return nPort;
}

bool CheckPortUsable(unsigned short nPort, int iType)
{
	int listenfd;
	struct sockaddr_in sockaddr;
	memset(&sockaddr,0,sizeof(sockaddr));

	sockaddr.sin_family = AF_INET;
	sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	sockaddr.sin_port = htons(nPort);
	
	listenfd = socket(AF_INET,(iType==0?SOCK_STREAM:SOCK_DGRAM),0);
	if (listenfd == -1)
	{
		//LOG_ERROR("HPR_CreateSocket Fail, errCode<%d>", HPR_GetSystemLastError());
		return false;
	}

	int iRet = bind(listenfd,(struct sockaddr *) &sockaddr,sizeof(sockaddr));
	if(iRet == -1)
	{
		close(listenfd);
		return false;
	}

	close(listenfd);	
	return true;
}

bool CheckTcpPortPairsUsable(unsigned short nPort)
{
	return (CheckPortUsable(nPort, 0) && CheckPortUsable(nPort + 1, 0));
}

bool CheckUdpPortPairsUsable(unsigned short nPort)
{
	return (CheckPortUsable(nPort, 1) && CheckPortUsable(nPort + 1, 1));
}

unsigned short PortPool::GetAndCheckTcpPort(int iCycleCount)
{
	unsigned short nPort = 0;
	do 
	{
		nPort = GetTcpPort();
		if (nPort == 0)
		{
			break;
		}
		if (CheckTcpPortPairsUsable(nPort))
		{
			break;
		}
		PortPool::GetInstance()->ReleaseTcpPort(nPort);
		nPort = 0;

	} while (iCycleCount-- > 0);	

	return nPort;
}

unsigned short PortPool::GetAndCheckUdpPort(int iCycleCount)
{
	unsigned short nPort = 0;
	do 
	{
		nPort = GetUdpPort();
		if (nPort == 0)
		{
			break;
		}
		if (CheckUdpPortPairsUsable(nPort))
		{
			break;
		}
		PortPool::GetInstance()->ReleaseUdpPort(nPort);
		nPort = 0;

	} while (iCycleCount-- > 0);	

	return nPort;
}

void PortPool::ReleaseTcpPort(unsigned short nPort)
{
	if (nPort > 0)
	{
		//HPR_Guard lock(&m_iTcpPortPoolLock);
		pthread_mutex_lock(&m_iTcpPortPoolLock);

		list<unsigned short>::iterator iter = find(m_listTcpPortPool.begin(), m_listTcpPortPool.end(), nPort);
		if (iter == m_listTcpPortPool.end())
		{
			m_listTcpPortPool.push_back(nPort);
		}

		pthread_mutex_unlock(&m_iTcpPortPoolLock);
	}
}

void PortPool::ReleaseUdpPort(unsigned short nPort)
{
	if (nPort > 0)
	{
		//HPR_Guard lock(&m_iUdpPortPoolLock);
		pthread_mutex_lock(&m_iUdpPortPoolLock); 
		list<unsigned short>::iterator iter = find(m_listUdpPortPool.begin(), m_listUdpPortPool.end(), nPort);
		if (iter == m_listUdpPortPool.end())
		{
			m_listUdpPortPool.push_back(nPort);
		}
		pthread_mutex_unlock(&m_iUdpPortPoolLock); 
	}
}
