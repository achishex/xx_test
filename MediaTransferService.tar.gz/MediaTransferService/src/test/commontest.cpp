///////////////////////////////////////////////////////////////
//
// FileName : common.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : common head file
//
///////////////////////////////////////////////////////////////
#include "common.h"

Log *pMTSLog = NULL;

int main()
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    
    pMTSLog = new Log(conf_file_path);
    
    singleton("./LOCK") ;
    S_clientToIPCMsg IpcMsg ;
    IpcMsg.display() ;
    S_clientToIPCMsg IpcMsg1(IpcMsg) ;
    IpcMsg1.display() ;
    S_clientToIPCMsg IpcMsg2(string("172.16.10.157") , 2000 , 5000 , COMMON_START, "deadbeef" ) ;
    IpcMsg2.display() ;
    string _ip = "172.16.10.161" ;
    S_clientToIPCMsg IpcMsg3(_ip , 2001 , 5001 , STREAMING_START, "deadbeef") ;
    IpcMsg3.display() ;
    return 0 ;
}
