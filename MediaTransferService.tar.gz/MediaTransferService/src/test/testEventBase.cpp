///////////////////////////////////////////////////////////////
//
// FileName : testEventBase.cpp
// Creator  : tanght
// Date     : 2018-3-5
// Comment  :  to test code as much as possible
//
///////////////////////////////////////////////////////////////
#include <cstdio>
#include <unistd.h>
#include <event2/thread.h>
#include <signal.h>
#include "udpServerEventBase.h"
#include "TimerEvent.h"
#include "udpEvent.h"

Log *pMTSLog = NULL;
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    std::printf( "\ntest event base .. ---------------------------------- \n\n" ) ;
    std::printf( "test UdpServerEventBase ..\n" ) ;

//    evthread_use_pthreads();

    UdpServerEventBase  t ;
    struct event_base * base = t.get_base() ;
    std::printf( "base of thread %p = %p \n",  & t,  base );

    TimerEvent * timer_ev = new TimerEvent( base,  1,  NULL,  NULL ) ;
    delete timer_ev ;

    std::printf( "\ntest event base done! -----------------------------------\n\n\n" ) ;
//    raise( SIGKILL );
    return 0;
}
//---------------------------------------------------------------------------
