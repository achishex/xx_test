///////////////////////////////////////////////////////////////
//
// FileName : handle
// Creator  : lcl
// Date     : 2017-03-05
// Comment  :
//
///////////////////////////////////////////////////////////////

#include "handleVoiceVideo.h"
//#include "httpHandle.h"
#include "HandleHeartbeat.h"
#include "handleDeviceCall.h"
#include "handleConfigChange.h"
#include "handleCloudSpeak.h"
/*void* thread_func(void* arg)
{
    if( arg )
    {
        ((HttpServer*)arg)->run();
    }
    return NULL;
} */

Log *pMTSLog = NULL;

int main()
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    
    pMTSLog = new Log(conf_file_path);
    
    ConfigXml::getIns()->init();

    HttpServer httpserver ;
    HttpServer httpsrv1;
    HttpServer httpsrv2(-1);

    httpserver.init();

    /* pthread_t tid;
	pthread_create(&tid, NULL, thread_func, &httpserver);
*/


    string udpServerIp = ConfigXml::getIns()->getValue( "UdpServer",  "udpServerIp"   );
    int  udpServerPort = atoi( ConfigXml::getIns()->getValue( "UdpServer",  "udpServerPort" ).c_str() );
    UdpClient udpserver(udpServerIp , udpServerPort );

    string replydata = "" ;
    string urldata = "{}";
    //HandleVoiceVideoStart
    cout<<"HandleVoiceVideoStart test"<<endl ;
    HandleVoiceVideoStart start1 ;
    start1.init(urldata , &httpserver );
    start1.deal();
    start1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start2 ;
    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\"\n";
    urldata += "}\n";
    start2.init(urldata , &httpserver );
    start2.deal();
    start2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start3 ;
    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\",\n";
    urldata += "\"voicePort\":5001\n";
    urldata += "}\n";
    start3.init(urldata , &httpserver );
    start3.deal();
    start3.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start4 ;
    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\",\n";
    urldata += "\"voicePort\":5001,\n";
    urldata += "\"videoIp\":\"172.16.10.164\"\n";
    urldata += "}\n";
    start4.init(urldata , &httpserver );
    start4.deal();
    start4.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start5 ;
    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\",\n";
    urldata += "\"voicePort\":5001,\n";
    urldata += "\"videoIp\":\"172.16.10.164\",\n";
    urldata += "\"videoPort\":5002\n";
    urldata += "}\n";
    start5.init(urldata , &httpserver );
    start5.deal();
    start5.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start6 ;
    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\",\n";
    urldata += "\"voicePort\":5001,\n";
    urldata += "\"videoIp\":\"172.16.10.164\",\n";
    urldata += "\"videoPort\":5002,\n";
    urldata += "\"devReceiveIp\":\"172.16.9.100\"\n";
    urldata += "}\n";
    start6.init(urldata , &httpserver );
    start6.deal();
    start6.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start7 ;
    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\",\n";
    urldata += "\"voicePort\":5001,\n";
    urldata += "\"videoIp\":\"172.16.10.164\",\n";
    urldata += "\"videoPort\":5002,\n";
    urldata += "\"devReceiveIp\":\"172.16.9.100\",\n";
    urldata += "\"devReceivePort\":5003\n";
    urldata += "}\n";
    start7.init(urldata , &httpserver );
    start7.deal();
    start7.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start ;

    urldata = "{\n";
    urldata += "\"voiceIp\":\"172.16.10.164\",\n";
    urldata += "\"voicePort\":5001,\n";
    urldata += "\"videoIp\":\"172.16.10.164\",\n";
    urldata += "\"videoPort\":5002,\n";
    urldata += "\"devReceiveIp\":\"172.16.9.100\",\n";
    urldata += "\"devReceivePort\":5003,\n";
    urldata += "\"deviceCode\":\"123abc111\"\n";
    urldata += "}\n";

    start.init(urldata , &httpserver );
    start.deal();
    start.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleVoiceVideoStart start0 ;
    start0.init(urldata , NULL );
    start0.deal();
    start0.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    //--------------------------------------------------------------------------//

    //HandleVoiceVideoStop
    cout<<"HandleVoiceVideoStop test"<<endl;

    HandleVoiceVideoStop stop ;
    urldata = "{\n";
    urldata += "\"deviceCode\":\"123abc111\"\n";
    urldata += "}\n";

    stop.init(urldata , &httpserver);
    stop.deal();
    stop.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;
/*
    HandleVoiceVideoStop stop1 ;
    stop1.init(urldata , NULL );
    stop1.deal();
    stop1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;
*/
    HandleVoiceVideoStop stop2 ;
    urldata = "{}" ;
    stop2.init(urldata, &httpserver );
    stop2.deal();
    stop2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    //------------------------------------------------------------------------//

    cout<<"HandleStreamStart and HandleStreamStop test"<<endl;

    HandleStreamStart streamstart1 ;
    urldata = "{}" ;
    streamstart1.init( urldata , &httpserver );
    streamstart1.deal();
    streamstart1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStop streamstop1 ;
    streamstop1.init(urldata , &httpserver);
    streamstop1.deal();
    streamstop1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart2 ;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"172.16.10.98\"\n";
    urldata += "}\n";
    streamstart2.init( urldata , &httpserver );
    streamstart2.deal();
    streamstart2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStop streamstop2 ;
    streamstop2.init(urldata , &httpserver);
    streamstop2.deal();
    streamstop2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart3 ;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"172.16.10.98\",\n";
    urldata += "\"receivePort\":5000\n";
    urldata += "}\n";
    streamstart3.init( urldata , &httpserver );
    streamstart3.deal();
    streamstart3.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStop streamstop3 ;
    streamstop3.init(urldata , &httpserver);
    streamstop3.deal();
    streamstop3.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart5;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"172.16.10.98\",\n";
    urldata += "\"receivePort\":5000,\n";
    urldata += "\"deviceCode\":\"5000\"\n";
    urldata += "}\n";
    streamstart5.init( urldata , &httpserver );
    streamstart5.deal();
    streamstart5.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl ;

    HandleStreamStop streamstop5 ;
    streamstop5.init(urldata , &httpserver);
    streamstop5.deal();
    streamstop5.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart6;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"172.16.10.98\",\n";
    urldata += "\"receivePort\":5000,\n";
    urldata += "\"deviceCode\":\"5000\",\n";
    urldata += "\"parentID\":\"1\"\n";
    urldata += "}\n";
    streamstart6.init( urldata , &httpserver );
    streamstart6.deal();
    streamstart6.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl ;

    HandleStreamStop streamstop6 ;
    streamstop6.init(urldata , &httpserver);
    streamstop6.deal();
    streamstop6.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart7 ;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"172.16.10.98\",\n";
    urldata += "\"receivePort\":5000,\n";
    urldata += "\"deviceCode\":\"5000\",\n";
    urldata += "\"parentID\":\"1\",\n";
    urldata += "\"streamProfile\":0\n";
    urldata += "}\n";

    streamstart7.init(urldata , &httpserver);
    streamstart7.deal();
    streamstart7.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart8 ;
    urldata = "{";
    urldata += "\"receiveIp\":\"172.16.10.99\",";
    urldata += "\"receivePort\":5000,";
    urldata += "\"deviceCode\":\"5001\",";
    urldata += "\"parentID\":\"1\",";
    urldata += "\"streamProfile\":0";
    urldata += "}";
    streamstart8.init(urldata , &httpserver);
    streamstart8.deal();
    streamstart8.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStart streamstart9 ;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"172.16.10.100\",";
    urldata += "\"receivePort\":5000,";
    urldata += "\"deviceCode\":\"5001\",";
    urldata += "\"parentID\":\"1\",";
    urldata += "\"streamProfile\":0";
    urldata += "}\n";

    streamstart9.init(urldata , &httpserver);
    streamstart9.deal();
    streamstart9.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleStreamStop streamstop ;
    streamstop.init(urldata , &httpserver);
    streamstop.deal();
    streamstop.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    string urldata1;
    urldata1 = "{\n";
    urldata1 += "\"receiveIp\":\"172.16.10.99\",";
    urldata1 += "\"receivePort\":5000,";
    urldata1 += "\"deviceCode\":\"10032001001899000001\",";
    urldata1 += "\"parentID\":\"10032001001899000001\",";
    urldata1 += "\"streamProfile\":0";
    urldata1 += "}\n";

    ClientSession* pClient = new ClientSession();
    string clientip = "172.16.10.99";
    pClient->SetClientIp(clientip);
    pClient->SetClientPort(5000);
    string devicecode = "10032001001899000001";
    pClient->SetClientDeviceCode(devicecode);
    string parentId = "10032001001899000001";
    pClient->SetClientParentId(parentId);
    pClient->SetClientStreamProfileCode(0);
    pClient->SetClientLocalPort(30000);

    string sClientID = pClient->GetClientID();
    httpserver.m_ClientSessionList.insert(pair<string, ClientSession*>(sClientID,pClient));

    HandleStreamStop streamstopv ;
    streamstopv.init(urldata1 , &httpserver);
    streamstopv.deal();
    streamstopv.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;


    HandleStreamStart streamstart0 ;
    streamstart0.init(urldata , NULL );
    streamstart0.deal();
    streamstart0.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;
/*
    HandleStreamStop streamstop0 ;
    streamstop0.init(urldata , NULL);
    streamstop0.deal();
    streamstop0.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;
*/

    //--------------------------------------------------------------------//

    cout<<"HandleDeviceCall test"<<endl;
    HandleDeviceCall  devicecall1 ;
    urldata = "{}" ;
    devicecall1.init(urldata, &httpserver);
    devicecall1.deal();
    devicecall1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceCall  devicecall2 ;
    devicecall2.init(urldata, &httpserver);
    devicecall2.deal();
    devicecall2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceCall  devicecall3 ;
    urldata = "{\n";
    urldata += "\"clientIp\":\"172.16.10.164\"\n";
    urldata += "}\n";
    devicecall3.init(urldata, &httpserver);
    devicecall3.deal();
    devicecall3.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceCall  devicecall4 ;
    urldata = "{\n";
    urldata += "\"clientIp\":\"172.16.10.164\",\n";
    urldata += "\"clientPort\":5004\n";
    urldata += "}\n";
    devicecall4.init(urldata, &httpserver);
    devicecall4.deal();
    devicecall4.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceCall  devicecall ;
    urldata = "{\n";
    urldata += "\"clientIp\":\"172.16.10.164\",\n";
    urldata += "\"clientPort\":5004,\n";
    urldata += "\"deviceCode\":\"123abc111\"\n";
    urldata += "}\n";
    devicecall.init(urldata , &httpserver);
    devicecall.deal();
    devicecall.getRecvClientVoiceip();
    devicecall.GetRecvClientVoicePort();
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceCall  devicecall0 ;
    devicecall0.init(urldata , NULL);
    devicecall0.deal();
    devicecall0.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    //-------------------------------------------------------------------//

    cout<<"HandleDeviceIntercall test"<<endl;

    HandleDeviceIntercall intercall1 ;
    urldata = "{}" ;
    intercall1.init(urldata, &httpserver);
    intercall1.deal();
    intercall1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceIntercall intercall2 ;
    urldata = "{\n";
    urldata += "\"deviceIp\":\"0.0.0.0\"\n";
    urldata += "}\n";
    intercall2.init(urldata, &httpserver);
    intercall2.deal();
    intercall2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceIntercall intercall3 ;
    urldata = "{\n";
    urldata += "\"deviceIp\":\"0.0.0.0\",\n";
    urldata += "\"devicePort\":5005\n";
    urldata += "}\n";
    intercall3.init(urldata, &httpserver);
    intercall3.deal();
    intercall3.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleDeviceIntercall intercall ;
    urldata = "{\n";
    urldata += "\"deviceIp\":\"0.0.0.0\",\n";
    urldata += "\"devicePort\":5005,\n";
    urldata += "\"deviceCode\":\"123abc111\"\n";
    urldata += "}\n";

    intercall.init(urldata , &httpserver);
    intercall.deal();
    intercall.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;
/*
    HandleDeviceIntercall intercall0 ;
    intercall0.init(urldata , NULL);
    intercall0.deal();
    intercall0.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;
    */

    //----------------------------------------------------------------//

    cout<<"HandleHeartbeat test"<<endl;
    HandleHeartbeat heartbeat1 ;
    urldata = "" ;
    heartbeat1.init(urldata , &httpserver);
    heartbeat1.deal();
    heartbeat1.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleHeartbeat heartbeat2 ;
    urldata = "{}" ;
    heartbeat2.init(urldata , &httpserver);
    heartbeat2.deal();
    heartbeat2.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleHeartbeat heartbeat3 ;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"0.0.0.0\"\n";
    urldata += "}\n";
    heartbeat3.init(urldata , &httpserver);
    heartbeat3.deal();
    heartbeat3.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    HandleHeartbeat heartbeat ;
    urldata = "{\n";
    urldata += "\"receiveIp\":\"0.0.0.0\",\n";
    urldata += "\"receivePort\":5006\n";
    urldata += "}\n";
    heartbeat.init(urldata , &httpserver);    heartbeat.deal();
    heartbeat.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    //--------------------------------------------------------------------//

    cout<<"HandleVideoAppHeartbeat test"<<endl;
    HandleVideoAppHeartbeat appheartbeat ;
    urldata="{}" ;
    appheartbeat.init(urldata , &httpserver);
    appheartbeat.deal();
    appheartbeat.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    //--------------------------------------------------------------------//

    cout<<"handleConfigChange test"<<endl;
    HandleConfigChange configChange ;
    urldata = "{}";
    configChange.init(urldata, &httpserver);
    configChange.deal();
    configChange.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    urldata = "{\n";
    urldata += "\"MQAppId\":\"192.168.111.207\",\n";
    urldata += "\"TutkUuid\":\"test\"\n";
    urldata += "}\n";
    configChange.init(urldata, &httpserver);
    configChange.deal();
    configChange.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    urldata = "{\n";
    urldata += "\"MQHost\":\"192.168.111.207\",\n";
    urldata += "\"TutkUuid\":\"test\"\n";
    urldata += "}\n";
    configChange.init(urldata, &httpserver);
    configChange.deal();
    configChange.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    urldata = "{\n";
    urldata += "\"MQHost\":\"192.168.111.207\",\n";
    urldata += "\"MQAppId\":\"test\"\n";
    urldata += "}\n";
    configChange.init(urldata, &httpserver);
    configChange.deal();
    configChange.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

    urldata = "{\n";
    urldata += "\"MQHost\":\"192.168.0.207\",\n";
    urldata += "\"MQAppId\":\"APP9516\",\n";
    urldata += "\"TutkUuid\":\"ABCD0123!@zxcGJUB\"\n";
    urldata += "}\n";
    configChange.init(urldata, &httpserver);
    configChange.deal();
    configChange.getReplyData(replydata);
    cout<<"replydata:"<<replydata<<endl;

//---------------------------------------------------------------------------
    cout << "\n\ntest: HandleCloudVoiceVideoStart\n" << endl;  // �ƶԽ�.��ʼ  //added by tanght 18.3.30
    {
        struct TestCloudStart
        {
            static void test( string & url_data,  HttpServer * http_server,  const char * tip )
            {
                if( tip ) cout << "\t" << tip << endl ;
                HandleCloudVoiceVideoStart  h ;
                h.init( url_data,   http_server );
                h.deal();
                string reply ;
                h.getReplyData( reply );
                cout<< "reply:" << reply << endl;
            }
        };
        urldata  =  "" ;
        TestCloudStart::test( urldata,  & httpserver,  "empty"  );

        urldata  =  "{" ;
        TestCloudStart::test( urldata,  & httpserver,  "parse error"  );

        urldata  =  "{"          "}\n" ;
        TestCloudStart::test( urldata,  & httpserver,  "empty field"  );

        urldata  =  "{"   "\"deviceCode\":\"dev_0\""        "}\n" ;
        TestCloudStart::test( urldata,  & httpserver,  "field: deviceCode"  );

        urldata  =  "{"   "\"deviceCode\":\"dev_0\""   ",\"devReceiveIp\":\"0.0.0.0\""      "}\n" ;
        TestCloudStart::test( urldata,  & httpserver,  "field: devicdCode + devReceiveIp"  );


        urldata  =  "{"   "\"deviceCode\":\"dev_0\""   ",\"devReceiveIp\":\"0.0.0.0\""   ",\"devReceivePort\":4000"    "}\n" ;
        TestCloudStart::test( urldata,  & httpserver,  "input ok. first"  );
        TestCloudStart::test( urldata,  & httpserver,  "input ok. again"  );
    }
//---------------------------------------------------------------------------
    cout << "\n\ntest: HandleCloudVoiceVideoStop\n" << endl;   // �ƶԽ�.ֹͣ //added by tanght 18.3.30
    {
        struct TestCloudStop
        {
            static void test( string & url_data,  HttpServer * http_server,  const char * tip )
            {
                if( tip ) cout << tip << endl ;
                HandleCloudVoiceVideoStop  h ;
                h.init( url_data,   http_server );
                h.deal();
                string reply ;
                h.getReplyData( reply );
                cout<< "reply:" << reply << endl;
            }
        };

        urldata  =  "" ;
        TestCloudStop::test( urldata,  & httpserver,  "empty"  );

        urldata  =  "{" ;
        TestCloudStop::test( urldata,  & httpserver,  "parse error"  );

        urldata  =  "{"          "}\n" ;
        TestCloudStop::test( urldata,  & httpserver,  "empty field"  );

        urldata  =  "{"   "\"deviceCode\":\"dev_0\""   "}\n" ;
        TestCloudStop::test( urldata,  & httpserver,  "input ok. first" );
        TestCloudStop::test( urldata,  & httpserver,  "input ok. again" );
    }
//---------------------------------------------------------------------------





//---------------------------------------------------------------------------
    cout << "\n\n" << endl ;
    return 0 ;
}


