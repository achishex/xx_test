///////////////////////////////////////////////////////////////
//
// FileName : PortPoolTest.h
// Creator  : licl
// Date     : 2018-1-22
// Comment  : PortPoolTest test file
//
///////////////////////////////////////////////////////////////
#include "PortPool.h"
#include "configXml.h"

//Log *pMTSLog = NULL;

void PortTest()
{
    ConfigXml::getIns()->init();

    //string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
   // string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
   // string conf_file_path = filePath + fileName;
   // pMTSLog = new Log(conf_file_path);
    
    PortPool* pPortPool = PortPool::GetInstance();
    //portPool.InitPortPool(4000,10,4100,10) ;
    unsigned int nPort = pPortPool->GetAndCheckTcpPort(10) ;
    if(nPort == 0 )
        cout<<"GetTcpPort error"<<endl ;
    else
    {
        cout<<"the Tcp port :" << nPort << endl ;
        pPortPool->ReleaseTcpPort(nPort) ;
    }

    nPort = pPortPool->GetAndCheckUdpPort(10) ;
    if(nPort == 0 )
    {
        cout<< "GetudpPort error" << endl ;
    }
    else 
    {
        cout<< "the udp port :" << nPort << endl  ;
        pPortPool->ReleaseUdpPort(nPort) ;
    }

    nPort = pPortPool->GetTcpPort() ;
    cout<<"TcpPort:"<<nPort<<endl ;
     if(nPort == 0 )
    {
        cout<< "GetudpPort error" << endl ;
    }
    else 
    {
        cout<< "the udp port :" << nPort << endl  ;
        pPortPool->ReleaseTcpPort(nPort) ;
    }

    nPort = pPortPool->GetUdpPort() ;
    cout<<"udpPort:"<<nPort<<endl;
    if(nPort == 0 )
    {
        cout<< "GetudpPort error" << endl ;
    }
    else 
    {
        cout<< "the udp port :" << nPort << endl  ;
        pPortPool->ReleaseUdpPort(nPort) ;
    }
    delete pPortPool ;
}

int main()
{
    PortTest() ;
    //UdpPortTest() ;
    return 0 ;
}
