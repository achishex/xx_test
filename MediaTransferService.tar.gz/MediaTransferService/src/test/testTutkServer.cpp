///////////////////////////////////////////////////////////////
//
// FileName : testTutkServer.cpp
// Creator  : tanght
// Date     : 2018-3-30
// Comment  :  to test code as much as possible
//
///////////////////////////////////////////////////////////////
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <iostream>
#include "tutkServer.h"

Log *pMTSLog = NULL;

//#include <signal.h>
//---------------------------------------------------------------------------
void dump_client_info( const AV_CLIENT & c,  const char * s )
{
    std::cout << s << std::endl;
    std::cout << "\t" << "int  nClientSid       = "  << c.nClientSid       << std::endl;
    std::cout << "\t" << "int  nSpeakerCh       = "  << c.nSpeakerCh       << std::endl;
    std::cout << "\t" << "int  nAVIndex         = "  << c.nAVIndex         << std::endl;
    std::cout << "\t" << "bool bEnableAudio     = "  << c.bEnableAudio     << std::endl;
    std::cout << "\t" << "bool bEnableVideo     = "  << c.bEnableVideo     << std::endl;
    std::cout << "\t" << "bool bEnableSpeaker   = "  << c.bEnableSpeaker   << std::endl;
    std::cout << "\t" << "char chSpeakSendToIp  = "  << c.chSpeakSendToIp  << std::endl;
    std::cout << "\t" << "int  nSpeakSendToPort = "  << c.nSpeakSendToPort << std::endl;
}
//---------------------------------------------------------------------------
// �������غ���������
extern void  Handle_IOCTRL_Cmd(int nSID, int nAVIndex, char* pchBuf, int nType); //
extern void pfnLoginInfoCBCallBack(unsigned int uLoginInfo) ;
extern int pfnAuthCallBack(char *viewAcc,char *viewPwd) ;
extern unsigned int GetTimeStamp() ;
//---------------------------------------------------------------------------
void * th_func( void * )
{
    {
        std::printf( "\n test CTutkServer  \n" );

//        string  strUUID( "MJSR4TR9AS47RBR7111A" ) ; // ����ֵ: ����Init()����
        string  strUUID( "404" ) ; // �����ڵ�.
        CTutkServer::instance()->Init( strUUID );


        std::printf( "\n test SendXXXData() \n" );
        std::string dst_dev_id( "xx" ) ;
        char buf[ 1024 ] ;
        int  buf_len =  128 ;

        std::printf( "\n send to dst not exists ..\n" );
        CTutkServer::instance()->SendFrameData( dst_dev_id,  buf,  buf_len ) ;
        CTutkServer::instance()->SendAudioData( dst_dev_id,  buf,  buf_len ) ;

        AV_Client c ;
        c.nClientSid  = 1;
        c.nSpeakerCh  = 1;
        c.nAVIndex    = 0 ;
        c.bEnableAudio = true ;
        c.bEnableVideo = true ;
        c.bEnableSpeaker = true;
        std::strcpy( c.chSpeakSendToIp,  "172.16.10.162" ) ;
        c.nSpeakSendToPort = 4000;
        dump_client_info( c  ,  "dst: "  ) ;


        std::printf( "\n insert dst ..\n" );
        CTutkServer::instance()->UpdateLinkInfoBySID( dst_dev_id,  c ,0) ;
        std::printf( "\n insert dst again..\n" );
        CTutkServer::instance()->UpdateLinkInfoBySID( dst_dev_id,  c ,0) ; // again

        AV_Client c2 ;
        int rc  =  CTutkServer::instance()->GetLinkInfoBySID( c2, dst_dev_id ,0) ;
        std::printf( "get link info by dev id = %d\n",  rc );
        if( rc  ==  0 )
            dump_client_info( c2 ,  "got client info: "  ) ;


        std::printf( "\n send to dst ..\n" );
        CTutkServer::instance()->SendFrameData( dst_dev_id,  buf,  buf_len ) ;
        CTutkServer::instance()->SendAudioData( dst_dev_id,  buf,  buf_len ) ;


        std::printf( "\n del link: not exists \n" );
        std::string dev_id_404( "dev_404" );
        CTutkServer::instance()->DelServerLinkInfo( dev_id_404, 0) ;

        std::printf( "\n del link: exists \n" );
        CTutkServer::instance()->DelServerLinkInfo( dst_dev_id,0 ) ;


        std::printf( "\n sleep ..\n" );
        sleep( 3 ) ;
        //std::printf( "\n Fini() ..\n" );
        //CTutkServer::instance()->Fini(); // ��ʱ�� core dump. ��ʱ������
    }
    return NULL ;
}
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    std::printf( "\ntest tutk server .. ---------------------------------- \n\n" ) ;

    { //
        std::printf( "\n test AV_CLIENT\n" );
        AV_CLIENT   c,  c2( c ) ;
        dump_client_info( c  ,  "c"  ) ;
        dump_client_info( c2 ,  "c2" ) ;
    }
    {
        std::printf( "\n test GetTimeStamp()\n" );
        unsigned int x = GetTimeStamp() ;
        printf( "%u \n",  x );
    }
    {
        std::printf( "\n test pfnLoginInfoCBCallBack()\n" );

        std::printf( "0x04\n" );
        pfnLoginInfoCBCallBack( 0x04 );
        std::printf( "0x08\n" );
        pfnLoginInfoCBCallBack( 0x08 );
    }

    {
        std::printf( "\n test pfnAuthCallBack\n" );
        {
            char acc[ 32 ] = "admin" ;
            char pwd[ 32 ] = "888888" ;
            int rc = pfnAuthCallBack( acc,  pwd ) ;
            std::printf( " pfnAuthCallBack(%s,%s)=%d\n",  acc,  pwd,  rc );
        }
        {
            char acc[ 32 ] = "admin" ;
            char pwd[ 32 ] = "8" ;
            int rc = pfnAuthCallBack( acc,  pwd ) ;
            std::printf( " pfnAuthCallBack(%s,%s)=%d\n",  acc,  pwd,  rc );
        }
        {
            char acc[ 32 ] = "a" ;
            char pwd[ 32 ] = "8" ;
            int rc = pfnAuthCallBack( acc,  pwd ) ;
            std::printf( " pfnAuthCallBack(%s,%s)=%d\n",  acc,  pwd,  rc );
        }
    }

    {
        pthread_t  t_id  =  0 ;
        int rc  =  pthread_create( & t_id,  NULL, th_func,  NULL );
        std::printf( "udp server 2: pthread_create()=%d \n",  rc );

        sleep( 5 ) ; // wait tutk server
    }


    std::printf( "\n now exit \n" );
    exit( 0 ) ;


    return 0;
}
//---------------------------------------------------------------------------
