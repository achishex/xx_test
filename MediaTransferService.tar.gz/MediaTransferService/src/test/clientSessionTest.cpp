///////////////////////////////////////////////////////////////
//
// FileName : clientSessionTest.cpp
// Creator : licl
// Date : 2018-2-2
// Comment :
//
///////////////////////////////////////////////////////////////
#include "clientSession.h"
Log *pMTSLog = NULL;

int main()
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    ClientSession session ;

    //ip
    string _ip = "172.16.10.157" ;
    string _ip1 ;
    session.SetClientIp(_ip) ;
    _ip1 = session.GetClientIp() ;
    cout<<"_ip,_ip1 : "<< _ip <<_ip1 <<endl;

    //port
    int _port ;
    session.SetClientPort(2000) ;
    _port = session.GetClientPort() ;
    cout<<"_port : "<<_port <<endl;

    //DeviceCode
    string set_devicecode = "123456789";
    string get_devicecode ;
    session.SetClientDeviceCode(set_devicecode) ;
    get_devicecode = session.GetClientDeviceCode() ;
    cout<<"set_devicecode:"<<set_devicecode<<",get_devicecode:"<<get_devicecode<<endl;

    //ParentId
    string set_parentid = "11111111" ;
    string get_parentid ;
    session.SetClientParentId(set_parentid) ;
    get_parentid = session.GetClientParentId() ;
    cout<<"set_parentid:"<<set_parentid<<",get_parentid:"<<get_parentid<<endl;

    //StreamProfileCode
    int _streamprofilecode;
    session.SetClientStreamProfileCode(1) ;
    _streamprofilecode = session.GetClientStreamProfileCode() ;
    cout<<"_streamprofilecode:"<<_streamprofilecode<<endl;

    //subjectid
    string _subjectid ;
    _subjectid = session.GetClientSubjectId() ;
    cout<<"_subjectid:"<<_subjectid<<endl;

    //Update
    time_t _update ;
    session.SetClientUpdate() ;
    _update = session.GetClientUpdate() ;
    cout<<"_update:"<<_update<<endl;

    //LocalPort
    int _localport ;
    session.SetClientLocalPort(2000) ;
    _localport = session.GetClientLocalPort() ;
    cout<<"_localport:"<<_localport<<endl;

    //ClientID
    string _clientid ;
    _clientid = session.GetClientID() ;
    cout<<"_clientid:"<<_clientid<<endl;

    // string _json="{\"receiveIp\":\"172.16.10.157\",\"receivePort\":2001,\"deviceCode\":\"2004\",\"parentID\":\"2005\",\"streamProfile\":3}" ; //json
    // if( session.ParseJson(_json) )
    //     cout<<"Parse success"<<endl;
    // else 
    //     cout<<"Parse failed"<<endl;

    return 0 ;

}
