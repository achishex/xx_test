/**
 * @file: unix_util_test.cpp
 * @brief: 
 * @author:  wusheng Hu
 * @version: V0001
 * @date: 2018-04-10
 */
#include <iostream>
#include <memory>
#include "unix_util.h"


int main(int argc, char **argv)
{
    const char* sUnixUtilTestProcName = "UnixUtilTest";
    Util::daemonize(sUnixUtilTestProcName);
    //
    std::shared_ptr<Util::ProcTitle> ProcTitleOp(new Util::ProcTitle(argc, argv));
    ProcTitleOp->SetTitle(sUnixUtilTestProcName);
    std::cout << "proc name: " << ProcTitleOp->GetTitle() << std::endl;

    return 0;
}

