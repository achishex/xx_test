///////////////////////////////////////////////////////////////
//
// FileName : udpClientTest.h
// Creator  : licl
// Date     : 2018-1-22
// Comment  : udpClient test file
//
///////////////////////////////////////////////////////////////
#include "udpClient.h"
#include <string.h>
#include <fstream>
#include <iostream>
using namespace std ;


/* 目标ip:port收到的数据：
12345678
//a.txt文件内容
0987654321
*/
/*
void udpClientRecvTest(string dstIp , int dstPort)
{
    UdpClient udpClient(dstIp,dstPort) ;  //测试构造函数
    char buf[1024] ;
    udpClient.recvFrom(buf,1024) ;  //测试recvFrom

    UdpClient udpClient1(dstPort+1) ;   //
    string buffer ;
    udpClient1.recvFrom(buffer) ;  //测试recvFrom
} */
//接收来自Server的数据

Log *pMTSLog = NULL;

int main(int argc, char* argv[])
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;

    pMTSLog = new Log(conf_file_path);
    
    UdpClient* udpcli0 = new UdpClient();
    UdpClient udpcli1(20002);
    UdpClient udpcli2("0.0.0.0", 20003);
    if ( 0 < udpcli0->sendTo("0.0.0.0", 20004, "this are test data 1") )
    {
        cout << "send error" << endl;
    }

    if ( 0 < udpcli1.sendTo("0.0.0.0", 20005, "this are test data 2") )
    {
        cout << "send error" << endl;
    }
    delete udpcli0;

    return 0;
}
