///////////////////////////////////////////////////////////////
//
// FileName : testUdpServer.cpp
// Creator  : tanght
// Date     : 2018-3-5
// Comment  :  to test code as much as possible
//
///////////////////////////////////////////////////////////////
#include <cstdio>
#include <unistd.h>
#include "udpServer.h"
#include "udpClient.h"
#include <signal.h>
Log *pMTSLog = NULL;

//---------------------------------------------------------------------------
int port = 20010 ;
std::string ip = "0.0.0.0" ;
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    std::printf( "\ntest udp server .. ---------------------------------- \n\n" ) ;

    // constructor , destructor
    {
        UdpServer  * s0 = new UdpServer( port,  ip ) ;
        delete s0 ;
    }

    UdpClient c ;
    // init() , callback
    {
        UdpServer  s( port,  ip ) ;
        int rc  =  s.init();
        std::printf( "udp server init()=%d\n",  rc );

        c.sendTo( ip,  port    ,  "1234" ) ;
        c.sendTo( ip,  port    ,  "1234" ) ;
        UdpServer::callBackFuncUdpSrv( s.m_sock,  0,  & s ) ; //
    }


    // thread_func() run()
    {
        UdpServer  s( port,  ip ) ;
        pthread_t  t_id  =  0 ;
        int rc  =  pthread_create( & t_id,  NULL,  UdpServer::thread_func,  & s );
        std::printf( "udp server 2: pthread_create()=%d \n",  rc );

        sleep( 1 ) ; // wait udp server  ready
        c.sendTo( "127.0.0.1",  port    ,  "1234" ) ;
        c.sendTo( "127.0.0.1",  port    ,  "1234" ) ;


        sleep( 3 ) ;
        event_del( s.m_event ) ;
        sleep( 1 ) ;
    }

    std::printf( "\ntest udp server done! -----------------------------------\n\n\n" ) ;

    return 0;
}
//---------------------------------------------------------------------------
