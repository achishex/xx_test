///////////////////////////////////////////////////////////////
//
// FileName : httpServertest.cpp
// Creator  : licl
// Date     : 2018-1-22
// Comment  : test main 
//
///////////////////////////////////////////////////////////////

#include <iostream>
#include "common.h"
//#include "handle_stream_start.h"
#include "httpServer.h"
#include "configXml.h"
#include "httpHandle.h"

Log *pMTSLog = NULL;
using namespace std;

void* thread_func(void* arg)
{
    if( arg )
    {
        ((HttpServer*)arg)->run();
    }
    return NULL;
}

int main(int argc, char* argv[])
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    //配置文件
    ConfigXml::getIns()->init();

    HttpServer httpsrv1();
    HttpServer httpsrv2(-1);
    HttpServer* httpsrv3 = new HttpServer("0.0.0.0", 10000);
	pthread_t tid;
	pthread_create(&tid, NULL, thread_func, httpsrv3);
    
    string urldata = "{\"receiveIp\":\"172.16.10.164\",\"receivePort\":4000,\"deviceCode\":\"abc0001\",\"parentID\":\"abc0001\",\"streamProfile\":0}";
    HandleStreamStart streamstart;
    streamstart.init(urldata, httpsrv3);
    streamstart.deal();
    string replaydata = "";
    streamstart.getReplyData(replaydata);

    urldata = "{\"receiveIp\":\"172.16.10.164\",\"receivePort\":4000,\"deviceCode\":\"abc0001\",\"parentID\":\"abc0001\"}";
    HandleStreamStop streamstop;
    streamstop.init(urldata, httpsrv3);
    streamstop.deal();
    replaydata = "";
    streamstop.getReplyData(replaydata);
    
    sleep(10);
    delete httpsrv3;

    return 0;
}
