///////////////////////////////////////////////////////////////
//
// FileName : testUdpEvent.cpp
// Creator  : tanght
// Date     : 2018-3-5
// Comment  :  to test code as much as possible
//
///////////////////////////////////////////////////////////////
#include <cstdio>
#include "udpEvent.h"
#include "udpServerEventBase.h"
#include "udpClient.h"
//---------------------------------------------------------------------------
void dump_dst_list( const std::vector< Dst > & v )
{
    unsigned int n  =  static_cast<unsigned int>( v.size() ) ;
    std::printf( "size of dst list is %u \n",  n );
    for( unsigned int i = 0;  i < n;  ++i ) { std::printf( "[%u]=%s:%d \n",  i,  v[ i ].get_ip(),  v[ i ].get_port() ); }
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    std::printf( "\ntest udp event .. ---------------------------------- \n\n" ) ;

    {  // 测试 Dst
        std::printf( "\n\ntest Dst ..\n" ) ;

        Dst  d ;
        std::printf( "d: default constructor. ip=%s port=%d\n",  d.get_ip(),  d.get_port() ) ;

        Dst  d2( 4000,  "172.168.10.162" ) ;
        std::printf( "d2: ip=%s port=%d\n",  d2.get_ip(),  d2.get_port() ) ;

        bool equal = ( d  ==  d2 ) ;
        std::printf( "d1 equal d2 : %d",  equal );

        Dst d3 ;  d3 = d ;
        equal = ( d  ==  d3 ) ;
        std::printf( "d1 equal d3 : %d",  equal );
    }
    //---------------------------------------------------------------------------
    { // 测试 DstList
        std::printf( "\n\ntest DstList ..\n" ) ;
        DstList  a ;
        Dst  d( 4000,  "1.1.1.1" ),  d2( 4001,  "2.2.2.2" ),  d3( 4002,  "3.3.3.3" ),  d4( 4004,  "4.4.4.4" ) ;

        a.add( d );
        a.add( d2 ) ;
        a.add( d2 ) ; // twice
        a.add( d3 ) ;
        std::printf( "after add \n" );
        {
            a.copy_out( ) ;
            dump_dst_list( a.m_send_list ) ;
        }

        a.del( d2 ) ;
        a.del( d2 ) ; // twice
        a.del( d4 ) ;
        std::printf( "after del \n" );
        {
            a.copy_out( ) ;
            dump_dst_list( a.m_send_list ) ;
        }

        a.clear();
        std::printf( "after clear \n" );
        {
            a.copy_out( ) ;
            dump_dst_list( a.m_send_list ) ;
        }
    }
    //---------------------------------------------------------------------------
    {  // 测试 EventManager
        std::printf( "\n\ntest EventManager ..\n" ) ;

        UdpEvent  * e   =  EventManager::ins()->acquire( ) ;
        UdpEvent  * e2  =  EventManager::ins()->acquire( ) ;

        std::printf( "e=%p e2=%p \n",  e,  e2 );

        EventManager::ins()->release( e2 ) ;
        EventManager::ins()->release( e  ) ;
    }
    //---------------------------------------------------------------------------
    { // 测试 UdpEvent
        std::printf( "\n\ntest UdpEvent ..\n" ) ;
        {
            Dst  d( 4000,  "1.1.1.1" ) ;

            UdpEvent     e ;
            e.add_dst( d ) ;
            e.del_dst( d ) ;
        }
        { // constructor / destructor
            UdpServerEventBase  t ; //
        }
        { // constructor / destructor
            UdpEvent   *  e = new UdpEvent ;
            delete e ;
        }
        { // init: // 端口不合法
            UdpEvent   *  e = new UdpEvent ;
            UdpServerEventBase  t ; //
	        int rc  =   e->init( 0,   "abcdef", t.get_base() ) ; //
            std::printf( "bad port: init()=%d \n",  rc );
            delete e ;
        }
        { // init: // 端口合法
            UdpEvent   *  e = new UdpEvent ;
            UdpServerEventBase  t ; //
	        int rc =  e->init( 31000,   "abcdef", t.get_base() ) ;
            std::printf( "good port: init()=%d \n",  rc );
            e->cleanup(); // 清除
            delete e ;    //
        }
        {
            UdpEvent     e ;
            UdpServerEventBase  t ; //
	        int rc  =  e.init( 31000,  "abcdef", t.get_base() ) ;
            std::printf( "good port: init()=%d \n",  rc );

            Dst  d( 4000,  "1.1.1.1" ) ;
            e.add_dst( d ) ;

            UdpClient c ;
            c.sendTo( "127.0.0.1",  e.m_port,  "abcdefg" ) ;

            UdpEvent::recv_callback( e.m_sock,  0,  & e ) ;

            c.sendTo( "127.0.0.1",  e.m_port,  "abcdefg" ) ;

            e.do_recv( e.m_sock,  0 );

            e.begin_destroy( e.m_port );
            e.cleanup();
        }
    }

    std::printf( "\ntest udp event done! -----------------------------------\n\n\n" ) ;
    return 0;
}
//---------------------------------------------------------------------------
