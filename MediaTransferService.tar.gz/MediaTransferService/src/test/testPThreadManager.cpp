///////////////////////////////////////////////////////////////
//
// FileName : testPThreadManager.cpp
// Creator  : tanght
// Date     : 2018-3-5
// Comment  :  to test code as much as possible
//
///////////////////////////////////////////////////////////////
#include <cstdio>
#include "pthreadManager.h"
#include <signal.h>

Log *pMTSLog = NULL;

//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{

    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    std::printf( "\ntest pthread manager .. ---------------------------------- \n\n" ) ;

    { // test Client
        std::printf( "\n\ntest Client ..\n" ) ;
        Client c;
        Client c2( 4000,  "1.0.0.1",  2000,  NULL,  NULL );
        bool equal =  ( c  ==  c2 ) ;
        std::printf( "c1 == c2 : %d..\n",  static_cast<int>( equal ) ) ;
    }
    //---------------------------------------------------------------------------
    { // test ClientInfo
        std::printf( "\n\ntest ClientInfo ..\n" ) ;
        UdpEvent * event = reinterpret_cast< UdpEvent * >( main );
        UdpServerEventBase * base  =  reinterpret_cast< UdpServerEventBase * >( main );

        ClientInfo a ;
        a.dump( "after defined:" );

        a.add( 4000,  "1.0.0.1",  2000,  event,  base );
        a.add( 4000,  "1.0.0.1",  2001,  event,  base );
        a.dump( "after add" );

        int client_count ;
        UdpEvent * e;
        UdpServerEventBase * b ;
        bool found = a.find_event( 4000,  client_count,  & e,  & b );
        printf( "found=%d client_count=%d event=%p base=%p\n",  static_cast<int>( found ),  client_count,  e,  b );

        a.del_client( 4000,  "1.0.0.1",  2000 );
        a.dump( "after del client" );

        a.del_event( 4000 ) ;
        a.dump( "after del event" );
    }
    //---------------------------------------------------------------------------
    {  // test PthreadManager
        std::printf( "\n\ntest PthreadManager ..\n" ) ;
        {
           /* PthreadManager * m = */ PthreadManager::getInstance();
        }
        PthreadManager  m ;
        int rc =  m.init( 1 ) ;
        printf( "pthread manager init()=%d",  rc );

        m.get_idle_thread() ;
        m.analyseHttpMessage( & m,  2 ); // invalid input

        char send_to_ip[ 32 ] = "0.0.0.0" ;
        int  send_to_port = 4000 ;
		string deviceCode = "abcdef";

        {
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port,  0,  COMMON_START, deviceCode ) ; // bad input: local port == 0
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }

        int  local_port = 3000 ;
        {
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port, local_port,  COMMON_START, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 1, local_port,  COMMON_START, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 2, local_port + 1,  COMMON_START, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 3, local_port + 1,  COMMON_START, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }

        { // cloud video
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 10,  local_port + 2,  CLOUDVIDEO_START, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        { // cloud voice
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 11,  local_port + 3,  CLOUDVOICE_START, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }


        sleep( 5 ) ;

        {
            printf( "stream stop\n\n" );
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port,  local_port,  STREAMING_STOP, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            printf( "stream stop\n\n" );
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 1,  local_port,  STREAMING_STOP, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            printf( "voicevideo/devicecall stop\n\n" );
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 2,  local_port + 1,  VOICEVIDEO_STOP, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            printf( "cloud voice/video stop\n\n" );
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 10,  local_port + 2,  VOICEVIDEO_STOP, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
        {
            printf( "cloud voice/video stop\n\n" );
            _S_clientToIPCMsg  x( send_to_ip,  send_to_port + 11,  local_port + 3,  VOICEVIDEO_STOP, deviceCode ) ; //
            m.analyseHttpMessage( & x,  sizeof( x ) ) ;
        }
    }

    sleep( 3 ) ;
    std::printf( "\ntest pthread manager done! -----------------------------------\n\n\n" ) ;

    exit( 0 );    //raise( SIGKILL );

    return 0;
}
//---------------------------------------------------------------------------
