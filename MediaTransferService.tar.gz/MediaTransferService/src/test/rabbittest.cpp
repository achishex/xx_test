#include "common.h"
#include "rabbitMQClient.h"


#include "rapidjson/document.h"
#include "rapidjson/prettywriter.h"  
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <new>
using namespace rapidjson;

Log *pMTSLog = NULL;

int main()
{
    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);

    ConfigXml::getIns()->init();
    Document doc;  
    doc.SetObject();    //key-value 相当与map
    //doc.Setvalue();        //数组型 相当与vector
    Document::AllocatorType &allocator=doc.GetAllocator(); //获取分配器
    doc.AddMember("topic","MSG/MCOMMAND/CAMERA",allocator);
    doc.AddMember("appID","APP9516",allocator);
    doc.AddMember("token","12fc61654baf7355",allocator);
    doc.AddMember("deviceID","11",allocator);
    doc.AddMember("messageID","1",allocator);
    doc.AddMember("eventTypeID",20009,allocator);
    doc.AddMember("eventStatus",0,allocator);
    doc.AddMember("replyFlag"," ",allocator);
    doc.AddMember("replyToQueue"," ",allocator);
    doc.AddMember("timestamp"," ",allocator);
    doc.AddMember("gatewayID","APP9516",allocator);
    doc.AddMember("correlationID"," ",allocator);
    doc.AddMember("isReplyMsg"," ",allocator);
    doc.AddMember("payload","test1111",allocator);
    StringBuffer buffer;  
    //PrettyWriter<StringBuffer> writer(buffer);  //PrettyWriter是格式化的json，如果是Writer则是换行空格压缩后的json  
    Writer<StringBuffer> writer(buffer);
    doc.Accept(writer); 
    cout<<buffer.GetString()<<endl;
    printf("creat pRabbitClient\n");

    RabbitMQClient* prabbitClient=RabbitMQClient::create();
    if(NULL == prabbitClient)
    {
         printf("pRabbitClient is null\n");
         return 0 ;
    } 
    
    //prabbitClient->logIn("192.168.0.207",5672,"iotdev","iotclient", "passw0rd");
    prabbitClient->logIn() ;
    //prabbitClient->basicPublish("MSG_INBOUND_QUEUE",buffer.GetString());
    prabbitClient->publishMessage(buffer.GetString()) ;
    //prabbitClient->consumerRun() ;
    
    delete prabbitClient;
    return 0;
}
