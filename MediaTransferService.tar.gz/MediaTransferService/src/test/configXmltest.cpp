#include <iostream>
#include <fstream>
#include <cstring>
#include <cassert>

#include <rapidxml.hpp>
#include <rapidxml_utils.hpp>
#include <rapidxml_print.hpp>

using namespace std;
using namespace rapidxml;

#include "configXml.h"

int main(int argc, char * argv[]) 
{
    ConfigXml::getIns()->init();
    string value1 = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string value2 = ConfigXml::getIns()->getValue("UdpServer", "udpBaseEventPort");
    cout << "value1: " << value1 << endl;
    cout << "value2: " << value2 << endl;
    ConfigXml::getIns()->print();
    ConfigXml::getIns()->display();

    ConfigXml::getIns()->appendValue("Log", "", "log.config");
    ConfigXml::getIns()->appendValue("Log", "logPropertiesFileName", "log.config");
    ConfigXml::getIns()->appendValue("Log", "logPropertiesFileCount", "5");
    ConfigXml::getIns()->appendValue("Logconfig", "logFileFormat", "%t-%s-%m%n");
    ConfigXml::getIns()->modifyValue("Logconfig", "logPropertiesFileName", "log.config");
    ConfigXml::getIns()->modifyValue("Log", "logPropertiesFilePath", "/home/fan/user/liupc123");

    return 0;
}
