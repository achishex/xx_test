///////////////////////////////////////////////////////////////
//
// FileName : 
// Creator  : fan
// Date     : 2017-12-21
// Comment  : rabbitMQ  client 
//
///////////////////////////////////////////////////////////////
#include "log.h"

Log *pMTSLog = NULL;

int main()
{

    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);
    
    Log logTest ;
    Log logTest0("./log.properties") ;
    //logTest.init() ;
    logTest.emerg("%s %d logTest.emerg" , __FILE__ , __LINE__ ) ;
    logTest0.emerg(string("logTest0.emerg") );
    logTest.fatal("%s %d logTest.fatal" , __FILE__ , __LINE__ ) ;
    logTest0.fatal(string("logTest0.fatal")) ;
    logTest.alert("%s %dlogTest.alert" , __FILE__ , __LINE__ ) ; 
    logTest0.alert(string("logTest0.alert") );
    logTest.crit("%s %d logTest.crit" ,__FILE__ , __LINE__ ) ; 
    logTest0.crit(string("logTest0.crit")) ;
    logTest.error("%s %d logTest.error" , __FILE__ , __LINE__ ) ; 
    logTest0.error(string("logTest0.error")) ;
    logTest.warn("%s %d logTest.warn" , __FILE__ , __LINE__ ) ; 
    logTest0.warn(string("logTest0.warn")) ;
    logTest.notice("%s %d logTest.notice" , __FILE__ , __LINE__ ) ; 
    logTest0.notice(string("logTest0.notice")) ;
    logTest.info("%s %d logTest.info" , __FILE__ , __LINE__ ) ; 
    logTest0.info(string("logTest0.info")) ;
    logTest.debug("%s %d logTest.debug" , __FILE__ , __LINE__ ) ; 
    logTest0.debug(string("logTest0.debug") );

    Log logTest1("./log.properties","sample") ;
    return 0 ;
}
