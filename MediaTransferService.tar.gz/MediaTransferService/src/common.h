///////////////////////////////////////////////////////////////
//
// FileName : common.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : common head file
//
///////////////////////////////////////////////////////////////

#ifndef _ALL_COMMON_H_
#define _ALL_COMMON_H_

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string>
#include <string.h>
#include <vector>
#include <list>
#include <queue>
#include <deque>
#include <map>
#include <set>

#include <sys/time.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <errno.h>
#include <utility>
#include <fcntl.h>
#include <unistd.h>

#include "log.h"
#include "mutexClass.h"

//#define BUF_MAX 1024*32
//#define INFO  log.info("%s %s %d", __FILE__, __FUNCTION__, __LINE__)
//#define NOTICE  log.notice("%s %s %d", __FILE__, __FUNCTION__, __LINE__)

const int onePortMapServerCount = -1;
const struct timeval udpRecvTimeOut = {1,0};    //1s
const struct timeval udpSendTimeOut = {1,0};    //1s
const int udpRecvBuffer = 1024 * 1024 * 64;    //default 8688B
const int udpSendBuffer = 1024 * 1024 * 64;    //default 8688B

enum E_ClientRquestType
{
    DEFAULT_REQUEST     =    00,
    COMMON_START        =    11,
    STREAMING_START     =    12,
    VOICEVIDEO_START    =    13,
    DEVICECALL_REQUIRE  =    14,
    DEVICECALL_START    =    15,
    STREAMING_STOP      =    01,
    DEVICECALL_STOP     =    02,
    VOICEVIDEO_STOP     =    03,
    CLOUDVIDEO_START    =    04,
    CLOUDVOICE_START    =    05,
    CLOUDSPEAK_START    =    06,
    CLOUDSPEAK_STOP     =    07,
    ERROR_REQUEST       =    -1
};

enum E_DstSendType
{
    DATA_NORMAL       =   00,
    DATA_TUTKVIDEO    =   11,
    DATA_TUTKVOICE    =   12,
    DATA_TUTKSPEAK    =   13,
    DATA_ERROR        =   -1

};


//客户端发送过来的消息体, httpServer 与 udpServer 通信使用  httpServer <---> udpServer 消息结构体
typedef struct _S_clientToIPCMsg
{
    char sendToIp[64];
    char chDevIndeCode[36];
    int sendToPort;
    int localPort;
    E_ClientRquestType command;    //1:开, 0:关

    _S_clientToIPCMsg()
    {
        sendToIp[0] = '\0';
        sendToPort = -1;
        localPort = -1;
        command = DEFAULT_REQUEST;
        memset( chDevIndeCode , 0 ,sizeof(chDevIndeCode)) ;
    }

    _S_clientToIPCMsg(const _S_clientToIPCMsg& other)
    {
        memset( sendToIp , 0 ,sizeof(sendToIp)) ;
        strncpy(sendToIp, other.sendToIp, sizeof(sendToIp)-1 );
        sendToPort = other.sendToPort;
        localPort = other.localPort;
        command = other.command;
        strncpy(chDevIndeCode, other.chDevIndeCode, sizeof(chDevIndeCode)-1 );
    }
    

    _S_clientToIPCMsg(string _sendToIp, int _sendToPort, int _localPort, E_ClientRquestType _command,string _strDevIndeCode)
    {
	    memset( sendToIp , 0 ,sizeof(sendToIp)) ;
        strncpy(sendToIp, _sendToIp.c_str(), sizeof(sendToIp)-1 );
        strncpy(chDevIndeCode, _strDevIndeCode.c_str(), sizeof(chDevIndeCode)-1);
        sendToPort = _sendToPort;
        localPort = _localPort;
        command = _command;
    }
    void display();
}S_clientToIPCMsg, *pS_clientToIPCMsg;


int singleton(const string &lock_file);

template<typename T>
class singleton_T
{
public:
	static inline T* instance()
	{
		if (instance_ == 0)
		{
			lock_.Lock();
			if (instance_ == 0)
			{
				instance_ = new T;
			}
			lock_.Unlock();
		}
		return instance_;
	}

	static inline void free()
	{
		free_ = true;
		lock_.Lock();
		if (instance_ != 0)
		{
			delete instance_;
			instance_ = 0;
		}
		lock_.Unlock();
	}

protected:
	singleton_T() {}
	virtual ~singleton_T()
	{
		if (!free_)
		{
			lock_.Lock();
			if (instance_ != 0)
			{
				delete instance_;
				instance_ = 0;
			}
			lock_.Unlock();
		}
	}
private:
	singleton_T(const singleton_T&) {}
	singleton_T& operator=(const singleton_T&) {}

private:
	static T* instance_;
	static hdtool::CMutexClass lock_;
	static bool free_;
};

template<typename T>
T* singleton_T<T>::instance_ = NULL;

template<typename T>
hdtool::CMutexClass singleton_T<T>::lock_;

template<typename T>
bool singleton_T<T>::free_ = false;


#endif //end define
