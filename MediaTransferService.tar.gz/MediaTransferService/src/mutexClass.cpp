#include "mutexClass.h"
#include <string.h>

namespace hdtool {
    CMutexClass::CMutexClass(void)
      : m_bCreated(true)
    {
        pthread_mutexattr_t mattr;
        pthread_mutexattr_init(&mattr);
        pthread_mutex_init(&m_mutex, &mattr);
        memset(&m_owner, 0, sizeof(pthread_t));
    }

    CMutexClass::~CMutexClass(void)
    {
        pthread_mutex_lock(&m_mutex);
        pthread_mutex_unlock(&m_mutex);
        pthread_mutex_destroy(&m_mutex);
    }

    void CMutexClass::Lock()
    {
        pthread_t id = pthread_self();
        try
        {
            if(m_owner == id)
                throw "\n\tcan not acquire mutex twice!\n";

            pthread_mutex_lock(&m_mutex);
            m_owner = id;
        }
        catch(char *psz)
        {

        }
    }

    void CMutexClass::Unlock()
    {
        pthread_t id = pthread_self();
        try
        {
            if(m_owner != id)
                throw "\n\tnot the thread that has the mutex\n";

            memset(&m_owner, 0, sizeof(pthread_t));
            pthread_mutex_unlock(&m_mutex);
        }
        catch(char *psz)
        {

        }
    }
}
