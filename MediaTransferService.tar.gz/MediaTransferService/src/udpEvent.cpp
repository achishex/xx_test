//---------------------------------------------------------------------------
//
// FileName : udpEvent.cpp
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : udpEvent source file
//
//---------------------------------------------------------------------------
#include "udpEvent.h"

#include <cstring>
#include "log.h"

#include <netinet/in.h> // inet_addr
#include <arpa/inet.h>
#include "tutkServer.h"
#include "udpLogBase.h"
#include "dev_info.h"

using namespace DEV_CHECK;

static int GetStatInterval()
{
	std::string interval =ConfigXml::getIns()->getValue( "Log",  "StatStreamInterval");
	if(interval == "")
	{
		LOG_ERROR_("get StatStreamInterval config value error. use default value 10");
		return 10;
	}
	else
	{
		return atoi(interval.c_str());
	}
}

static time_t GetTimeStamp()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec;
}

UdpEvent::UdpEvent()
  : m_IsOnRun(true)
  , m_destroying( false )
  , m_port( 0 )
  , m_sock( -1 )
  , m_pDevCheckHandle(NULL)
  , m_sDevSrcIp("")
  , m_iStatRecvNums(0)
{
    std::memset( & m_event,  0,  sizeof( m_event ) ) ;
    memset(&m_stat, 0, sizeof(AVStatItem));
    m_stat._startstamp = GetTimeStamp();

}

UdpEvent::~UdpEvent()
{
    if( m_sock  >  0 )
    {
        close( m_sock );
        m_sock = -1 ;
    }
    ResetResource();
}

void UdpEvent::recv_callback(int fd, short event, void* arg)
{
    UdpEvent * e = reinterpret_cast< UdpEvent * >( arg );
    e->do_recv( fd,  event );
}

int UdpEvent::init( int port, const char *deviceCode, struct event_base * base )
{
    std::memset( & m_event,  0,  sizeof( m_event ) ) ;
    m_destroying = false ;
    m_port =  port ;
    m_sock = -1 ;
    m_deviceCode.assign(deviceCode);

    if ( port < 1000 || port > 65535 )
    {
        return -2;
    }

    m_sock  =  socket( AF_INET,  SOCK_DGRAM | SOCK_NONBLOCK,  0 );
    if ( m_sock < 0 )
    {
        LOG_ERROR_("create udp socket failed: port:%d, msgtag:%s",  m_port, m_deviceCode.c_str());
        return -1;
    }


    int onePortMapServerCount = 1 ;
    int RECV_BUF_SIZE  =  1024 * 1024 * 10  ;
    int SEND_BUF_SIZE  =  RECV_BUF_SIZE * 6 ;
    //struct timeval udpRecvTimeOut = {1,0};    //1s
    //struct timeval udpSendTimeOut = {1,0};    //1s

    int ret = setsockopt(m_sock, SOL_SOCKET, SO_REUSEADDR, &onePortMapServerCount, sizeof(int)); // 同一个端口绑定服务器数量
    if ( ret < 0)
    {
        close( m_sock );  m_sock = -1 ;
        LOG_ERROR_("setsockopt onePortMapServerCount failed: %d, msgtag:%s", errno, m_deviceCode.c_str());
        return -1;
    }

    // setsockopt(m_sock, SOL_SOCKET, SO_RCVTIMEO, &udpRecvTimeOut, sizeof(udpRecvTimeOut));    // 发送时限

    // setsockopt(m_sock, SOL_SOCKET, SO_SNDTIMEO, &udpSendTimeOut, sizeof(udpSendTimeOut));    // 接收时限

    ret = setsockopt(m_sock, SOL_SOCKET,SO_RCVBUF, & RECV_BUF_SIZE, sizeof( RECV_BUF_SIZE ) );     // 接收缓冲区
    if ( ret )
    {
        LOG_ERROR_( "setsockopt recv_buf_size=%d failed: %d, msgtag:%s",  RECV_BUF_SIZE,  errno, m_deviceCode.c_str());
    }

    ret = setsockopt(m_sock, SOL_SOCKET, SO_SNDBUF, & SEND_BUF_SIZE, sizeof( SEND_BUF_SIZE ) );    // 发送缓冲区
    if ( ret )
    {
        LOG_ERROR_( "setsockopt send_buf_size=%d failed: %d, msgtag:%s",  SEND_BUF_SIZE,  errno, m_deviceCode.c_str());
    }

    struct sockaddr_in serverAddr;
    bzero( & serverAddr, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(m_port);
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    ret  =  bind( m_sock, (sockaddr*)&serverAddr, sizeof(serverAddr));
    if ( ret )
    {
        close( m_sock );  m_sock = -1 ;
        LOG_ERROR_( "bind udp port=%d failed, msgtag:%s", m_port, m_deviceCode.c_str());
        return -1;
    }

    //             event_new( base,  m_sock,  EV_READ | EV_PERSIST,  recv_callback,  this ) ;
    event_assign( & m_event,  base,  m_sock,  EV_READ | EV_PERSIST,  recv_callback,  this ) ;

    ret  =  event_add( & m_event,  NULL );
    if ( ret  <  0 )
    {
        close( m_sock );  m_sock = -1 ;
        LOG_ERROR_( "event_add failed! port: %d, msgtag:%s",  m_port, m_deviceCode.c_str());
        return -1;
    }
    
    std::string sDefOnceRecvPkg =  ConfigXml::getIns()->getValue("Log", "OnceRecvDevPkg");
    int32_t iOnceRecPkg =  200;
    if (sDefOnceRecvPkg.empty() == false)
    {
       iOnceRecPkg =  ::atoi(sDefOnceRecvPkg.c_str());
    }

    int32_t iCheckDevInteTm = 9; //use 9 second to check dev oneline,the value must less than tm used by
    // client to re-request start tm.
    std::string sDefCheckDevInteTm = ConfigXml::getIns()->getValue("Log", "CheckDevIntTm");
    if (sDefCheckDevInteTm.empty() == false)
    {
        iCheckDevInteTm = ::atoi(sDefCheckDevInteTm.c_str());
    }

    ResetResource();
    m_pDevCheckHandle = new DEV_CHECK::DevCheck(base, iCheckDevInteTm, port, iOnceRecPkg);
    LOG_INFO_("check dev online conf, check interval tm: %d, once recv pkg nums: %d, msgtag:%s", 
              iCheckDevInteTm, iOnceRecPkg, m_deviceCode.c_str());

    if (m_pDevCheckHandle->StartCheckPoint(UdpEvent::DevCheckPointCallBack) == false)
    {
		//first call by udp thread.
		//next call by event thread.
        LOG_ERROR_("start dev health check proc fail, err msg: %s, msgtag:%s", m_pDevCheckHandle->ToString().c_str(), m_deviceCode.c_str());
    }
    else 
    {
        LOG_DEBUG_("start dev health check proc succ, dev info: [ %s ], msgtag:%s", m_pDevCheckHandle->ToString().c_str(), m_deviceCode.c_str());
    }

	LOG_NOTICE_( "UdpEvent init success. port:%d, msgtag:%s",  m_port, m_deviceCode.c_str() );
    return 0;
}

void UdpEvent::DevCheckPointCallBack(int fd, short event, void *pCheckHandle)
{
    DevCheck* pHandle = (DevCheck*) pCheckHandle;
    if (pHandle == NULL)
    {
        return ;
    }

    pHandle->MarkStopStream();
    LOG_ERROR_("dev stop stream desc: [ %s ]", pHandle->ToString().c_str());
	UdpLogBase logclient;
	logclient.WriteMonitorLog("DevStopStream", pHandle->ToString());
    return ;
}

void UdpEvent::ResetResource()
{
    if (m_pDevCheckHandle)
    {
        delete m_pDevCheckHandle;
        m_pDevCheckHandle = NULL;
    }
}

void UdpEvent::cleanup()
{
    int port = m_port ;

	LOG_NOTICE_( "prepare to stop stream. port:%d, msgtag:%s",  port, m_deviceCode.c_str() );
	
    event_del( & m_event ) ; //

    if( m_sock  >  0 ) { ::close( m_sock );  m_sock = -1 ; }

    m_dst_list.clear(); // lock inside.

    m_destroying = false ; //
    
    ResetResource();
    EventManager::ins()->release( this ) ; //lock inside.

    LOG_NOTICE_( "stop stream success. port:%d, msgtag:%s",  port, m_deviceCode.c_str() );

	ulong_t howlong = GetTimeStamp() - m_stat._startstamp;
	if(howlong > 0)
	{
		LOG_DEBUG_("msgtag:%s, TotalRcv:%lu, TotalRcvVideo:%lu, TotalRcvAudio:%lu, Time:%lu, VideoAverageRate:%lu, AudioAverageRate:%lu"
							, m_deviceCode.c_str()
							, (m_stat._videoTotalCnt + m_stat._audioTotalCnt)
							, m_stat._videoTotalCnt
							, m_stat._audioTotalCnt
							, howlong
							, (m_stat._videoTotalCnt/howlong)
							, (m_stat._audioTotalCnt/howlong)
							);  
	}
	m_stat._videoTotalCnt = 0;
	m_stat._audioTotalCnt = 0;
	m_stat._videoIntervalCnt = 0;
	m_stat._audioIntervalCnt = 0;
	m_stat._startstamp = 0;
}

void GetRtpPackageInfo(char *buf, bool &IsAudio, uint16_t &sn)
{
	char pt=*(buf+1)&0x7f;
	// TODO: enum all defined payraod type in RTP spec
	if(pt == 96) //H264
	{
		IsAudio = false;
	}
	else
	{
		IsAudio = true;
	}
	memcpy(&sn, buf+2, 2);
}

void UdpEvent::do_recv( int fd,  short event )
{
    if ( m_destroying )
    {
        this->cleanup();
        return ;
    }

    struct sockaddr_in addr;
    socklen_t size = sizeof(addr);
    bzero( & addr,  size);
    char buf[ BUF_MAX_SIZE ] ;

    int recvLen  =  ::recvfrom( fd,   buf,  sizeof( buf ),  0,  (struct sockaddr *) & addr,  & size ); // recv
    if(recvLen <= 0)
    {
    	LOG_ERROR_( "port:%d recv from %s error, msgtag:%s", m_port, inet_ntoa(addr.sin_addr), m_deviceCode.c_str()); 
    }

    if ( ProcNotifyDevSrcIp( buf, recvLen) )
    {
        return ;
    }

    if ( !m_sDevSrcIp.empty() )
    {
        if (m_iStatRecvNums++ < 100)
        {
            LOG_DEBUG_("dev src ip: %s,pkg src ip: %s", m_sDevSrcIp.c_str(), ::inet_ntoa(addr.sin_addr));
        }

        if (::memcmp(m_sDevSrcIp.c_str(), ::inet_ntoa(addr.sin_addr), m_sDevSrcIp.size()) != 0)
        {
            LOG_ERROR_("recv pkg dev src ip: %s, really dev ip: %s, local port: %d, devcode: %s",
                       ::inet_ntoa(addr.sin_addr), m_sDevSrcIp.c_str(), m_port, m_deviceCode.c_str());
            return ;
        }
    }

	bool IsAudio = false;
	if(recvLen >= 4)
	{
		uint16_t sn = 0;
		GetRtpPackageInfo(buf, IsAudio, sn);
		//LOG_DEBUG_("IsAudio:%d, SN:%d", IsAudio, sn);
		if(IsAudio == true)
		{
			m_stat._audioTotalCnt += recvLen;
			m_stat._audioIntervalCnt += recvLen;
		}
		else
		{
			m_stat._videoTotalCnt += recvLen;
			m_stat._videoIntervalCnt += recvLen;
		}
	}
    //
	m_pDevCheckHandle->UpdteCheckTimer();
    m_dst_list.copy_out(); // lock inside
    for( std::vector< Dst >::iterator it =  m_dst_list.m_send_list.begin();  it != m_dst_list.m_send_list.end();  ++it )
    {
        if( m_destroying )
        {
            this->cleanup();
            return ;
        }
        if( it->m_enDataType  ==  DATA_NORMAL ) // 普通数据
        {
        	int ret = it->m_udpclient->SendData(buf,  recvLen);
        	if(ret <= 0)
        	{
				LOG_ERROR_( "port:%d sendto (%s:%d) error. ret:%d, errno:%d, msgtag:%s"
							, m_port 
							, it->get_ip()
							, it->get_port()
							, ret
							, errno
							, m_deviceCode.c_str()
							);
        	}

			if(ret < 0)
			{
				ret = it->m_udpclient->SendData(buf,  recvLen);
			}
        }
        else if ( DATA_TUTKVIDEO  ==  it->m_enDataType ) // 云对讲.视频
        {
            string strDstDevID( it->m_chDevIndexCode );
            
            CTutkServer::instance()->SendFrameData(strDstDevID, buf, recvLen);
        }
        else if ( DATA_TUTKVOICE  ==  it->m_enDataType ) // 云对讲.音频
        {
            string strDstDevID( it->m_chDevIndexCode );
            
            CTutkServer::instance()->SendAudioData(strDstDevID, buf, recvLen);
        }
    }

}

void UdpEvent::begin_destroy( int port )
{
    m_destroying  =  true ;
	UdpClient udpclient("0.0.0.0", port, false);
	udpclient.SendData((char *)&port, sizeof(port));
}

bool UdpEvent::del_dst( const Dst & dst )  // 删除1个目标
{
	LOG_NOTICE_("del udp client. msgtag:%s, port:%d, dst:[%s:%d], TotalRcv:%lu, TotalRcvVideo:%lu, TotalRcvAudio:%lu"
							, m_deviceCode.c_str()
							, m_port
							, dst.get_ip()
							, dst.get_port()
							, m_stat._videoTotalCnt+m_stat._audioTotalCnt
							, m_stat._videoTotalCnt
							, m_stat._audioTotalCnt
							);
    return m_dst_list.del( dst ) ;
}

bool UdpEvent::add_dst(const Dst & dst )  // 增加1个目标
{
	LOG_NOTICE_("add udp client. msgtag:%s, port:%d, dst:[%s:%d]", m_deviceCode.c_str(), m_port, dst.get_ip(), dst.get_port(), dst.m_chDevIndexCode);

    return m_dst_list.add( dst ) ;
}


void DstList::clear()
{
    m_send_list.clear();
    m_lock.Lock();
    m_list.clear();
    m_lock.Unlock();
}

void DstList::copy_out( ) // 拷贝目标
{
    m_send_list.clear();

    m_lock.Lock();
    for( list< Dst >::iterator it =  m_list.begin();  it != m_list.end();  ++it )
    {
        m_send_list.push_back( * it );
    }
    m_lock.Unlock();
}

bool DstList::add( const Dst & dst )
{
    m_lock.Lock();
    for( list< Dst >::iterator it =  m_list.begin();  it != m_list.end();  ++it )
    {
        if( * it  ==  dst ) // 已存在 无须添加
        {
            m_lock.Unlock();
            return false ;
        }
    }
    m_list.push_back( dst );
    m_lock.Unlock();
    return true ;
}

bool DstList::del( const Dst & dst )
{
    m_lock.Lock();
    for( list< Dst >::iterator it =  m_list.begin();  it != m_list.end();  ++it )
    {
        if( * it  ==  dst ) // 存在.
        {
			m_list.erase( it ) ;
            m_lock.Unlock();

            return true ;
        }
    }
    m_lock.Unlock();
    return false ;
}

Dst::Dst():m_enDataType(DATA_NORMAL)
{
	std::memset( m_chDevIndexCode, 0, sizeof( m_chDevIndexCode ) ) ;
}
Dst::Dst( const int port,  const char * ip, const E_DstSendType  nDataType): m_enDataType(nDataType)
{
	memset(&m_chDevIndexCode, 0, sizeof(m_chDevIndexCode));
    if (nDataType == DATA_TUTKVIDEO || nDataType == DATA_TUTKVOICE)
    {
        //as cloud speek dst ip/port not given
        m_udpclient = std::make_shared<UdpClient>(ip, port, false);
    }
    else 
    {
        m_udpclient = std::make_shared<UdpClient>(ip, port, true);
    }
}

Dst::Dst(const Dst &copy)
{
	m_udpclient = copy.m_udpclient;
	m_enDataType = copy.m_enDataType;
	memcpy(&m_chDevIndexCode, &(copy.m_chDevIndexCode), sizeof(m_chDevIndexCode));

}

Dst &Dst::operator=(const Dst &copy)
{
	m_udpclient = copy.m_udpclient;
	m_enDataType = copy.m_enDataType;
	memcpy(&m_chDevIndexCode, &(copy.m_chDevIndexCode), sizeof(m_chDevIndexCode));
	return *this;
}

const char *Dst::get_ip() const
{
	return m_udpclient->m_ip.c_str();
}

int Dst::get_port() const
{
	return m_udpclient->m_port;
}

bool Dst::operator ==( const Dst & o ) const
{
    return  ( get_port() == o.get_port() ) &&  ( std::strcmp( get_ip(),  o.get_ip() )  ==  0 ) ;
}

int UdpEvent::send_to_dst( int fd,  const void * buf,  int len,  const char * dstIp, int dstPort)
{
    struct sockaddr_in  a;
    std::memset( & a,  0,  sizeof( a ) ) ;
    a.sin_family = AF_INET;
    a.sin_port   =  htons( static_cast< unsigned short >( dstPort ) );
    a.sin_addr.s_addr = inet_addr( const_cast<char*>( dstIp ) );

    return  ::sendto( fd,  buf,  len,  0,  reinterpret_cast< sockaddr * >( & a ), sizeof( a ) );
}

void UdpEvent::stat()
{
	int inteval = GetStatInterval();
	
	LOG_DEBUG_("port:%d stat.msgtag:%s, TotalRcv:%lu, TotalRcvVideo:%lu, TotalRcvAudio:%lu, every %d second, VideoAverageRate:%lu, AudioAverageRate:%lu"
						, m_port
						, m_deviceCode.c_str()
						, (m_stat._videoTotalCnt+m_stat._audioTotalCnt)
						, m_stat._videoTotalCnt
						, m_stat._audioTotalCnt
						, inteval
						, (m_stat._videoIntervalCnt/inteval)
						, (m_stat._audioIntervalCnt/inteval)
						);
	m_stat._videoIntervalCnt = 0;
	m_stat._audioIntervalCnt = 0;
}

bool UdpEvent::ProcNotifyDevSrcIp(char *pBuf, int iLen)
{
    if ( !m_sDevSrcIp.empty() )
    {
        return false;
    }

    int iStrLen = sizeof(DevInfo::DevSrcIp);
    if (iStrLen != iLen)
    {
        //LOG_DEBUG_("recv data len: %d not notify struct data len: %d", 
        //          iLen, iStrLen);
        return false;
    }

    DevInfo::DevSrcIp* oneDevinfo = (DevInfo::DevSrcIp*)pBuf;
    if ( oneDevinfo->uiMagic != 0x0123 )
    {
        LOG_ERROR_("recv notify data is invalid");
        return false;
    }

    m_sDevSrcIp.assign(oneDevinfo->sDevsrcIp);
    LOG_DEBUG_("recv notify dev ip: %s", m_sDevSrcIp.c_str());
    return true;
}

EventManager * EventManager::ins()
{
    static EventManager * p = NULL ;
    if( p  ==  NULL )
    {
        p  =  new EventManager ;
    }
    return p ;
}

UdpEvent *  EventManager::acquire()
{
    UdpEvent * e = NULL ;

    m_lock.Lock();
    if( ! m_list.empty() )
    {
        e  =  * m_list.begin() ;        
		m_list.pop_front();
    }
    m_lock.Unlock();

    if( e  ==  NULL )
    {
        e =  new UdpEvent() ;
    }
    else
    {
        e->ResetDevSrcIp();
    }

	e->m_IsOnRun = true;
	e->m_stat._startstamp = GetTimeStamp();
	m_onRunList.push_back(e);    
    return e ;
}

void EventManager::release( UdpEvent * e )
{
    if( e  ==  NULL ) return ;
    m_lock.Lock();
	e->m_IsOnRun = false;
    m_list.push_back( e ) ;
	m_onRunList.remove(e);
    m_lock.Unlock();
}

EventManager::EventManager():  m_base(NULL), m_statTimer(NULL)
{
	
}

void stat_timeout_cb(evutil_socket_t fd, short event, void *arg)
{
	EventManager *p = reinterpret_cast<EventManager *>(arg);
	p->stat();
	p->startStatTimer();
}

void EventManager::startStatTimer()
{
	assert(m_base!=NULL); //just in case
	if(m_statTimer == NULL)
	{
		m_statTimer = evtimer_new(m_base,stat_timeout_cb,this);
		m_statInterval.tv_sec = GetStatInterval();
		m_statInterval.tv_usec = 0;
	}
	evtimer_add(m_statTimer, &m_statInterval);
}


void EventManager::init(event_base * base)
{
	m_base = base;
	startStatTimer();
}

void EventManager::stat()
{
    m_lock.Lock();
	for(std::list< UdpEvent *>::iterator it=m_onRunList.begin(); it!=m_onRunList.end(); it++)
	{
		(*it)->stat();
	}
    m_lock.Unlock();
}

