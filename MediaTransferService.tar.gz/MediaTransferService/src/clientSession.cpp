#include "clientSession.h"

#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

ClientSession::ClientSession()
  : m_iPort( 0 )
  , m_iStreamProfileCode( 0 )
  , m_iLocalPort( 0 )
{
    m_LastUpdated = std::time(NULL);
}

ClientSession::~ClientSession()
{

}

std::string ClientSession::GetClientSubjectId()
{
    std::string ret = m_sDeviceCode;
    ret += ":";
    ret += std::to_string(m_iStreamProfileCode);
    return ret;
}

void ClientSession::SetClientUpdate()
{
    m_LastUpdated = std::time(NULL);
}

std::time_t ClientSession::GetClientUpdate() const
{
    return m_LastUpdated;
}

std::string ClientSession::GetClientID()
{
    std::string ret = m_sIp;
    ret += ":";
    ret += std::to_string(m_iPort);
    return ret;
}
AudioVideoClient::AudioVideoClient(): m_sDevCode(""), sIpDevRcvAudio(""),uiPortDevRcvAudio(0),
                    uiPortRelayAudioToDev(0),
                    sIpClientRcvStream(""),uiPortClientRcvStream(0),uiPortRelayVideoToClient(0),
                    sIpClientRcvAudio(""),uiPortClientRecvAudio(0),uiPortRelayAudioToClient(0)
{
}

AudioVideoClient::~AudioVideoClient()
{
}

//
CloudAVClient::CloudAVClient(): m_sDevCode(""), sIpDevRecvAudio(""), uiPortDevRecvAudio(0),
                                uiPortMtsRelayAudioToApp(0), uiPortMtsRelayVideoToApp(0)
{
}

CloudAVClient::~CloudAVClient()
{
}
