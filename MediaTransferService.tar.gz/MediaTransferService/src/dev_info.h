#ifndef _DEV_INFO_H_
#define _DEV_INFO_H_

#include <mutex>
#include <string.h>
#include <map>
#include <string>
#include <vector>

#include "udpClient.h"

class DevInfo
{
 public:
  enum DevStart
  {
      EM_DEV_INIT   = 0,
      EM_DEV_START  = 1,
      EM_DEV_STOP   = 2,
  };

 public:
  struct DevSrcIp
  {
      DevSrcIp(): uiMagic(0x0123), uiDevDstPort(0), usStatus(EM_DEV_INIT) 
      { memset(sDevsrcIp, 0, sizeof(sDevsrcIp)); }

      DevSrcIp(const DevSrcIp& item) {
          uiMagic = item.uiMagic;
          uiDevDstPort = item.uiDevDstPort;
          usStatus = item.usStatus; // def = 0; 1: start, 2: stop
          memcpy( sDevsrcIp, item.sDevsrcIp, sizeof(sDevsrcIp) );
      }

      DevSrcIp& operator =(const DevSrcIp& item) {
        if(this != &item)
        {
            uiMagic = item.uiMagic;
            uiDevDstPort = item.uiDevDstPort;
            usStatus = item.usStatus; // def = 0; 1: start, 2: stop
            memcpy( sDevsrcIp, item.sDevsrcIp, sizeof(sDevsrcIp) );
        }
        return *this;
      }

      unsigned short    uiMagic;
      unsigned int      uiDevDstPort;
      unsigned short    usStatus; // def = 0; 1: start, 2: stop
      char              sDevsrcIp[40];
  };

  DevInfo();
  virtual ~DevInfo();

  void SetUdpSrvIp(const std::string& sip);

  /**
   * @brief: GetDevSrcIp 
   *  通过消息id获取本次会话的设备Ip
   * @param sMsgId
   *  会话msgid
   *
   * @return 
   *  设备源ip
   */
  std::string GetDevSrcIp(const std::string& sMsgId);

  /**
   * @brief: SetDevIp 
   *
   * 保存mq回包中的设备Ip,其中保存ip的条件是在status为 EM_DEV_START,
   *
   * @param sMsgId
   *  会话的message id
   *
   * @param sIp
   *  设备的源ip
   */
  void SetDevIp(const std::string& sMsgId, const std::string& sIp);

  /**
   * @brief: SetMsgIdPort 
   * 保存会话的状态和设备发送数据的目的端口
   *
   * @param sMsgId
   *   会话id
   * @param uiPort
   *   设备发送数据的目的端口
   * 
   * @param status
   * 保存的状态，初始为0， 会话开始为1， 会话结束为2
   */
  void SetMsgIdPort( const std::string& sMsgId, unsigned int uiPort, int status );

  /**
   * @brief: DelMsgId 
   *    删除会话信息, 只有当status 是 EM_DEV_STOP.
   * @param sMsgId
   * 会话id
   */
  void DelMsgId(const std::string& sMsgId);
  
  bool SendDataToUdpEvent(const std::string& sMsgId);
 private:
  std::mutex m_Mutex;
  std::map<std::string, DevSrcIp> m_mpMsgDevInfo;
  std::map<unsigned int, std::vector<std::string>>   m_mpPortMsgId;

  UdpClient notifyClient;
  std::string   m_sUdpSrvIp;
};
#endif
