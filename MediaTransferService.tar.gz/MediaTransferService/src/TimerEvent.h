
#ifndef TimerEvent_H
#define TimerEvent_H
//---------------------------------------------------------------------------
#include <event2/event.h>
//---------------------------------------------------------------------------
class TimerEvent  // ��ʱ���¼�
{
private:
    struct event    * m_event ;
    struct timeval  * m_timeout ;
public:
    typedef void ( * CallBack )(int fd,  short event, void * arg ) ;
    TimerEvent( struct event_base * base,  int seconds,  CallBack func,  void * arg ) ;
   ~TimerEvent() ;
};


//---------------------------------------------------------------------------
#endif // _H
