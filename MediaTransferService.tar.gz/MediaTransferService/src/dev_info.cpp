#include <iostream>
#include "dev_info.h"

DevInfo::DevInfo()
{
}

DevInfo::~DevInfo()
{
    std::lock_guard<std::mutex> lock(m_Mutex);
    m_mpMsgDevInfo.clear();
    m_mpPortMsgId.clear();
}

void DevInfo::SetMsgIdPort( const std::string& sMsgId, unsigned int uiPort, int istatus )
{
    DevSrcIp  oneDevInfo;
    oneDevInfo.uiDevDstPort = uiPort;
    oneDevInfo.usStatus     = istatus;

    std::lock_guard<std::mutex> lock(m_Mutex);
    auto it = m_mpMsgDevInfo.find(sMsgId);
    if (it == m_mpMsgDevInfo.end())
    {
        m_mpMsgDevInfo[sMsgId] = oneDevInfo;
    }
    else
    {
        it->second = oneDevInfo;
    }

    auto itPortMsgId = m_mpPortMsgId.find(uiPort);
    if (itPortMsgId == m_mpPortMsgId.end())
    {
        std::vector<std::string> vMsgId;
        vMsgId.push_back(sMsgId);
        m_mpPortMsgId[uiPort] = vMsgId;
        LOG_DEBUG_("add new msg id, set status: %d, msgid: %s, port: %d", istatus, sMsgId.c_str(), uiPort);
        return ;
    }

    LOG_DEBUG_("add msg id, set status: %d, msgid: %s, port: %d", istatus, sMsgId.c_str(), uiPort);
    itPortMsgId->second.push_back(sMsgId);
}

void DevInfo::SetDevIp(const std::string& sMsgId, const std::string& sIp)
{
    std::lock_guard<std::mutex> lock(m_Mutex);
    auto it = m_mpMsgDevInfo.find(sMsgId);
    if (it == m_mpMsgDevInfo.end())
    {
        return ;
    }
    if (it->second.usStatus == EM_DEV_START)
    {
        memcpy(it->second.sDevsrcIp, sIp.c_str(),sizeof(it->second.sDevsrcIp));
    }
}

std::string DevInfo::GetDevSrcIp(const std::string& sMsgId)
{
    std::lock_guard<std::mutex> lock(m_Mutex);
    auto it = m_mpMsgDevInfo.find(sMsgId);
    if (it == m_mpMsgDevInfo.end())
    {
        return std::string("");;
    }
    return it->second.sDevsrcIp;
}

void DevInfo::DelMsgId( const std::string& sMsgId )
{
    std::lock_guard<std::mutex> lock(m_Mutex);
    auto it = m_mpMsgDevInfo.find(sMsgId);
    if (it == m_mpMsgDevInfo.end())
    {
        return ;
    }
    if (it->second.usStatus != EM_DEV_STOP)
    {
        LOG_DEBUG_("msgid: %s, is not stop step, do not del", sMsgId.c_str());
        return ;
    }

    unsigned int uiPort = it->second.uiDevDstPort;
  
    auto itMsgId = m_mpPortMsgId.find(uiPort);
    if (itMsgId == m_mpPortMsgId.end())
    {
        m_mpMsgDevInfo.erase(sMsgId);
    } 
    else 
    {
        std::vector<std::string> vMsgId = itMsgId->second;
        for ( auto oneDev: vMsgId )
        {
            m_mpMsgDevInfo.erase(oneDev);
            LOG_DEBUG_("del msg id: %s, udp port: %d", oneDev.c_str(), uiPort);
        }

        LOG_DEBUG_("del udp port: %d", uiPort);
        m_mpPortMsgId.erase(uiPort);
    }
}

bool DevInfo::SendDataToUdpEvent(const std::string& sMsgId)
{
    DevSrcIp onedevinfo;
    {
        std::lock_guard<std::mutex> lock( m_Mutex );
        auto it = m_mpMsgDevInfo.find( sMsgId );
        if ( it == m_mpMsgDevInfo.end() )
        {
            LOG_ERROR_("not find record for msg id: %s", sMsgId.c_str());
            return false;
        }
        onedevinfo = it->second; 
    }

    if (onedevinfo.usStatus != EM_DEV_START)
    {
        LOG_DEBUG_("status: %d, need not to notify, msgid: %s", onedevinfo.usStatus, sMsgId.c_str());
        return false;
    }

    if ( ::strlen(onedevinfo.sDevsrcIp) == 0 )
    {
        LOG_DEBUG_("send dev ip is empty,msgid: %s", sMsgId.c_str());
        return false;
    }

    int iLen = sizeof(DevSrcIp);
    int iRet = notifyClient.sendTo( m_sUdpSrvIp, onedevinfo.uiDevDstPort, (void*)&onedevinfo, sizeof(onedevinfo) );
    if ( iRet <= 0 )
    {
        LOG_ERROR_("send to notify to udp event fail");
        return false;
    }
    if ( iLen != iRet )
    {
        LOG_ERROR_("send notify data len: %d, not eq to send len: %d, msgid: %s",
                   iRet, iLen, sMsgId.c_str());
        return false;
    }

    LOG_DEBUG_("send notify to udp event succ, msgid: %s, status: %d", sMsgId.c_str(), onedevinfo.usStatus);
    return true;
}

void DevInfo::SetUdpSrvIp(const std::string& sip)
{
    m_sUdpSrvIp = sip;
}
