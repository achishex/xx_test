#include "udpLogBase.h"

using namespace rapidjson;

static hdtool::CMutexClass	lock_;

UdpLogClient *UdpLogClient::p_instance_ = NULL;

UdpLogClient::UdpLogClient()
{
	do_log_ = atoi(ConfigXml::getIns()->getValue("Log", "LogToKafka").c_str());
	string udpSvrIp = ConfigXml::getIns()->getValue("Log", "UdpSvrIp").c_str();
	int udpSvrPort = atoi(ConfigXml::getIns()->getValue("Log", "UdpSvrPort").c_str());
	udp_client_.Init(udpSvrIp.c_str(), udpSvrPort, true);
}

UdpLogClient *UdpLogClient::GetInstance()
{
	if(p_instance_ == NULL)
	{
		lock_.Lock();
		if(p_instance_ == NULL)
		{
			p_instance_ = new UdpLogClient();
		}
		lock_.Unlock();
	}

	return p_instance_;
}

void UdpLogClient::SendData(const string &msg)
{
	if(do_log_ == 0)
	{
		return;
	}

	udp_client_.SendData(msg.c_str(), msg.length());
}

void RapidJsonAddStringMember(rapidjson::Document &root, const char *key, const string &val)
{
	Document::AllocatorType &allocator=root.GetAllocator();
	rapidjson::Value memval(rapidjson::kStringType);
	memval.SetString(val.c_str(),  val.size(), allocator);
	root.AddMember(StringRef(key), memval, allocator);
}

void RapidJsonAddIntMember(rapidjson::Document &root, const char *key, long  val)
{
	Document::AllocatorType &allocator=root.GetAllocator();
	rapidjson::Value memval;
	root.AddMember(StringRef(key), val, allocator);
}

UdpLogBase::UdpLogBase()
{
    _mtsIp = ConfigXml::getIns()->getValue("HttpServer", "httpIp"); 
    _mtsPort = atoi(ConfigXml::getIns()->getValue("HttpServer", "httpPort").c_str());
}

UdpLogBase &UdpLogBase::operator=(const UdpLogBase &val)
{
	_traceId = val._traceId;
	_spanId = val._spanId;
	_peerIp = val._peerIp;
	return *this;
}

void UdpLogBase::WriteTraceLog(const string & traceId, const string &spanId, const string &srcIp, const string &dstIp, const string &dataBody, const string &logLevel, const string &reqUrl, const string &loginfo)
{
	rapidjson::Document document;
	document.SetObject();
	RapidJsonAddIntMember(document, "logType", 1);
	RapidJsonAddStringMember(document, "traceId", traceId);
	RapidJsonAddStringMember(document, "spanId", spanId);
	RapidJsonAddStringMember(document, "srcIp", srcIp);
	RapidJsonAddStringMember(document, "dstIp", dstIp);
	RapidJsonAddStringMember(document, "dataBody", dataBody);
	RapidJsonAddStringMember(document, "logLevel", logLevel);
	RapidJsonAddStringMember(document, "serverName", SERVER_NAME);
	RapidJsonAddStringMember(document, "terminalType", TERMINAL_TYPE);
	if(reqUrl != "")
	{
		RapidJsonAddStringMember(document, "reqUrl", reqUrl);
	}

	if(loginfo != "")
	{	
		RapidJsonAddStringMember(document, "customCode", loginfo);
	}

	RapidJsonAddStringMember(document,  "createTime", GetCurrentDate());

	rapidjson::StringBuffer buffer;
	rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
	document.Accept(writer);


	string msg = buffer.GetString();
	//LOG_DEBUG_("trace log:%s", msg.c_str());
	UdpLogClient::GetInstance()->SendData(msg);
}

void UdpLogBase::WriteHttpReqTraceLog(const string &dataBody, const string &logLevel, const string &reqUrl, const string &loginfo)
{
	WriteTraceLog(_traceId, _spanId, _peerIp, _mtsIp, dataBody, logLevel, reqUrl, loginfo);
}

void UdpLogBase::WriteHttpRspTraceLog(const string &dataBody, const string &logLevel, const string &reqUrl, const string &loginfo)
{
	IncSpanId();
	WriteTraceLog(_traceId, _spanId, _mtsIp, _peerIp,  dataBody, logLevel, reqUrl, loginfo);
}

void UdpLogBase::WriteMQTraceLog(const string &dataBody, const string &logLevel, const string &reqUrl, const string &loginfo)
{
	std::string MQServerIp = ConfigXml::getIns()->getValue("RabbitMQ", "host") ;
	IncSpanId();
	WriteTraceLog(_traceId, _spanId, _mtsIp, MQServerIp,  dataBody, logLevel, reqUrl, loginfo);
}
void UdpLogBase::WriteTraceLogInternal(const string &dataBody, const string &logLevel, const string &reqUrl, const string &loginfo)
{
	WriteTraceLog(_traceId, _spanId, _mtsIp, _mtsIp,  dataBody, logLevel, reqUrl, loginfo);
}


void UdpLogBase::WriteMonitorLog(const std::string &type, const std::string &content)
{
	rapidjson::Document document;
	document.SetObject();
	RapidJsonAddIntMember(document, "logType", 2);
	RapidJsonAddStringMember(document, "monitorType", type);
	RapidJsonAddIntMember(document, "monitorLevel", 1);
	RapidJsonAddStringMember(document, "monitorContent", content);
	RapidJsonAddStringMember(document, "traceId", _traceId);	
	RapidJsonAddStringMember(document,  "createTime", GetCurrentDate());
	RapidJsonAddStringMember(document, "serverName", SERVER_NAME);
	std::string hostName = _mtsIp + ":" + std::to_string(_mtsPort);
	RapidJsonAddStringMember(document, "hostName", hostName);
	
	rapidjson::StringBuffer buffer;
	rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
	document.Accept(writer);


	string msg = buffer.GetString();
	//LOG_DEBUG_("monitor log:%s", msg.c_str());
	UdpLogClient::GetInstance()->SendData(msg);
}

string UdpLogBase::GetTraceId() 
{
	return _traceId;
}
	
string UdpLogBase::GetSpanId() 
{
	return _spanId;
}
	
string UdpLogBase::ExpandSpanId(const string &val) 
{
	return val+".0";
}
	
void UdpLogBase::IncSpanId() 
{
	size_t found = _spanId.find_last_of(".");
	if(found != std::string::npos)
	{
		string suf(_spanId.begin()+found+1, _spanId.end());
		string pre(_spanId.begin(), _spanId.begin()+found+1);
		int n=0;
		stringstream ssi;
		ssi<<suf;
		ssi>>n;
		n++;
		stringstream sso;
		sso<<n;
		_spanId=pre+sso.str();
	}
}
	
void UdpLogBase::InitUdpLogBase(const string &traceId, const string &spanId, const string &peerIp)
{
	_peerIp = peerIp;
	_traceId = traceId;
	_spanId = ExpandSpanId(spanId);
}
std::string UdpLogBase::GetCurrentDate()
{
	time_t timep;
	time (&timep);
	struct tm *ptm = localtime(&timep);
	char tmp[32] = {0};
	sprintf(tmp, "%04d-%02d-%02d %02d:%02d:%02d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
	string createTime(tmp);
	return createTime;	
}
