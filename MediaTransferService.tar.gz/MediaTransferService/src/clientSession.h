///////////////////////////////////////////////////////////////
//
// FileName : clientSession.h
// Creator : zhuxiaojing
// Date : 2018-1-17 18:03:00
// Comment :
//
///////////////////////////////////////////////////////////////



#ifndef _CLIENTSESSION_H_
#define _CLIENTSESSION_H_

#include "common.h"
#include <ctime>
#include <string>
#include "udpLogBase.h"

class ClientSession
{
public:
    ClientSession();
    ~ClientSession();

    void SetClientIp(const std::string& ip) { m_sIp = ip; };
    std::string GetClientIp() const { return m_sIp; };
    void SetClientPort(const int& port) { m_iPort = port; };
    int GetClientPort() const { return m_iPort; };
    void SetClientDeviceCode(const std::string& devicecode) { m_sDeviceCode = devicecode; };
    std::string GetClientDeviceCode() const { return m_sDeviceCode; };
    void SetClientParentId(const std::string& parentid) { m_sParentID = parentid; };
    std::string GetClientParentId() const { return m_sParentID; };
    void SetClientStreamProfileCode(const int& streamprofile) { m_iStreamProfileCode = streamprofile; };
    int GetClientStreamProfileCode() const { return m_iStreamProfileCode; };
    std::string GetClientSubjectId();
    void SetClientUpdate() ;
    std::time_t GetClientUpdate() const ;
    void SetClientLocalPort(const int& localport) { m_iLocalPort = localport; };
    int GetClientLocalPort() const { return m_iLocalPort; };
    std::string GetClientID();
	
private:
    std::string m_sIp;
    int         m_iPort;
    std::string m_sDeviceCode;
    std::string m_sParentID;
    int         m_iStreamProfileCode;  // used to identify whether the video stream is HD or not
    int         m_iLocalPort;
    std::time_t m_LastUpdated;  // used to record date time of last hearbeat received
};

//
struct AudioVideoClient
{
    AudioVideoClient();
    virtual ~AudioVideoClient();
    std::string m_sDevCode;

    std::string sIpDevRcvAudio; //ip which dev use to recv audio
    uint32_t uiPortDevRcvAudio; //port which dev use to recv audio
    uint32_t uiPortRelayAudioToDev; //port which mts relay audio to dev

    std::string sIpClientRcvStream; //ip which client use to recv video
    uint32_t uiPortClientRcvStream; //port which client to recv video
    uint32_t uiPortRelayVideoToClient; //port which mts relay video to client

    std::string sIpClientRcvAudio; // ip which client  to recv audio
    uint32_t  uiPortClientRecvAudio; //port whihch client to recv audio
    uint32_t uiPortRelayAudioToClient; //port which mts relay audio to client
};

//cloud speek session client
struct CloudAVClient
{
    CloudAVClient();
    virtual ~CloudAVClient();
    
    std::string m_sDevCode;            //dev code
    std::string sIpDevRecvAudio;       
    uint32_t uiPortDevRecvAudio;

    uint32_t uiPortMtsRelayAudioToApp;
    uint32_t uiPortMtsRelayVideoToApp;
};

#endif
