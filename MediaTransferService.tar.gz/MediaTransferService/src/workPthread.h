///////////////////////////////////////////////////////////////
//
// FileName : workPthread.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : workPthread head file
//
///////////////////////////////////////////////////////////////

#ifndef _WORKPTHREAD_H_
#define _WORKPTHREAD_H_

#include "common.h"

// typedef void* (*pFuncWorkPthread)(void * arg);

// 工作线程的实现
class WorkPthread
{
public:
	WorkPthread();
	virtual ~WorkPthread();
    //void lock();			//线程加锁
    void unlock();			//线程解锁
	void start();			//线程的启动
	void stop();			//线程的停止
	//int getStartStatus();	//获取线程状态
	//pthread_t gettid();
	virtual int run() = 0;
	static void* workPthreadFunc(void* arg);

protected:
	string m_name;
	int m_startStatus;	//1:start 0:stop
	int m_prior;		//线程优先级
	pthread_t m_tid;	//线程标识符
	pthread_mutex_t m_mutex;
};


#endif