//---------------------------------------------------------------------------
//
// FileName : udpEvent.h
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : udpEvent head file
//
//---------------------------------------------------------------------------

#ifndef UdpEvent_H
#define UdpEvent_H
#include <vector>
#include <list>

#include <unistd.h>
#include "common.h"
#include <event2/event.h>
#include <event2/buffer.h>
#include <event.h>
#include "udpClient.h"
#include "mutexClass.h"
#include <memory>

#include "dev_health_check.h"

typedef unsigned long ulong_t;

//class DEV_CHECK::DevCheck;

struct Dst  // 接收目标
{
    E_DstSendType m_enDataType;
    char m_chDevIndexCode[ 36 ];  
    std::shared_ptr<UdpClient> m_udpclient;

    Dst(const Dst &copy) ;
    Dst &operator=(const Dst &copy);
	Dst() ;
    Dst( const int port,  const char * ip, E_DstSendType  nDataType=DATA_NORMAL ) ;
    bool operator ==( const Dst & o ) const ;
    const char *get_ip() const;
	int get_port() const;
};

class DstList  // 目标列表
{
    hdtool::CMutexClass    m_lock ; //
    std::list< Dst >       m_list ; // 目标列表
public:
    DstList() {}
    void clear() ;
    bool add( const Dst & dst ) ;
    bool del( const Dst & dst ) ;

    void  copy_out(); // 拷贝目标

    std::vector< Dst >   m_send_list ;
} ;

class UdpEvent  // 代表1个设备
{
struct AVStatItem {
	ulong_t _videoTotalCnt;
	ulong_t _audioTotalCnt;
	ulong_t _videoIntervalCnt;
	ulong_t _audioIntervalCnt;
	ulong_t _startstamp;
};

    friend int main(int argc, char* argv[]) ;
    static const int BUF_MAX_SIZE = 4096 * 10;
public:
    UdpEvent();
   ~UdpEvent();
    int init( int port, const char *deviceCode, struct event_base * base );

    /**
     * @brief: ResetResource,
     *  主要用于udpevent 实例被回收到资源池时，实例内部资源的释放
     *  释放init()内部申请的一些资源.
     *
     * @return 
     */
    void ResetResource();

    /**
     * @brief: DevCheckPointCallBack
     *    dev check health process,当设备推流检查时间点到达，
     *    表明设备已经出现自动断流性为，
     *    该接口的作用就是在此情况发生时，日志打印一下.
     *
     * @return 
     */
    static void DevCheckPointCallBack(int fd, short event, void *pCheckHandle); 

    bool del_dst( const Dst & dst ) ; // 删除1个目标
    bool add_dst( const Dst & dst ) ; // 增加1个目标

    void begin_destroy( int port ); // 开始 退出
    void stat();

	bool		   m_IsOnRun;
    AVStatItem     m_stat;
    
    //主要是为了解决重复利用的event对象资源被初始化.
    void ResetDevSrcIp()
    {
        m_sDevSrcIp.clear();
    }
private:
    static int  send_to_dst( int fd,  const void * buf,  int len, const char * dstIp, int dstPort);

    static void recv_callback(int fd, short event, void* arg) ;
    void do_recv( int fd,  short event ) ;

    void cleanup();
    
    bool  ProcNotifyDevSrcIp(char *pBuf, int iLen);
private:
    bool           m_destroying ;  // 是否要退出

    int            m_port  ;    //端口
    int            m_sock  ;    //socket描述符
	string		   m_deviceCode;
    struct event   m_event ;    // event
    DstList        m_dst_list ; // 目标列表

 private:
    DEV_CHECK::DevCheck* m_pDevCheckHandle;
    std::string m_sDevSrcIp;
    int m_iStatRecvNums;
};

class EventManager // 事件管理类
{
    hdtool::CMutexClass      m_lock ;
    std::list< UdpEvent * >  m_list ;
	std::list<UdpEvent *> m_onRunList;
    event_base * m_base;
    struct event* m_statTimer;
	struct timeval m_statInterval;
    EventManager();
public:
    static EventManager * ins() ;
    UdpEvent *  acquire() ;  // 获取
    void  release( UdpEvent * e ) ; // 释放
    void init(event_base * base);
    void startStatTimer();
    void stat();
} ;


#endif
