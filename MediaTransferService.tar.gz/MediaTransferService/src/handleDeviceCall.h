///////////////////////////////////////////////////////////////
//
// FileName : handleDeviceCall.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  : handleDeviceCall head file
//
///////////////////////////////////////////////////////////////

#ifndef _DEVICE_CALL_H_
#define _DEVICE_CALL_H_

#include "httpHandle.h"


/* 二次握手流程
*  1:req->客户通知服务器将要发起对讲请求(携带客户端接收IP1,Port2)
*    rsp->服务器回应(携带服务器接收客户端数据的IP2,Port2,及接收设备端数据的IP3,Port3)
*  --客户端直接向设备请求对讲,(携带服务器接收设备端数据的IP3,Port3)
*  --设备回应
*  2:req->客户发起对讲(携带设备的IP4,Port4)
*/

// 呼叫设备第一次握手的事物处理类
class HandleDeviceCall : virtual public HandleBase
{
public:
    HandleDeviceCall();
    virtual ~HandleDeviceCall();
    void init(std::string& urldata, HttpServer* httpserver);
    void getReplyData(string& replydata);
    virtual void deal(const char *peerIp="");
    virtual bool encodeHttpData();
    virtual bool decodeHttpData(const char *peerIp="");
    string getRecvClientVoiceip() const {return m_sRecvClientVoiceip;}
    int GetRecvClientVoicePort() const {return m_iRecvClientVoicePort;}
private:
    string m_urlData;
    string m_replydata;
    PortPool* m_pUdpPortPool;

    string m_sClientIp;
    int m_iClientPort;
    string m_sDeviceCode;

    string m_sRecvClientVoiceip;
    int m_iRecvClientVoicePort;
    string m_sRecvDevVoiceip;
    int m_iRecvDevVoicePort;
    bool m_bReplyStatus ; 
    HttpServer* m_pHttpServer;
};

// 呼叫设备第一次握手的事物处理类
class HandleDeviceIntercall : virtual public HandleBase
{
public:
    HandleDeviceIntercall();
    virtual ~HandleDeviceIntercall();
    void init(std::string& urldata, HttpServer* httpserver);
    void getReplyData(string& replydata);
    virtual void deal(const char *peerIp="");
    // virtual bool encodeHttpData();
    virtual bool decodeHttpData(const char *peerIp="");
private:
    string m_urlData;
    string m_replydata;
    PortPool* m_pUdpPortPool;

    string m_sDeviceIp;
    int m_iDevicePort;
    string m_sDeviceCode;

    // string m_sRecvClientVoiceip;
    int m_iRecvClientVoicePort;
    HttpServer* m_pHttpServer;
};

#endif
