///////////////////////////////////////////////////////////////
//
// FileName : main.h
// Creator  : liupc123
// Date     : 2017-12-13
// Comment  :  process entrance
//
///////////////////////////////////////////////////////////////

#include "httpServer.h"
#include "udpServer.h"
#include "udpEvent.h"
#include "udpServerEventBase.h"
#include "workPthread.h"
#include "PortPool.h"
#include "pthreadManager.h"
#include "tutkServer.h"
#include "log.h"
#include "unix_util.h"
#include <memory>

Log *pMTSLog = NULL;

static HttpServer** InstanceHttpSrv = nullptr;

static void HandleKillSignal(int sig);
int main(int argc, char* argv[])
{
#ifdef SINGLE_SRV_PER_NODE
    if ( 0 != singleton("/var/tmp/mediaTransferServer.lock") )
#elif NO_HA
    if ( 0 != singleton("./mediaTransferServer.lock") )
#else
    if (0)
#endif
    {
        return 0;
    }

    int ret = -1;
    if ( argc >= 2 )
    {
        ret = ConfigXml::getIns()->init(argv[1]);
    }
    else
    {
        ret = ConfigXml::getIns()->init();
    }

    string filePath = ConfigXml::getIns()->getValue("Log", "logPropertiesFilePath");
    string fileName = ConfigXml::getIns()->getValue("Log", "logPropertiesFileName");
    string conf_file_path = filePath + fileName;
    pMTSLog = new Log(conf_file_path);

    LOG_INFO_("the program %s is starting........................................................", argv[0]);
    // ConfigXml::getIns()->display();

    if ( 0 != ret )
    {
        LOG_INFO_("config init error, exit!");
        return -1;
    }
    std::shared_ptr<Util::ProcTitle> PTile(new Util::ProcTitle(argc, argv));
    char buf[512] = {0};
    getcwd(buf, sizeof(buf));
    std::string procName("/mediaTransferServer ");
    procName.append(argv[1]);
    std::stringstream os;
    os << buf << procName;
    //snprintf(buf+strlen(buf),procName.size(),"%s", procName.c_str());
    //PTile->SetTitle(buf);
    PTile->SetTitle(os.str().c_str());
    Util::daemonize(PTile->GetTitle());
    LOG_DEBUG_("add send stop cmd to mq when server killed");
    Util::InstallSignal(HandleKillSignal);
	Util::SetOpenFileNums();
    
	PthreadManager::getInstance();

    string udpServerIp    =        ConfigXml::getIns()->getValue( "UdpServer",  "udpServerIp"   ) ;
    int    udpServerPort  =  atoi( ConfigXml::getIns()->getValue( "UdpServer",  "udpServerPort" ).c_str() );
    UdpServer udpSrv( udpServerPort,  udpServerIp ) ;
	pthread_t tid;
	pthread_create( & tid,  NULL,  UdpServer::thread_func,  & udpSrv ) ;

    int threadNumber = atoi( ConfigXml::getIns()->getValue( "HttpServer",  "threadNumber" ).c_str() ); ;
    PthreadManager::getInstance()->init( threadNumber );

    {
        string strUUID =  ConfigXml::getIns()->getValue( "Tutk",  "UUID"   ) ;
        //string strUUID("MJSR4TR9AS47RBR7111A");
        CTutkServer::instance()->Init(strUUID);
    }

    string httpIp = ConfigXml::getIns()->getValue("HttpServer", "httpIp");
    int httpPort = atoi(ConfigXml::getIns()->getValue("HttpServer", "httpPort").c_str());
    
    HttpServer* pNewHttpSrv = new HttpServer(httpIp, httpPort);
    InstanceHttpSrv = &pNewHttpSrv; 
   
    pNewHttpSrv->run();
    delete pNewHttpSrv;
    pNewHttpSrv = nullptr;

    return 0;
}

static void HandleKillSignal(int sig)
{
    std::ostringstream  mtsOs;
    mtsOs << "Signal handled: " << strsignal(sig);
    std::string strProcessExistMsg;
    
    if (sig == SIGTERM)
    {
        mtsOs << ", User Kill this Pid: " << getpid();
    }
    else 
    {
        
    }

    mtsOs << " now process manually exit.";
    strProcessExistMsg.append(mtsOs.str());
    LOG_ERROR_("%s", strProcessExistMsg.c_str());
    if ( (InstanceHttpSrv != nullptr) && (*InstanceHttpSrv) != nullptr )
    {
        LOG_ERROR_("--------------- begin: send stop cmd to dev-gateway -----------------");
        (*InstanceHttpSrv)->TerminateAndHttpStop(); 
        usleep(100000);
        LOG_ERROR_("--------------- end: send stop cmd to dev-gateway  ------------------");
    }
    
    exit(EXIT_SUCCESS);
}

