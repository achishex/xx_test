//---------------------------------------------------------------------------
//
// FileName : udpServerEventBase.h
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : udpServerEventBase head file
//
//---------------------------------------------------------------------------
#ifndef UdpServerEventBase_H
#define UdpServerEventBase_H
//---------------------------------------------------------------------------

#include <event2/event.h>
#include <event2/buffer.h>
#include <event.h>

#include "workPthread.h"

#include "udpEvent.h"
//---------------------------------------------------------------------------
class UdpServerEventBase : public WorkPthread
{
    friend int main(int argc, char* argv[]) ;
public:
    UdpServerEventBase( const int id = 0 );
   ~UdpServerEventBase();

    struct event_base * get_base() { return m_base ; }

protected:
    virtual int run() override; //

private:
//    int  getid() const {  return this->m_id ; }

private:
    int m_id;
    struct event_base * m_base ;
};


//---------------------------------------------------------------------------
#endif //end define
