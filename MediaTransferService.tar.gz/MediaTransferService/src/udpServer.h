//---------------------------------------------------------------------------
//
// FileName : udpServer.h
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : udpServer head file
//
//---------------------------------------------------------------------------
#ifndef UdpServer_H
#define UdpServer_H
//---------------------------------------------------------------------------
#include <string>

#include <event.h>
#include <event2/event.h>
#include <event2/buffer.h>
//---------------------------------------------------------------------------
class UdpServer  // udp server 接收并处理来自httpserver的命令
{
    friend int main(int argc, char* argv[]) ;
    static const int BUF_MAX_SIZE   =  1024 * 32 ;
public:
    UdpServer( int port,  const std::string & ip ) ;
   ~UdpServer();
    static void * thread_func( void * arg );
private :
    int init();
    int run( struct event_base * base );
//    int sendTo(const void* buf, int len, const char * dstIp, int dstPort);
    static void callBackFuncUdpSrv(int fd, short event, void *arg);

private:
    std::string   m_ip   ;     //ip地址
    int           m_port ;     //端口
    int           m_sock ;     //socket描述符
    struct sockaddr_in   m_clientAddr;
    struct event       * m_event ;
} ;
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
#endif
