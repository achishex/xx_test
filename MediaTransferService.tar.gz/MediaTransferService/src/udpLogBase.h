#ifndef __UDP_LOG_BASE__
#define __UDP_LOG_BASE__

#include "udpClient.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/prettywriter.h"  
#include "mutexClass.h"

using namespace std;

class UdpLogClient {
public:
	static UdpLogClient *GetInstance();
	void SendData(const string &msg);	
private:
	UdpLogClient();
	static UdpLogClient			*p_instance_;
	UdpClient					udp_client_;
	int							do_log_;
};

class UdpLogBase {
public:
	UdpLogBase();
	UdpLogBase &operator=(const UdpLogBase &val);
	void WriteHttpReqTraceLog(const string &dataBody, const string &logLevel, const string &reqUrl="", const string &loginfo="");
	void WriteHttpRspTraceLog(const string &dataBody, const string &logLevel, const string &reqUrl="", const string &loginfo="");
	void WriteMQTraceLog(const string &dataBody, const string &logLevel, const string &reqUrl="", const string &loginfo="");
	void WriteTraceLogInternal(const string &dataBody, const string &logLevel, const string &reqUrl="", const string &loginfo="");
	void WriteTraceLog(const string &traceId, const string &spanId, const string &srcIp, const string &dstIp, const string &dataBody, const string &logLevel, const string &reqUrl="", const string &loginfo="");
	void WriteMonitorLog(const std::string &type, const std::string &content);
	string GetTraceId();

	string GetSpanId();
	void IncSpanId();
	void InitUdpLogBase(const string &traceId, const string &spanId, const string &peerIp);
	std::string GetCurrentDate();

private:
	string ExpandSpanId(const string &val);
public:
	string		_traceId;
	string		_spanId;
	string		_peerIp;
	string		_mtsIp;
	int			_mtsPort;
	const string TERMINAL_TYPE = "scp-videogatewaycomponent";
	const string SERVER_NAME = "MediaTransferServer";
};

void RapidJsonAddStringMember(rapidjson::Document &root, const char *key, const string &val);
void RapidJsonAddIntMember(rapidjson::Document &root, const char *key, long  val);
#endif
