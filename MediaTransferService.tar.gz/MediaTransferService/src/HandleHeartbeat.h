///////////////////////////////////////////////////////////////
//
// FileName : HandleHeartbeat.h
// Creator  : fan
// Date     : 2017-12-22
// Comment  : handle_stream head file
//
///////////////////////////////////////////////////////////////

#ifndef _HANDLE_HEARTBEAT_H_
#define _HANDLE_HEARTBEAT_H_

#include "common.h"
#include "httpServer.h"
#include "httpHandle.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"



/**
*** 心跳处理类
**/
class HandleHeartbeat : public HandleBase
{
public:
    HandleHeartbeat() ;
    ~HandleHeartbeat() ;
    void init(std::string& urldata, HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);
private:
    bool receiveDataParse(std::string& urldata);
private:

    string m_sReceiveData;
    string m_sReceiveIp;
    int m_iReceivePort;
    HttpServer* m_pHttpServer;
    bool m_bReplyStatus;
};


//上游检测服务器是否存在的心跳
class HandleVideoAppHeartbeat : public HandleBase
{
public:
    HandleVideoAppHeartbeat();
    ~HandleVideoAppHeartbeat();
    void init(std::string& urldata, HttpServer* httpserver );
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);

private:
    string m_sReceiveData;
    HttpServer* m_pHttpServer;
    bool m_bReplyStatus;
};

#endif
