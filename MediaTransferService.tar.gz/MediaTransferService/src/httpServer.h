///////////////////////////////////////////////////////////////
//
// FileName : httpServer.h
// Creator  : fan
// Date     : 2017-12-13
// Comment  : httpServer head file
//
///////////////////////////////////////////////////////////////

#ifndef _HTTP_SERVER_H_
#define _HTTP_SERVER_H_


#include <evhttp.h>
#include <event.h>
#include <signal.h>
#include <memory>
#include <regex>
#include <event2/http.h>
#include <event2/event.h>
#include <event2/buffer.h>

#include "common.h"
#include "PortPool.h"
#include "clientSession.h"
#include "TimerEvent.h"
#include "rabbitMQClient.h"
#include "dev_info.h"

class HandleBase;
typedef void (*pFuncCallBackHttp)(struct evhttp_request *, void *);
typedef map<string, ClientSession* >::iterator   ClientMapiterator;

class HttpServer
{
public:
    HttpServer();
    HttpServer(int port);
    HttpServer(string ip, int port);
    int init();
    int run(pFuncCallBackHttp func, void* arg);
    virtual int run();
    virtual ~HttpServer();
    PortPool* GetPortPool();
    std::map<std::string, ClientSession*> m_ClientSessionList;
    std::map<std::string, AudioVideoClient>  m_AudioVideoSession; //key: devcode
    std::map<std::string, CloudAVClient> m_mpCloudAVSession; //key: devcode
    std::map<std::string, time_t> m_mpVoiceVideNodes; //key: devcode, value: voicevideo start time;

    // IProcessHttp* m_HttpRequestProcessors;
    std::map<std::string, HandleBase*> m_reqTyp2Handler;
	void DoHttpGetReq(struct evhttp_request* request);

    void InitUriMeth(const std::string& sUri, HandleBase* phandlObj, const std::string& sPartten);
    void DealVoicVideoExpireNode(time_t tNow);

    bool InsertDevCodeInVoiceVideoNode(const std::string& sDevCode);
    bool DelDevCodeFromVoiceVideoNode(const std::string& sDevCode);

    bool TerminateAndHttpStop();
private:
    string m_ip;
    int m_port;
    struct event_base* m_base;
    struct evhttp* m_http;
    TimerEvent* m_pTimer;
    PortPool* m_pUdpPortPool;    

public:
    RabbitMQClient* m_pRabbitMQ;
    int m_ilocalInterPort ;
    string m_sServerIp ;
    string m_sOutTimeMax;
    std::string m_sVoiceVideoExpTm;
public:
    class UriRegex;
    std::map<std::shared_ptr<UriRegex>, HandleBase*> m_mpUriRegex;

    struct UriRegexRegist;
    UriRegexRegist* pArrRegex;
    static const int iArrRegxLen = 100;

    DevInfo m_stDevInfo;
};

#endif
