///////////////////////////////////////////////////////////////
//
// FileName : HandleVideVice.h
// Creator  : fan
// Date     : 2018-01-18
// Comment  : handle_stream_start source file
//
///////////////////////////////////////////////////////////////
#ifndef _HANDLE_VideoVioce_H_
#define _HANDLE_VideoVioce_H_

#include "httpHandle.h"


/**
*** 同事获取视频流和音频流请求的事物操作类
**/
class HandleVoiceVideoStart : virtual public HandleBase
{
public:
    HandleVoiceVideoStart();
    ~HandleVoiceVideoStart();
    //Handle_stream_start(std::string& urldata):m_sReceiveData(urldata){}
    void init(std::string&  urldata, HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    
    void getReplyData(std::string& replaydata);
private:
    bool receiveDataParse(std::string& urldata, const char *peerIp);
    bool encodeSuccessData(int devvideoport,int devvoiceport,int cltvoiceport );
private:
    std::string m_sReceiveData;
    //解析客户端发送过来的数据并保存在以下成员中
    std::string m_sVoiceIp;
    int m_iVoicePort;

    std::string m_sVideoIp;
    int m_iVideoPort;

    std::string m_sdevReceiveIp;
    int m_idevReceivePort;
    
    std::string m_sDeviceCode;

    //操作成功返回给客户端的数据
    std::string m_sSuccessData;

    //类内部使用的成员变量
    PortPool* m_pUdpPortPool;
    HttpServer* m_pHttpServer;
    
    bool m_bReplyStatus;
};


/**
*** 请求停止流操作类
**/
class HandleVoiceVideoStop : public HandleBase
{
public:
    HandleVoiceVideoStop();
    ~HandleVoiceVideoStop();
    //Handle_stream_start(std::string& urldata):m_sReceiveData(urldate){}
    void init(std::string& urldata, HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);

    //add to implement HA 
    void ReleaseRelayPort();
    void SetDevCode(const std::string& sDevCode)
    {
        m_sDeviceCode = sDevCode;
    }

private:
    bool receiveDataParse(std::string& urldata, const char *peerIp );
    bool getSendToMQData(std::string& ssendMQData); 
private:
    std::string m_sReceiveData ;
    std::string m_sDeviceCode ;
    PortPool* m_pUdpPortPool ;
    bool m_bReplyStatus ;

    HttpServer* m_pHttpServer;
    
    string m_sReceiveIp;
    int m_iReceivePort;
    int m_iStreamProfile;
};

#endif
