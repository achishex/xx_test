#include "dev_health_check.h"
#include <time.h>

#include "log.h"

namespace DEV_CHECK
{
    DevCheck::DevCheck(event_base* pBase,
                       int32_t iCheckTimeDur, 
                       int32_t uiPort, 
                       uint32_t uiNeedRecvPkgNum
                      ) :m_pEventBase(pBase), m_pCheckPointEvent(NULL)
                         ,m_iDisConnNums(0), m_iCheckTimeDur(iCheckTimeDur),
                         m_uiRecvDevPort(uiPort), m_uiDevCode(""),
                         m_pCheckPointCallback(NULL), m_uiRecvPkgNums(0), m_uiNeedRcvPkgNums(uiNeedRecvPkgNum), m_uiLastUpdateTm(time(NULL))

    {
        m_ssBuf.str("");
    }

    DevCheck::~DevCheck()
    {
        if (m_pCheckPointEvent)
        {
            evtimer_del(m_pCheckPointEvent);
            event_free(m_pCheckPointEvent);
            m_pCheckPointEvent = NULL;
        }
        m_pEventBase = NULL;
    }

    bool DevCheck::StartCheckPoint(void (*pCheckPointCallBack)(int fd, short event, void* arg))
    {
        if (m_pEventBase == NULL)
        {
            m_ssBuf.str("");
            m_ssBuf << "event base is null" ;
            return false;
        }

        if (m_pCheckPointEvent == NULL)
        {
            m_pCheckPointEvent = event_new( m_pEventBase, -1, EV_PERSIST, pCheckPointCallBack, this );
            m_pCheckPointCallback = pCheckPointCallBack;
            m_ssBuf.str("");
            m_ssBuf << "start timer tm: " << time(NULL) << ", mts recv port: " << m_uiRecvDevPort;
			LOG_DEBUG_("=> %s", m_ssBuf.str().c_str() );
        }
        else 
        {
            //m_ssBuf.str("");
            //m_ssBuf << "update timer tm: " << time(NULL) << ", mts recv port: " << m_uiRecvDevPort;
			//LOG_DEBUG_("=> %s", m_ssBuf.str().c_str() );
        }

        if (m_pCheckPointEvent) 
        {
            struct timeval tv;
            evutil_timerclear(&tv);
            tv.tv_sec = m_iCheckTimeDur;
            evtimer_add( m_pCheckPointEvent, &tv );
			m_uiLastUpdateTm = time(NULL);
        }
        else 
        {
            m_ssBuf.str("");
            m_ssBuf << "event_new timer fail";
            return false;
        }
        return true;
    }

    bool DevCheck::UpdteCheckTimer()
    {
        if ( CheckDevSendPkgEnough() == false )
        {
			//if dev less pkg sent, 交给定时器超时处理.
            return true;
        }
        //重新统计dev发送的包	
        m_uiRecvPkgNums = 0;
        evtimer_del(m_pCheckPointEvent);
        return StartCheckPoint(m_pCheckPointCallback);
    }

    bool DevCheck::CheckDevSendPkgEnough()
    {
        m_uiRecvPkgNums ++;
        if ( m_uiRecvPkgNums > m_uiNeedRcvPkgNums )
        {
            return true;
        }
		//if recv num is less. dev may disconn temp.
        return false;
    }


    std::string DevCheck::ToString()
    {
        return m_ssBuf.str();
    }

    bool DevCheck::MarkStopStream()
    {
        m_iDisConnNums ++;       
        m_ssBuf.str("");
        m_ssBuf << "dev stop stream, now tm: " << time(NULL) << ", last recv " << m_uiNeedRcvPkgNums << " pkgs tm: " 
				<< m_uiLastUpdateTm  << ", mts port " 
				<< m_uiRecvDevPort << ", stop stream times: " << m_iDisConnNums;
        m_uiRecvPkgNums = 0;
        return true;
    }
    //////////////////////////
}
