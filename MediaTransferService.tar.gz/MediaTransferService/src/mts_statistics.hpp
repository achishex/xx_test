#ifndef _MTS_STATISTICS_H_
#define _MTS_STATISTICS_H_

/**
 * @file: mts_statistics.hpp
 * @brief: 
 *     通过http访问统计信息方式是: 在浏览器上输入 http://http_srv_ip:http_srv_port/mts/sts 
 *     其中http_srv_ip 和 http_srv_port 是媒体服务的http srv ip和端口
 * @author:  
 * @version: v0x0001
 * @date: 2018-05-21
 */

#include <string>
#include <map>
#include <vector>
#include <functional>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>    
#include <sys/ioctl.h>    
#include <sys/socket.h>    
#include <net/if.h>    
#include <stdio.h>    
#include <stdlib.h>    
#include <unistd.h>    
#include <netdb.h>    
#include <fcntl.h>    


#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/prettywriter.h"  
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

#include "httpServer.h"
#include "httpHandle.h"

#include "tutk/IOTCAPIs.h"
#include "tutk/AVAPIs.h"
using namespace rapidjson;

namespace MTS
{
    struct StreamInfo
    {
        StreamInfo() {} 
        virtual ~StreamInfo() {}
        void GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc);
        
        std::string sDevCode;      //parant id
        std::string sDevChannelId; //devcode

        std::string sIpClientRcvStream; //ip which client  use to recv  stream 
        uint32_t  uiPortClientRcvStream; //port which client use to recv stream 

        uint32_t uiStreamRelayPort; //port mts use to relay stream to client 
    };

    struct AudioVideoInfo
    {
        AudioVideoInfo() {}
        virtual ~AudioVideoInfo() {}

        void GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc);
        
        std::string sDevCode;  //devcode
        std::string sIpDevRcvAudio; //ip which dev use to recv audio
        uint32_t uiPortDevRcvAudio; //port which dev use to recv audio
        uint32_t uiPortRelayAudioToDev; //port which mts relay audio to dev

        std::string sIpClientRcvStream; //ip which client use to recv video
        uint32_t uiPortClientRcvStream; //port which client to recv video
        uint32_t uiPortRelayVideoToClient; //port which mts relay video to client

        std::string sIpClientRcvAudio; // ip which client  to recv audio
        uint32_t  uiPortClientRecvAudio; //port whihch client to recv audio
        uint32_t uiPortRelayAudioToClient; //port which mts relay audio to client
    };

    struct SysWRBufStat
    {
        SysWRBufStat(const std::string& statName):sStatName(statName),iStatNums(-1) {}
        virtual ~SysWRBufStat() { sStatName.clear(); }
        void CleanStat() { iStatNums = -1;}
        int32_t GetStatItem() { return iStatNums; }

        bool RunSysStat();
        
        std::string sStatName;
        int32_t iStatNums;

        class SysCmd
        {
         public:
            SysCmd():fp(NULL) {} 
            virtual ~SysCmd() { if (fp) { fclose(fp); fp = NULL; } }
            int32_t RunCmd(const std::string& sCmd);
         private:
            FILE * fp;
        };
    };

    struct NICStat
    {
        NICStat(const std::string& nicName): sNicName(nicName), 
               sTxQueName("txqueuelen"), iTxQueLen(1) {}
        virtual ~NICStat() {}

        bool NicStatRun();
        void GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc);
        //
        std::string sNicName; 
        //
        std::string sTxQueName;
        int32_t iTxQueLen;
        // ++ other items
        
        class NicCmd
        {
         public:
          NicCmd(): m_iSock(-1) {} 
          virtual ~NicCmd() { if (m_iSock > 0) { close(m_iSock); m_iSock = -1; } }
          static bool GetAllNicName(std::vector<std::string>& nicNameList);
          bool RunNicCmd(int iNicOpt, struct ifreq& inIfReq);

         private:
           int m_iSock;
        };
    };
    
    struct CloudAvStat
    {
        CloudAvStat();
        virtual ~CloudAvStat();

        std::string m_sDevCode;            //dev code
        std::string sIpDevRecvAudio;       
        uint32_t uiPortDevRecvAudio;

        uint32_t uiPortMtsRelayAudioToApp;
        uint32_t uiPortMtsRelayVideoToApp;
        //
        void GetJsonObj(rapidjson::Value& jsonObj, Document::AllocatorType& alloc);
    };

    class HandleStatistics: public HandleBase
    {
        public:
         HandleStatistics();
         virtual ~HandleStatistics();
         
         virtual void init(std::string& urldata, HttpServer* httpserver);
         virtual void deal(const char *peerIp="");
         void getReplyData(std::string& replaydata);
        
        private:
         enum STAT_TYPE {
            STAT_CONF       = 1,        //type: stats for mts conf currently
            STAT_MQ         = 2,        //type: stats for rabbit-mq conf currently
            STAT_CURSTREAM  = 3,        //type: stats for stream preview currently
            STAT_CURAVSPEAK = 4,        //type: stats for visable speak  currently
            STAT_CLIENTS    = 5,        //type: stats for accessing clients nums currently 
            STAT_NETWRBUFLEN    = 6,    //type: stats for rwbuflen/max/default on nic currently
            STAT_NICCONF        = 7,    //type: stats for txquelen on nic currently
            STAT_CURINOUTFLOW   = 8,    //type: stats for current in/out flow on nic currently
            STAT_CLOUDAV        = 9,    //type: stats for cloud speak currently
            STAT_UUIDVIP        = 10,    //type: stats for uuid dev ip list 
         };

        private:
         void RegisterStatType();
         typedef void (HandleStatistics::*StatInterface)();

         //------------- concrete stats interface --------//
         void GetConfInfo();
         void GetMQReqRespStat();
         void GetCurStartedStremStat();
         void GetCurAudioVideoStat();
         inline void GetClientNums();
         void GetSysWRBufLen();
         void GetNicStats();
         void GetCloudAVStats();
         void GetUuidIpList();
        
        private:
         HttpServer* m_pHttpServer;
         bool m_bReplyStatus;
        
         //-------------- define stats result set ---------------//
         //mts conf stat item. eg: rabbit-mq/tutk config
         std::map<std::string, int32_t> m_mpIntConf;
         std::map<std::string, std::string> m_mpStrConf;

         //key: client ip + port; all video preview stat items
         std::map<std::string, StreamInfo> m_mpStreamStat;         
        
         //key: devcode; all visable speak stat items
         std::map<std::string, AudioVideoInfo> m_mpAudioVideoStat; 
        
         //client stat nums
         uint32_t m_uiClientNums;
        
         //sys w/r buf len stat, key: stat item name,eg: SNAMERMEMMAX/SNAMERMEMDEFAULT/...
         std::map<std::string, SysWRBufStat> m_mpWRBufLen;  
         
         //all nic stat in this system,eg: eth0, eth1 and so on..., key: like eth0
         std::map<std::string, NICStat> m_mpNicStats;

         //all dev cloud speak, key is devcode
         std::map<std::string, CloudAvStat> m_mpCloudAvStats;

         //all uuid correspond to dev ip
         std::map<std::string, std::vector<std::string>>m_mpUuidVIp; 
    
         //---------- registered stats interface set ------//
         //all interface to stat, is set of func pointer. eg: GetConfInfo()/GetMQReqRespStat()...
         std::map<int32_t, StatInterface> m_mpToStatType; //

         static const std::string SNAMERMEMMAX;
         static const std::string SNAMERMEMDEFAULT;
         static const std::string SNAMEWMEMMAX;
         static const std::string SNAMEWMEMDEFAULT;
    };
}
#endif

