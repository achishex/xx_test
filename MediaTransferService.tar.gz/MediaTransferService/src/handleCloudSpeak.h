///////////////////////////////////////////////////////////////
//
// FileName : handleCloudSpeak.h
// Creator  : chenbo
// Date     : 2018-02-28
// Comment  : 
//
///////////////////////////////////////////////////////////////
#ifndef _HANDLE_CloudSpeak_H_
#define _HANDLE_CloudSpeak_H_

#include "httpHandle.h"


/**
*** 云呼叫获取视频流和音频流请求的事物操作类
**/
class HandleCloudVoiceVideoStart : virtual public HandleBase
{
public:
    HandleCloudVoiceVideoStart();
    virtual ~HandleCloudVoiceVideoStart();
    
    void init(std::string&  urldata, HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    
    void getReplyData(std::string& replaydata);
private:
    bool receiveDataParse(std::string& urldata, const char *peerIp);
    bool encodeSuccessData(int devvideoport,int devvoiceport,int cltvoiceport );
private:
    std::string m_sReceiveData;
    //解析客户端发送过来的数据并保存在以下成员中
    std::string m_sVoiceIp;
    int m_iVoicePort;

    std::string m_sVideoIp;
    int m_iVideoPort;

    std::string m_sdevReceiveIp;
    int m_idevReceivePort;
    
    std::string m_sDeviceCode;

    //操作成功返回给客户端的数据
    std::string m_sSuccessData;

    //类内部使用的成员变量
    PortPool* m_pUdpPortPool;
    bool m_bReplyStatus;
    HttpServer* m_pHttpServer;
};


/**
*** 请求停止流操作类
**/
class HandleCloudVoiceVideoStop : public HandleBase
{
public:
    HandleCloudVoiceVideoStop();
    ~HandleCloudVoiceVideoStop();
    //Handle_stream_start(std::string& urldata):m_sReceiveData(urldate){}
    void init(std::string& urldata, HttpServer* httpserver);
    virtual void deal(const char *peerIp="");
    void getReplyData(std::string& replaydata);

private:
    bool receiveDataParse(std::string& urldata, const char *peerIp);
    bool getSendToMQData(std::string& ssendMQData); 
    
private:
    std::string m_sReceiveData ;
    std::string m_sDeviceCode ;
    PortPool* m_pUdpPortPool ;
    bool m_bReplyStatus ;

    string m_sReceiveIp;
    int m_iReceivePort;
    int m_iStreamProfile;

    HttpServer* m_pHttpServer;
};

#endif
