#include "udpClient.h"

UdpClient::UdpClient()
{
	m_doConnect = false;
	m_port = 0;
    bzero(&m_remoteAddr, sizeof(m_remoteAddr));
    
    m_sock=socket(PF_INET,SOCK_DGRAM,0);
    if ( m_sock < 0 )
    {
        LOG_NOTICE_("create socket failed");
    }
}

UdpClient::UdpClient(int localPort)
{
    m_port = localPort;
    bzero(&m_remoteAddr, sizeof(m_remoteAddr));

	m_doConnect = true;

    m_sock=socket(PF_INET,SOCK_DGRAM,0);
    if ( m_sock < 0 )
    {
        LOG_NOTICE_("create socket failed");
        return;
    }

    struct sockaddr_in localAddr;
    localAddr.sin_family = AF_INET;
    localAddr.sin_port = htons(m_port);
    localAddr.sin_addr.s_addr = INADDR_ANY;
    bzero(&localAddr.sin_zero, sizeof(localAddr.sin_zero));
    int _ret = bind(m_sock, (sockaddr*)&localAddr, sizeof(localAddr));
    if ( 0 != _ret )
    {
       LOG_NOTICE_("bind udp sockaddr failed!");
       return;
    }
}

UdpClient::UdpClient(string ip, int localPort)
  : m_ip( ip )
{
    //m_ip = ip;
    m_port = localPort;
    bzero(&m_remoteAddr, sizeof(m_remoteAddr));
	m_doConnect = false;

    m_sock=socket(PF_INET,SOCK_DGRAM,0);
    if ( m_sock < 0 )
    {
        LOG_NOTICE_("create socket failed");
        return;
    }

    struct sockaddr_in localAddr;
    // localAddr.sin_family = AF_INET;
    if ( m_ip.empty() )
    {
        localAddr.sin_addr.s_addr = INADDR_ANY;
    }
    else
    {
        localAddr.sin_addr.s_addr = inet_addr(const_cast<char*>(m_ip.c_str()));
    }
    localAddr.sin_port = htons(m_port);
    localAddr.sin_addr.s_addr = INADDR_ANY;
    bzero(&localAddr.sin_zero, sizeof(localAddr.sin_zero));
    int _ret = bind(m_sock, (sockaddr*)&localAddr, sizeof(localAddr));
    if ( 0 != _ret )
    {
       LOG_NOTICE_("bind udp sockaddr failed!");
       return;
    }
}

UdpClient::UdpClient(const char *ip, int localport, bool do_connect)
{
	Init(ip, localport, do_connect);
}

void UdpClient::Init(const char *ip, int localport, bool do_connect)
{
	m_port = localport;
	m_ip.append(ip);
	m_doConnect = true;
	
    m_sock=socket(PF_INET,SOCK_DGRAM,0);
    if ( m_sock < 0 )
    {
        LOG_NOTICE_("create socket failed");
        return;
    }
	const int SND_BUF_SIZE = 2*1024*1024;

    if ( setsockopt(m_sock, SOL_SOCKET, SO_SNDBUF, & SND_BUF_SIZE, sizeof(SND_BUF_SIZE)) < 0)
    {
        LOG_ERROR_( "setsockopt send_buf_size=%d failed: %d",  SND_BUF_SIZE,  errno );
    }

	m_remoteAddr.sin_family = AF_INET;
    m_remoteAddr.sin_addr.s_addr = inet_addr(ip);
    m_remoteAddr.sin_port = htons(localport);
	m_doConnect = do_connect;
    if(m_doConnect == true)
    {
    	if(connect(m_sock, (struct sockaddr *)&m_remoteAddr, sizeof(m_remoteAddr)) < 0)
   	 	{
   	 		LOG_NOTICE_("udp connect failed");
        	m_doConnect = false;
      	}
    }
}

UdpClient::UdpClient(const UdpClient &copy)
{
	m_sock = copy.m_sock;
	m_port = copy.m_port;
	m_ip = copy.m_ip;
	m_doConnect = copy.m_doConnect;
	memcpy(&m_remoteAddr, &(copy.m_remoteAddr), sizeof(m_remoteAddr));
}

UdpClient &UdpClient::operator=(const UdpClient &copy)
{
	m_port = copy.m_port;
	m_ip = copy.m_ip;
	m_doConnect = copy.m_doConnect;
	memcpy(&m_remoteAddr, &(copy.m_remoteAddr), sizeof(m_remoteAddr));
	m_sock = copy.m_sock;
	return *this;
}

int UdpClient::SendData(const char *buf, int len)
{
	if(m_doConnect == true)
	{
		return sendto(m_sock, buf, len, 0, NULL, 0);
	}
	else
	{
		return sendto(m_sock, buf, len, 0, (struct sockaddr *)&m_remoteAddr, sizeof(struct sockaddr_in));
	}
}

int UdpClient::sendTo(string dstIp, int dstPort, string str)
{
    return sendTo(dstIp, dstPort, str.c_str(), str.length());
}

int UdpClient::sendTo(string dstIp, int dstPort, const void* buf, int len)
{
    struct sockaddr_in remote_addr;
    memset(&remote_addr, 0, sizeof(remote_addr));
    remote_addr.sin_family=AF_INET;
    remote_addr.sin_addr.s_addr=inet_addr(const_cast<char*>(dstIp.c_str()));
    remote_addr.sin_port=htons(dstPort);

    if ( m_sock < 0 )
    {
        LOG_NOTICE_("the server sock was uninitialized");
        return -1;
    }

    int senLen = sendto(m_sock, buf, len, 0, (sockaddr*)&remote_addr, sizeof(remote_addr));
	if ( senLen < 0)
    {
		LOG_NOTICE_("the udp send buf error!");
        return -1;
	}

	return senLen;
}


UdpClient::~UdpClient()
{
    close(m_sock);
}
