///////////////////////////////////////////////////////////////
//
// FileName : 
// Creator  : fan
// Date     : 2017-12-21
// Comment  : rabbitMQ  client 源码实现
//
///////////////////////////////////////////////////////////////

#include "rabbitMQClient.h"  
#include "log.h"
#include <assert.h>

#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/prettywriter.h"  

RabbitMQClient::RabbitMQClient()
{
	m_amqpConn = amqp_new_connection();
	if ( NULL == m_amqpConn)
	{
		LOG_ERROR_(" amqp_new_connection error");
    	throw std::bad_alloc();
    }
	
	_udpServerIp = ConfigXml::getIns()->getValue("UdpServer", "udpServerIp");
	_MQServerIp = ConfigXml::getIns()->getValue("RabbitMQ", "host") ;

    m_pDevInfo = NULL;
}

RabbitMQClient::~RabbitMQClient()
{
	this->closeConnection();
	int replycon = amqp_destroy_connection(m_amqpConn);
	if(replycon != AMQP_STATUS_OK)
	{
		LOG_ERROR_(" Ending connection failed %d",replycon);
	}
}

void RabbitMQClient::closeConnection()
{
	amqp_rpc_reply_t reply = amqp_channel_close(m_amqpConn, 1, AMQP_REPLY_SUCCESS);
	if(reply.reply_type != AMQP_RESPONSE_NORMAL)
	{
		LOG_ERROR_(" Closing channel failed %d",reply.reply_type);
	}
	reply = amqp_connection_close(m_amqpConn, AMQP_REPLY_SUCCESS);
	if(reply.reply_type != AMQP_RESPONSE_NORMAL)
	{
		LOG_ERROR_("Closing connection failed %d",reply.reply_type);
	}
	LOG_INFO_("mq close success");
}

RabbitMQClient* RabbitMQClient::create()
{
	return new RabbitMQClient();
}

int RabbitMQClient::logIn()
{
	//获取ＭＱ登录发布相关配置
    string host = ConfigXml::getIns()->getValue("RabbitMQ", "host") ;
    int port = atoi(ConfigXml::getIns()->getValue("RabbitMQ", "port").c_str()) ;
    string vhost = ConfigXml::getIns()->getValue("RabbitMQ", "vhost") ;
    string username = ConfigXml::getIns()->getValue("RabbitMQ", "username") ;
    string password = ConfigXml::getIns()->getValue("RabbitMQ", "password") ;
	int iReturn = 0 ;
    iReturn = this->logIn(host.c_str(),port,vhost.c_str(), username.c_str(), password.c_str()) ;	
	if(iReturn < 0)
	{	
		_udpLogBase.WriteMonitorLog("RabbitMQFail", "initial login fail.check local log file");
	}
	return iReturn;
}
int RabbitMQClient::logIn(const char* host, int port, char const* vhost, const char* username, const char* password)
{
	int channelid = 1;
	amqp_socket_t* socket = amqp_tcp_socket_new(m_amqpConn);
	struct timeval tv;
	tv.tv_sec=1;
	tv.tv_usec=0;
  	int status = amqp_socket_open_noblock(socket, host, port, &tv);
  	if (status)
	{
   		LOG_ERROR_(" amqp_socket_open() failed %d",status);
		return -1;
 	}
	amqp_rpc_reply_t reply = amqp_login(m_amqpConn, vhost, 0, 131072, 0, AMQP_SASL_METHOD_PLAIN, username, password);
	if(reply.reply_type != AMQP_RESPONSE_NORMAL)
	{
		LOG_ERROR_("amqp_login() failed %d",reply.reply_type );
		return -1;
	}
	amqp_channel_open(m_amqpConn, channelid);
	reply = amqp_get_rpc_reply(m_amqpConn);
	if(reply.reply_type != AMQP_RESPONSE_NORMAL)
	{
		LOG_ERROR_(" opening channel failed %d",reply.reply_type);
		return -1;
	}
	LOG_DEBUG_("login success");
	return 0;
}

int RabbitMQClient::publishMessage(const char* message)
{
	string msgqueue = ConfigXml::getIns()->getValue("RabbitMQ", "msgQueue") ;
	int  iReturn = 0 ;
    iReturn = this->basicPublish(msgqueue.c_str(),message) ;
	return iReturn;
}

int RabbitMQClient::basicPublish(const char* queuename, const char* body)
{
	int channelid = 1;
	// amqp_basic_properties_t props;
	// props._flags = AMQP_BASIC_CONTENT_TYPE_FLAG | AMQP_BASIC_DELIVERY_MODE_FLAG;
	// props.content_type = amqp_cstring_bytes("application /json");
	// props.content_encoding = amqp_cstring_bytes("UTF-8");
	int replypub =  amqp_basic_publish(m_amqpConn,
									channelid,
									amqp_cstring_bytes(""),
									amqp_cstring_bytes(queuename),
									0,
									0,
									// &props,
									NULL,
									amqp_cstring_bytes(body));
	if(replypub != AMQP_STATUS_OK)
	{
		LOG_ERROR_("rabbitMQ publish failed,reply is : %d",replypub);
		return -1;
	}

	return 0;
}

void* consumerFun(void * arg)
{
	RabbitMQClient* rabbitMQ = static_cast<RabbitMQClient*>(arg);
	if ( rabbitMQ != NULL)
	{
		//登录ＭＱ,启动的消费线程
        int mqret = rabbitMQ->logIn();
        if (mqret < 0)
        {
            mqret = rabbitMQ->logIn();
            if ( mqret < 0 )
            {
                LOG_ERROR_(" rabbitmq login error %d",mqret) ;
            //return -1;
            }
        }
		rabbitMQ->loopConsumer();
	}
	return NULL;
}

void RabbitMQClient::consumerRun()
{
	pthread_t thr;
	int ret = pthread_create(&thr,NULL,consumerFun,this);
	if (ret != 0 )
	{
		LOG_ERROR_(" cteate consume pthread error" );
	}
}
void RabbitMQClient::consumerInit()
{
	int channelid = 1;
	string queueName = ConfigXml::getIns()->getValue("RabbitMQ", "replyToQueue");
	amqp_basic_qos(m_amqpConn, channelid, 0, 1, 0);
	amqp_basic_consume(m_amqpConn, channelid, amqp_cstring_bytes(queueName.c_str()), amqp_empty_bytes, 0, 0, 0, amqp_empty_table);
	amqp_rpc_reply_t reply =amqp_get_rpc_reply(m_amqpConn);
	if(reply.reply_type != AMQP_RESPONSE_NORMAL)
	{
		LOG_ERROR_(" basic_consume failed %d ",reply.reply_type);
	}

}

/*
 *usage:get traceId and spanId from MQ reply
 */
bool ParseMQReply(const char *reply, string &traceId, string &spanId)
{
    rapidjson::Document document;
	document.Parse(reply);
	if (document.HasParseError() || !document.IsObject())  
	{	
		LOG_ERROR_("parse MQ reply error.");
		return false;
	}

    if( !document.HasMember("traceId") || !document["traceId"].IsString() )
    {

		LOG_ERROR_("parse MQ reply traceId error.") ;
        return false ;
    }
    traceId = document["traceId"].GetString();

    if( !document.HasMember("spanId") || !document["spanId"].IsString() )
    {

		LOG_ERROR_("parse MQ reply spanId error") ;
        return false ;
    }
    spanId = document["spanId"].GetString();
	return true;
}

void RabbitMQClient::loopConsumer( )
{
	
	int channelid = 1;
	char buf[1024*10]={0};
	struct timeval tv = {0,500000};
	this->consumerInit();
	
	while ( 1 ) 
	{
		amqp_frame_t frame;
		amqp_maybe_release_buffers(m_amqpConn);
		int result = amqp_simple_wait_frame_noblock(m_amqpConn, &frame,&tv);
		//int result = amqp_simple_wait_frame(m_amqpConn, &frame);
		if ( result < 0 )
		{	
			if (result == AMQP_STATUS_HEARTBEAT_TIMEOUT || result == AMQP_STATUS_SOCKET_ERROR ||
			     result == AMQP_STATUS_SSL_ERROR || result == AMQP_STATUS_CONNECTION_CLOSED )
			{//重连机制
				LOG_ERROR_(" amqp_simple_wait_frame result: %d",  result);
				int mqret = this->logIn();
				if ( mqret < 0 )
        		{
            		LOG_ERROR_(" rabbitmq relogin fail %d",mqret ) ;
					_udpLogBase.WriteMonitorLog("RabbitMQFail", "relogin fail.check local log file");
					sleep(1);
					continue;
        		}
				LOG_INFO_("rabbitmq relogin success");
				this->consumerInit();
				
			}
			continue ;
		}
		
		amqp_basic_deliver_t* pdeliver = (amqp_basic_deliver_t*)frame.payload.method.decoded;
		if ( frame.frame_type != AMQP_FRAME_METHOD || frame.payload.method.id != AMQP_BASIC_DELIVER_METHOD )
		{
			LOG_ERROR_("Frame type: %d, channel: %d, Method: %s",frame.frame_type, frame.channel, amqp_method_name(frame.payload.method.id) );
			// amqp_basic_ack(m_amqpConn, channelid, pdeliver->delivery_tag, 0);
			// continue;
		}

		
		
		result = amqp_simple_wait_frame_noblock(m_amqpConn, &frame,&tv);
		if ( result < 0)
		{
			LOG_ERROR_(" Frame type: %d, channel: %d, Method: %s",frame.frame_type, frame.channel, amqp_method_name(frame.payload.method.id) );
			//continue ;
		}

		if ( frame.frame_type != AMQP_FRAME_HEADER )
		{
			LOG_ERROR_("frame.frame_type=%d expected header!", frame.frame_type);
			amqp_basic_ack(m_amqpConn, channelid, pdeliver->delivery_tag, 0);
			continue ;
		}

		amqp_basic_properties_t* pproperties = (amqp_basic_properties_t *) frame.payload.properties.decoded;
		if ( pproperties->_flags == AMQP_BASIC_CONTENT_TYPE_FLAG )
		{
			LOG_ERROR_(" Content-type: %.*s",(int)pproperties->content_type.len, (char*)pproperties->content_type.bytes );
			//continue ;
		}

		size_t body_target = frame.payload.properties.body_size;
		size_t body_received = 0;

		//int sleep_seconds = 0;
		while ( body_received < body_target )
		{
			result = amqp_simple_wait_frame_noblock(m_amqpConn, &frame,&tv);
			if ( result < 0 )
			{
				LOG_ERROR_("Frame type: %d, channel: %d, Method: %s",frame.frame_type, frame.channel, amqp_method_name(frame.payload.method.id) );
				//break ;
			}

			if ( frame.frame_type != AMQP_FRAME_BODY )
			{
				LOG_ERROR_(" frame.frame_type=%d expected body!", frame.frame_type);
				break ;
			}
	
			memcpy(buf+body_received, (char*)frame.payload.body_fragment.bytes, frame.payload.body_fragment.len);
			body_received += frame.payload.body_fragment.len;
		}
		/* do something */
		LOG_INFO_("MQ reply is :%s",buf);
		string traceId;
		string spanId;
		if(ParseMQReply(buf, traceId, spanId) == true)
		{
			_udpLogBase.WriteTraceLog(traceId, spanId, _MQServerIp, _udpServerIp, buf, "INFO");
		}

        amqp_basic_ack(m_amqpConn, channelid, pdeliver->delivery_tag, 0);

        std::string sDevIp, sMsgId;
        
        ParseDevSrcIP(sDevIp, sMsgId, buf);
        NotifyDevSrcIpToUdpEvent(sMsgId, sDevIp);
        UpdateMsgStatus(sMsgId);
		
        memset(buf, 0, sizeof(buf));
	}

}
/*
int RabbitMQClient::queueClear(const char* queuename, vector<string>& messagevec) 
{
	int channelid = 1;
	char buf[1024*10]={0};
	
	amqp_basic_qos(m_amqpConn, channelid, 0, 1, 0);
	amqp_basic_consume(m_amqpConn, channelid, amqp_cstring_bytes(queuename), amqp_empty_bytes, 0, 0, 0, amqp_empty_table);
	amqp_rpc_reply_t reply =amqp_get_rpc_reply(m_amqpConn);
	if(reply.reply_type != AMQP_RESPONSE_NORMAL)
	{
		log.error("%s %s %d Opening channel failed ",  __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}

		//int loopCount = 2;
		int ret = 0;
		struct timeval tv={0,10000};
		string message;
		string str_waitMQRespondTime = ConfigXml::getIns()->getValue("RabbitMQ", "waitMQRespondTime");
		int i_waitMQRespondTime = 100;
		if ( !str_waitMQRespondTime.empty() )
		{
			i_waitMQRespondTime = atoi(str_waitMQRespondTime.c_str());
		}
		struct timeval starttv;
		struct timeval endltv;
    	gettimeofday(&starttv,NULL);
		while ( 1 ) 
		{
			memset(buf,0, sizeof(buf));
			gettimeofday(&endltv,NULL);
			int elapseTime = endltv.tv_sec*1000+endltv.tv_usec/1000 - (starttv.tv_sec*1000+starttv.tv_usec/1000) ;
			
			if ( elapseTime > i_waitMQRespondTime )
			{
				//amqp_basic_ack(m_amqpConn, channelid, pdeliver->delivery_tag, 0);
				return -1 ;
			}

			amqp_frame_t frame;
			amqp_maybe_release_buffers(m_amqpConn);
			int result = amqp_simple_wait_frame_noblock(m_amqpConn, &frame,&tv);
			//log.info("%s %s %d amqp_simple_wait_frame ", __FILE__, __FUNCTION__, __LINE__);
			if ( (result !=AMQP_STATUS_TIMEOUT) && (result !=AMQP_STATUS_OK) )
			{	
				return -1;	
			}
			else if(result == AMQP_STATUS_TIMEOUT)
			{
				//log.info("%s %s %d time out", __FILE__, __FUNCTION__, __LINE__);
				continue;
				
			}

			if ( frame.frame_type != AMQP_FRAME_METHOD || frame.payload.method.id != AMQP_BASIC_DELIVER_METHOD )
			{
				log.error("%s %s %d Frame type: %d, channel: %d, Method: %s", __FILE__, __FUNCTION__, __LINE__, 
				frame.frame_type, frame.channel, amqp_method_name(frame.payload.method.id) );
				continue;
			}

			amqp_basic_deliver_t* pdeliver = (amqp_basic_deliver_t*)frame.payload.method.decoded;
			// log.info("Delivery_tak: %d, exchange: %.*s, routing_key: %.*s", pdeliver->delivery_tag,
			// 	(int)pdeliver->exchange.len, (char*)pdeliver->exchange.bytes,
			// 	(int)pdeliver->routing_key.len, (char*)pdeliver->routing_key.bytes );

			result = amqp_simple_wait_frame_noblock(m_amqpConn, &frame, &tv);
			if ( (result !=AMQP_STATUS_TIMEOUT) && (result !=AMQP_STATUS_OK) )
			{	
				return -1;	
			}
			else if(result == AMQP_STATUS_TIMEOUT)
			{
				continue;
			}

			if ( frame.frame_type != AMQP_FRAME_HEADER )
			{
				log.error("%s %s %d frame.frame_type=%d expected header!", __FILE__, __FUNCTION__, __LINE__, frame.frame_type);
				
				return -1;
			}

			amqp_basic_properties_t* pproperties = (amqp_basic_properties_t *) frame.payload.properties.decoded;
			if ( pproperties->_flags == AMQP_BASIC_CONTENT_TYPE_FLAG )
			{
				log.error("%s %s %d Content-type: %.*s", __FILE__, __FUNCTION__, __LINE__, 
				(int)pproperties->content_type.len, (char*)pproperties->content_type.bytes );
			}

			size_t body_target = frame.payload.properties.body_size;
			size_t body_received = 0;
			
			while ( body_received < body_target )
			{
				result = amqp_simple_wait_frame_noblock(m_amqpConn, &frame, &tv);
				if ( result !=AMQP_STATUS_OK )
				{	
					break;	
				}
			
				if ( frame.frame_type != AMQP_FRAME_BODY )
				{
					log.error("%s %s %d frame.frame_type=%d expected body!", __FILE__, __FUNCTION__, __LINE__, frame.frame_type);
					break;
				}
				memcpy(buf+body_received, (char*)frame.payload.body_fragment.bytes, frame.payload.body_fragment.len);
				body_received += frame.payload.body_fragment.len;
				if (body_received > body_target)
				{
					break;
				}
			}
			//本次接收数据不对启动下次接收
			if ( body_received != body_target )
			{
				continue;
			}
			
			if(NULL == buf)
			{
				continue;
			}
			message = buf;

			messagevec.push_back(message) ;
	 		//log.info("do queue  clear  MQ message : %s", message.c_str()) ;
			
			amqp_basic_ack(m_amqpConn, channelid, pdeliver->delivery_tag, 0);
		}

	return ret;
} */


bool RabbitMQClient::ParseDevSrcIP(std::string& sIP, std::string& sMsgId, 
                                   const std::string& sSDPBuf)
{
    if (m_pDevInfo == NULL)
    {
        LOG_ERROR_("devinfo handle ptr is null");
        return false;
    }

    rapidjson::Document document;
	document.Parse(sSDPBuf.c_str());
	if (document.HasParseError() || !document.IsObject())  
	{	
		LOG_ERROR_("parse MQ reply error.");
		return false;
	}

    rapidjson::Value payloadJson;
    if ( !document.HasMember("payload") || !document["payload"].IsObject() )
    {
        LOG_ERROR_("mq reply not has payload obj item");
        return false;
    }
    payloadJson = document["payload"].GetObject();
    
    rapidjson::Value correctIdJson;
    if ( !document.HasMember("correlationID") || !document["correlationID"].IsString() )
    {
        LOG_ERROR_("mq reply not has correlationID string item");
        return false;
    }
    sMsgId = document["correlationID"].GetString();

    if ( !payloadJson.HasMember("result") || !payloadJson["result"].IsObject() )
    {
        LOG_ERROR_("mq reply not has result obj item");
        return false;
    }
    rapidjson::Value resultJson = payloadJson["result"].GetObject();


    if ( !resultJson.HasMember("SDP") || !resultJson["SDP"].IsString() )
    {
        LOG_DEBUG_("mq reply not has SDP string item");
        return false;
    }

    std::string sSdpData = resultJson["SDP"].GetString();
    auto funcObj = [](const std::string sSdp, 
                       const std::string sIdentification, 
                       std::vector<std::string> &vSdp)
    {
        vSdp.clear();
        int iStartSeat = sSdp.find(sIdentification);
        if (iStartSeat < 0)
        {
            return false;
        }
        iStartSeat += sIdentification.length();
        int iEndSeat = sSdp.find("\r\n", iStartSeat);
        int iTempSeat = sSdp.find(" ", iStartSeat);
        while (iTempSeat < iEndSeat&&iTempSeat > 0)
        {   
            vSdp.push_back(sSdp.substr(iStartSeat, iTempSeat - iStartSeat));
            iStartSeat = iTempSeat + 1;
            iTempSeat = sSdp.find(" ", iStartSeat);

        }   
        vSdp.push_back(sSdp.substr(iStartSeat, iEndSeat - iStartSeat));
        return true;
    };

    std::string sDim("o=");
    std::vector<std::string> vSdpData;
    if (false == funcObj(sSdpData, sDim, vSdpData))
    {
        LOG_ERROR_("parse sdp by deim symblom: %s fail", sDim.c_str());
        return false;
    }

    if (vSdpData.size() != 6)
    {
        LOG_ERROR_("o= feild nums not eq 6, check it");
        return false;
    }

    sIP = vSdpData[5];
    //if has sdp info, then update dev ip 
    if ( !sMsgId.empty() )
    {
        m_pDevInfo->SetDevIp(sMsgId, sIP);
        LOG_DEBUG_("dev ip: %s", sIP.c_str());
    }

    return true;
}

bool RabbitMQClient::NotifyDevSrcIpToUdpEvent( const std::string& sMsgId, 
                                               const std::string& sDevip )
{
    if (m_pDevInfo == NULL)
    {
        LOG_ERROR_("devinfo handle ptr is null");
        return false;
    }
    return m_pDevInfo->SendDataToUdpEvent( sMsgId );
}

bool RabbitMQClient::UpdateMsgStatus( const std::string& sMsgId )
{
    if (m_pDevInfo == NULL)
    {
        LOG_ERROR_("devinfo handle ptr is null");
        return false;
    }
    m_pDevInfo->DelMsgId( sMsgId ); 

    return true;
}
