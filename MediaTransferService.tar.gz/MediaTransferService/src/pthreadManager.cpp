//---------------------------------------------------------------------------
//
// FileName : pthreadManager.cpp
// Creator  : tanght
// Date     : 2018-2-7
// Comment  : pthreadManager source file
//
//---------------------------------------------------------------------------

#include "pthreadManager.h"
#include <event2/thread.h>
#include "log.h"

extern Log *pMTSLog;

PthreadManager* PthreadManager::m_instance = NULL;
PthreadManager* PthreadManager::getInstance()
{
    if ( NULL == PthreadManager::m_instance )
    {
        PthreadManager::m_instance = new PthreadManager();
    }
    return PthreadManager::m_instance;
}

PthreadManager::PthreadManager() : m_cur_thread_index( 0 ) // 线程池管理类构造函数
{
    evthread_use_pthreads();
   //  printf( "size: event=%lu \n",  sizeof( struct event ) ) ; // 128
}

PthreadManager::~PthreadManager()
{
}

int PthreadManager::init( int workThreadCount )
{
    if( workThreadCount  <  1 ) { workThreadCount  =  1 ; }

    for ( int i = 0;  i < workThreadCount;  ++i )
    {
        UdpServerEventBase * t  = new UdpServerEventBase( i + 1 ); // thread
        if ( NULL == t )
            break ;
        t->start();
        m_thread_list.push_back( t );
        // log.notice( "create thread %d : %ld", t->getid(),  t->gettid());
    }

    EventManager::ins()->init(get_idle_thread()->get_base()); 
    return 0 ;
}

string GetCmdType(int type)
{
	return	type == COMMON_START ? "COMMON_START" :
			type == STREAMING_START ? "STREAMING_START":
			type == VOICEVIDEO_START ? "VOICEVIDEO_START":
			type == DEVICECALL_REQUIRE ? "DEVICE_CALL_REQURE":
			type == DEVICECALL_START ? "DEVICECALL_START":
			type == STREAMING_STOP ? "STREAMING_STOP":
			type == DEVICECALL_STOP ? "DEVICECALL_STOP":
			type == VOICEVIDEO_STOP ? "VOICEVIDEO_STOP":
			type == CLOUDVIDEO_START ? "CLOUDVIDEO_START":
			type == CLOUDVOICE_START ? "CLOUDVOICE_START":
			type == CLOUDSPEAK_START ? "CLOUDSPEAK_START":
			type == CLOUDSPEAK_STOP ? "CLOUDSPEAK_STOP":
			"REQUEST_UNKNOWN";
}

void PthreadManager::analyseHttpMessage( void * buf,  int buf_len )
{
    //LOG_INFO_( "buf=%p len=%d \n",  buf,  buf_len );
    if( ( buf  ==  NULL )  ||  ( buf_len  !=  sizeof( S_clientToIPCMsg ) ) )
    {
        LOG_NOTICE_( "bad size: buf=%p len=%d expected=%d\n",  buf,  buf_len,  sizeof( S_clientToIPCMsg ) );
        return ;
    }

    S_clientToIPCMsg  * m  =  static_cast< S_clientToIPCMsg * >( buf ) ;

    int                    now_client_count = 0 ;
    UdpEvent            *  now_event  =  NULL ;
    UdpServerEventBase  *  now_base   =  NULL ;

    int  local_port  =  m->localPort ;
    E_DstSendType dstSendType = DATA_NORMAL;
    if ( m->command == CLOUDVIDEO_START)
    {
        dstSendType = DATA_TUTKVIDEO;
    }
    else if ( m->command == CLOUDVOICE_START ) 
    {
        dstSendType = DATA_TUTKVOICE;
    }
    else 
    {
    }

    Dst   dst( m->sendToPort,  m->sendToIp, dstSendType ) ;
    // find current info by port
    m_client_info.find_event( local_port,   now_client_count,  & now_event,  & now_base ) ; 

	string sCommand = GetCmdType(m->command);

    LOG_INFO_( "handle udp command. cmd:%s, local_port:%d, dst:[%s:%d], event:%p, base:%p, now_client_count:%d, msgtag:%s"  
    	, sCommand.c_str()
    	, local_port
    	, dst.get_ip()
    	, dst.get_port()
      	, now_event
      	, now_base
      	, now_client_count
		, m->chDevIndeCode) ;
      	
    if( local_port  <=  0 )
    {
        LOG_ERROR_( "illegal local port:%d, msgtag:%s",  local_port, m->chDevIndeCode) ;
        return ;
    }

    switch( m->command ) // 命令类型
    {
        case STREAMING_STOP : // 停止1个客户端的推送
        {
            if( dst.get_port()  <=  0 )
            {
                LOG_ERROR_( "illegal dst port:%d, msgtag:%s",   dst.get_port() , m->chDevIndeCode);
                return ;
            }

			if( now_client_count  >  1 )
            {
                now_event->del_dst( dst );
                m_client_info.del_client( local_port,  dst.get_ip(),  dst.get_port() );
            }
            else if( now_client_count  ==  1 ) // http server 已做过检查. 此处不检查目标ip/port是否匹配
            {
                now_event->begin_destroy( local_port ); // 释放
                usleep( 100 ) ; // us.
                m_client_info.del_event( local_port );
            }
            
            break;
        }

        case VOICEVIDEO_STOP: // fall thru!! // 停止此设备的推送
        case DEVICECALL_STOP:                // 停止此设备的推送
        {
            if( now_client_count  >  0 )
            {
                now_event->begin_destroy( local_port ); // 释放

                usleep( 100 ) ; // us.
                m_client_info.del_event( local_port );
            }
            break;
        }

        case VOICEVIDEO_START : // fall thru!!
        case DEVICECALL_START : // fall thru!!
        case  STREAMING_START : // fall thru!!
        case     COMMON_START : //
        {
            if( dst.get_port()  <=  0 )
            {
                LOG_ERROR_( "illegal dst port:%d, msgtag:%s",   dst.get_port() , m->chDevIndeCode);
                return ;
            }
            if( now_event  ==  NULL )
            {
                now_base     =   get_idle_thread( ); // 一定能找到
                now_event    =   EventManager::ins()->acquire(); //不用判断.
                int rc =  now_event->init( local_port,  m->chDevIndeCode, now_base->get_base() );
                if( rc  ) // 失败
                {
                    LOG_ERROR_( "init local port:%d event failed! rc:%d, msgtag:%s",  local_port,  rc, m->chDevIndeCode);
                }
            }
            m_client_info.add( local_port,  dst.get_ip(),  dst.get_port(),  now_event,  now_base ) ; // add client
            now_event->add_dst( dst );

            break;
        }
        case CLOUDVIDEO_START : // fall thru!! 云对讲.视频
        case CLOUDVOICE_START : //                   .音频
        {
            //不校验目的端端口 目的端为tutk通道
            std::strncpy( dst.m_chDevIndexCode ,  m->chDevIndeCode,  sizeof( dst.m_chDevIndexCode ) - 1 ) ;
            if( m->command  ==  CLOUDVIDEO_START ) // 云对讲.视频
            {
                dst.m_enDataType =  DATA_TUTKVIDEO  ;
                LOG_NOTICE_( "udpServer deal the cloud video speak start request" );
            }
            else // 云对讲.音频
            {
                dst.m_enDataType =  DATA_TUTKVOICE ;
                LOG_NOTICE_( "udpServer deal the cloud voice speak start request" );
            }

            if( now_event  ==  NULL )
            {
                now_base     =   get_idle_thread( ); // 一定能找到
                now_event    =   EventManager::ins()->acquire(); //不用判断.
                int rc =  now_event->init( local_port,  m->chDevIndeCode, now_base->get_base() );
                if( rc  ) // 失败
                {
                    LOG_ERROR_( "init local port:%d event failed! rc:%d, msgtag:%s",  local_port,  rc, m->chDevIndeCode);
                }
            }

            m_client_info.add( local_port,  dst.get_ip(),  dst.get_port(),  now_event,  now_base ) ; // add client
            now_event->add_dst( dst );

            break;
        }

        default :
            break;

    }//switch
	
	sCommand = "after " + sCommand + " from " + dst.get_ip() + ":" + std::to_string(dst.get_port()) + " requst " + m->chDevIndeCode;
    m_client_info.dump( sCommand.c_str() );
}

UdpServerEventBase* PthreadManager::get_idle_thread() // round robin
{
    UdpServerEventBase  *  base =  m_thread_list[ m_cur_thread_index ] ;
    ++ m_cur_thread_index ;
    if( m_cur_thread_index  >=  int( m_thread_list.size() ) ) { m_cur_thread_index = 0 ; }
    return base ;
}





Client::Client()   // def ctor
  : m_port( 0 )
  , m_client_port( 0 )
  , m_event( NULL )
  , m_base( NULL )
{
    m_client_ip[ 0 ] = '\0' ;
}
Client::Client( const int port,  const char * client_ip,  const int client_port,  UdpEvent * event,  UdpServerEventBase * base ) //
  : m_port( port )
  , m_client_port( client_port )
  , m_event( event )
  , m_base( base )
{
    std::memset( m_client_ip, 0, sizeof( m_client_ip ) ) ;
    std::strncpy( m_client_ip,  client_ip,  sizeof( m_client_ip ) - 1 ) ;
}
bool Client::operator == ( const Client & o ) const
{
    return  ( m_port == o.m_port )
          && ( m_client_port == o.m_client_port )
          && ( std::strcmp( m_client_ip,  o.m_client_ip ) ==  0 )  ;
}

    bool ClientInfo::add( const int port,  const char * client_ip,  const int client_port,  UdpEvent *  event,  UdpServerEventBase * base )  // 增加1个客户端
    {
        Client c( port,  client_ip,  client_port,  event,  base ) ;
        UdpEvent * e_old = NULL ;
        UdpServerEventBase * old_base = NULL ;
        for( std::size_t i = 0;  i < m_list.size();  ++i )
        {
            if( m_list[ i ].m_port  ==  port ) { if( e_old == NULL ) { e_old = m_list[ i ].m_event ;  old_base = m_list[ i ].m_base ; } }
            if( m_list[ i ]  ==  c ) return false ;
        }
        if( e_old    !=  NULL ) c.m_event  =  e_old ;
        if( old_base !=  NULL ) c.m_base   =  old_base ;
        //std::vector< Client >::iterator it =  std::find( m_list.begin(),  m_list.end(),  c ) ;
        //if( it  !=  m_list.end() ) return false;  // found

        m_list.push_back( c );
        return true ;
    }

    bool ClientInfo::find_event( const int port,  int & client_count,  UdpEvent ** event,  UdpServerEventBase ** base )  // 查找端口上的 event 与 客户数量
    {
        client_count  =  0 ;
        UdpEvent * e = NULL ;
        UdpServerEventBase * b = NULL ;
        for( std::vector< Client >::iterator it = m_list.begin();  it  !=  m_list.end();  ++it )
        {
            if( it->m_port  ==  port ) { ++ client_count ;  if( e  ==  NULL ) { e = it->m_event ;  b = it->m_base ; }  }
        }
        if( event ) { * event  =  e ; }
        if( base  ) { * base   =  b ; }
        return  e  !=  NULL ;
    }

    bool ClientInfo::del_client( const int port,  const char * client_ip,  const int client_port ) // 删除1个客户端. true=找到并删除 false=未找到
    {
        for( std::vector< Client >::iterator it = m_list.begin();  it  !=  m_list.end();  )
        {
             if(      ( it->m_port == port )
                  &&  ( it->m_client_port == client_port )
                  &&  ( std::strcmp( it->m_client_ip,  client_ip ) == 0 )
               )
             {    it = m_list.erase( it );  return true ;  }
             else
                 ++it ;
        }
        return false ;
    }

    int ClientInfo::del_event( const int port ) // 删除端口上的所有客户端
    {
        int n = 0 ;
        for( std::vector< Client >::iterator it = m_list.begin();  it  !=  m_list.end();  )
        {
             if( it->m_port == port )
             {
                 it = m_list.erase( it );
                 ++n;
             }
             else
                 ++it ;
        }
        return n ;
    }

    void ClientInfo::dump(const char *s)
    {
    	string strLogDump = ConfigXml::getIns()->getValue("Log", "LogDump");
        LOG_INFO_( "%s, total client=%d",  s, m_list.size());
    	if(strLogDump != "1")
    	{
    		return;
    	}
    	
        for( std::vector< Client >::iterator it = m_list.begin();  it  !=  m_list.end();  ++it )
        {
            LOG_DEBUG_( "\t b=%p e=%p   %d -> %s:%d",  it->m_base,  it->m_event,  it->m_port,  it->m_client_ip,  it->m_client_port ) ;
        }
    }

